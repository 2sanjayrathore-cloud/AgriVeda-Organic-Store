import type { Sale, Product } from '@/types';

export function formatPrice(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatDateTime(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function sendWhatsAppMessage(phone: string, message: string) {
  const cleanPhone = phone.replace(/\D/g, '');
  const encodedMessage = encodeURIComponent(message);
  const url = `https://wa.me/${cleanPhone}?text=${encodedMessage}`;
  window.open(url, '_blank');
}

export function sendWhatsAppBill(sale: Sale) {
  const message = `
*AgriVeda Organic Store*
Thank you for your purchase!

*Order ID:* ${sale.orderId}
*Product:* ${sale.product}
*Quantity:* ${sale.quantity}
*Total Amount:* Rs. ${sale.totalAmount}
*Payment Mode:* ${sale.paymentMode}
*Payment Status:* ${sale.paymentStatus}

Thank you for supporting organic farming!
Visit us again at AgriVeda.
  `.trim();

  sendWhatsAppMessage(sale.buyerPhone, message);
}

export function sendAdminWhatsAppNotification(sale: Sale, adminPhone: string) {
  const message = `
*New Sale - AgriVeda*

*Order ID:* ${sale.orderId}
*Product:* ${sale.product}
*Quantity:* ${sale.quantity}
*Amount:* Rs. ${sale.totalAmount}
*Buyer:* ${sale.buyerName}
*Phone:* ${sale.buyerPhone}
*Student:* ${sale.studentName}
*Date:* ${formatDateTime(sale.date)}

Total Sales Today: Check Dashboard
  `.trim();

  sendWhatsAppMessage(adminPhone, message);
}

export function generateBillHTML(sale: Sale): string {
  return `
<!DOCTYPE html>
<html>
<head>
<style>
  body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
  .header { text-align: center; border-bottom: 2px solid #2D5A27; padding-bottom: 20px; margin-bottom: 20px; }
  .header h1 { color: #2D5A27; margin: 0; }
  .header p { color: #5C3D2E; margin: 5px 0; }
  .section { margin-bottom: 20px; }
  .section h3 { color: #2D5A27; border-bottom: 1px solid #F5F1E8; padding-bottom: 5px; }
  .row { display: flex; justify-content: space-between; padding: 5px 0; }
  .row.total { font-weight: bold; font-size: 1.2em; border-top: 2px solid #2D5A27; padding-top: 10px; margin-top: 10px; }
  .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #F5F1E8; color: #5C3D2E; }
  .badge { display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 0.8em; font-weight: bold; }
  .paid { background: #8FAE76; color: white; }
  .pending { background: #C75B39; color: white; }
</style>
</head>
<body>
  <div class="header">
    <h1>AgriVeda Organic Store</h1>
    <p>Pure Organic Inputs for Healthy Farming</p>
    <p>Phone: 7877612427 | Email: sanjayrathorevbyl@gmail.com</p>
  </div>

  <div class="section">
    <h3>Order Details</h3>
    <div class="row"><span>Order ID:</span><span>${sale.orderId}</span></div>
    <div class="row"><span>Date:</span><span>${formatDateTime(sale.date)}</span></div>
  </div>

  <div class="section">
    <h3>Seller Information</h3>
    <div class="row"><span>Student Name:</span><span>${sale.studentName}</span></div>
  </div>

  <div class="section">
    <h3>Buyer Information</h3>
    <div class="row"><span>Name:</span><span>${sale.buyerName}</span></div>
    <div class="row"><span>Phone:</span><span>${sale.buyerPhone}</span></div>
    ${sale.buyerEmail ? `<div class="row"><span>Email:</span><span>${sale.buyerEmail}</span></div>` : ''}
    ${sale.buyerAddress ? `<div class="row"><span>Address:</span><span>${sale.buyerAddress}</span></div>` : ''}
  </div>

  <div class="section">
    <h3>Product Details</h3>
    <div class="row"><span>Product:</span><span>${sale.product}</span></div>
    <div class="row"><span>Quantity:</span><span>${sale.quantity}</span></div>
    <div class="row"><span>Price per Unit:</span><span>Rs. ${sale.pricePerUnit}</span></div>
    <div class="row total"><span>Total Amount:</span><span>Rs. ${sale.totalAmount}</span></div>
  </div>

  <div class="section">
    <h3>Payment Information</h3>
    <div class="row"><span>Payment Mode:</span><span>${sale.paymentMode}</span></div>
    <div class="row"><span>Payment Status:</span><span class="badge ${sale.paymentStatus === 'Paid' ? 'paid' : 'pending'}">${sale.paymentStatus}</span></div>
  </div>

  <div class="footer">
    <p><strong>Thank you for choosing organic!</strong></p>
    <p>Support sustainable farming with AgriVeda.</p>
    <p>Scan QR code to visit our store</p>
  </div>
</body>
</html>
  `;
}

export function printBill(sale: Sale) {
  const html = generateBillHTML(sale);
  const printWindow = window.open('', '_blank');
  if (printWindow) {
    printWindow.document.write(html);
    printWindow.document.close();
    printWindow.print();
  }
}

export function downloadBillPDF(sale: Sale) {
  const html = generateBillHTML(sale);
  const blob = new Blob([html], { type: 'text/html' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `AgriVeda_Bill_${sale.orderId}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
}

export function getProductImage(product: Product): string {
  return product.image || '/product-vermicompost.jpg';
}

export function validatePhone(phone: string): boolean {
  return /^[6-9]\d{9}$/.test(phone.replace(/\D/g, ''));
}

export function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function getAIResponse(query: string, lang: 'en' | 'hi'): string {
  const query_lower = query.toLowerCase();

  const responses: Record<string, { en: string; hi: string }> = {
    jeevamrit: {
      en: `**How to Make Jeevamrit:**

**Ingredients:**
- 10 kg fresh cow dung
- 10 liters cow urine
- 2 kg jaggery (gur)
- 2 kg pulse flour (besan)
- Handful of soil
- 200 liters water

**Step-by-Step Process:**
1. Mix cow dung and cow urine in a large container
2. Add jaggery and pulse flour
3. Add handful of soil (contains beneficial microbes)
4. Add water and stir well
5. Keep in shade, stir twice daily
6. Ready in 2-3 days (will have pleasant fermented smell)

**Usage:** Dilute 1:10 with water and apply to soil or as foliar spray.

**Benefits:**
- Boosts soil microbial activity
- Improves plant immunity
- Enhances nutrient availability
- Cost-effective organic solution`,
      hi: `**जीवामृत बनाने की विधि:**

**सामग्री:**
- 10 किलो ताजा गोबर
- 10 लीटर गोमूत्र
- 2 किलो गुड़
- 2 किलो बेसन
- मुट्ठी भर मिट्टी
- 200 लीटर पानी

**चरण-दर-चरण प्रक्रिया:**
1. गोबर और गोमूत्र को बड़े बर्तन में मिलाएं
2. गुड़ और बेसन मिलाएं
3. मुट्ठी भर मिट्टी डालें (लाभदायक सूक्ष्म जीव)
4. पानी मिलाकर अच्छी तरह हिलाएं
5. छाया में रखें, दिन में दो बार हिलाएं
6. 2-3 दिन में तैयार (सुखद खमीर की गंध आएगी)

**उपयोग:** 1:10 अनुपात में पानी मिलाकर मिट्टी में या स्प्रे के रूप में लगाएं।

**फायदे:**
- मिट्टी की सूक्ष्म जीव गतिविधि बढ़ाता है
- पौधों की प्रतिरोधक क्षमता बढ़ाता है
- पोषक तत्वों की उपलब्धता बढ़ाता है
- लागत प्रभावी जैविक समाधान`,
    },
    pest: {
      en: `**Organic Pest Control Methods:**

**1. Neemastra (Neem Spray)**
- Mix 5 kg neem leaves + 5 liters cow urine
- Ferment for 7 days, dilute 1:5 and spray
- Effective against: Aphids, mites, leaf miners

**2. Bramastra**
- Garlic 1kg + Green chili 500g + Neem leaves 2kg
- Boil in 10 liters water, cool and filter
- Dilute 1:10, spray every 15 days
- Effective against: Caterpillars, borers, all major pests

**3. Agniastra**
- Green chili 1kg + Garlic 500g + Tobacco 100g
- Boil in 10 liters water
- Very potent - dilute 1:20 before use
- Effective against: Stubborn pests, armyworm

**4. Physical Methods**
- Yellow sticky traps for whiteflies
- Neem cake in soil
- Companion planting (marigold, garlic)
- Handpicking large caterpillars

**Prevention Tips:**
- Maintain field sanitation
- Crop rotation
- Resistant varieties
- Proper spacing for air circulation`,
      hi: `**जैविक कीट नियंत्रण विधियां:**

**1. नीमास्त्र (नीम स्प्रे)**
- 5 किलो नीम पत्ते + 5 लीटर गोमूत्र मिलाएं
- 7 दिन खमीर करें, 1:5 मिलाकर स्प्रे करें
- प्रभावी: एफिड्स, माइट्स, लीफ माइनर

**2. ब्रह्मास्त्र**
- लहसुन 1 किलो + हरी मिर्च 500 ग्राम + नीम पत्ते 2 किलो
- 10 लीटर पानी में उबालें, ठंडा करके छानें
- 1:10 मिलाकर हर 15 दिन स्प्रे करें
- प्रभावी: कैटरपिलर्स, बोरर्स, सभी प्रमुख कीट

**3. अग्नास्त्र**
- हरी मिर्च 1 किलो + लहसुन 500 ग्राम + तंबाकू 100 ग्राम
- 10 लीटर पानी में उबालें
- बहुत तेज - उपयोग से पहले 1:20 मिलाएं
- प्रभावी: जिद्दी कीट, आर्मीवर्म

**4. भौतिक विधियां**
- सफेद मक्खी के लिए पीला स्टिकी ट्रैप
- मिट्टी में नीम की खली
- साथी फसल (गेंदा, लहसुन)
- बड़े कैटरपिलर्स को हाथ से उठाएं

**रोकथाम युक्तियां:**
- खेत की सफाई बनाए रखें
- फसल चक्र
- प्रतिरोधी किस्में
- हवा के संचार के लिए उचित दूरी`,
    },
    disease: {
      en: `**Common Plant Diseases & Organic Treatment:**

**1. Fungal Diseases (Leaf spot, Blight, Rust)**
- Spray: 3% neem oil solution
- Apply: Trichoderma viride (available as BGA)
- Use: Well-decomposed compost
- Ensure: Proper drainage

**2. Bacterial Diseases (Wilt, Canker)**
- Apply: Jeevamrit to boost immunity
- Spray: Cow urine diluted 1:10
- Remove: Infected plants immediately
- Practice: Crop rotation

**3. Viral Diseases (Mosaic, Leaf curl)**
- Control: Vector insects (whiteflies, aphids)
- Use: Neemastra regularly
- Remove: Infected plants
- Use: Resistant varieties

**4. Root Rot**
- Apply: Trichoderma-enriched compost
- Ensure: Good drainage
- Use: Raised beds
- Apply: Beejamrit at planting

**General Prevention:**
- Seed treatment with Beejamrit
- Regular Jeevamrit application
- Balanced nutrition through compost
- Crop rotation
- Proper spacing`,
      hi: `**सामान्य पौधे रोग और जैविक उपचार:**

**1. कवक रोग (पत्ती धब्बा, झुलसा, जंग)**
- स्प्रे: 3% नीम तेल घोल
- लगाएं: ट्राइकोडर्मा विरिडे (BGA के रूप में उपलब्ध)
- उपयोग: अच्छी तरह सड़ी हुई खाद
- सुनिश्चित करें: उचित जल निकासी

**2. जीवाणु रोग (मुरझाहट, कैंकर)**
- लगाएं: प्रतिरक्षा बढ़ाने के लिए जीवामृत
- स्प्रे: गोमूत्र 1:10 मिलाकर
- हटाएं: संक्रमित पौधे तुरंत
- अपनाएं: फसल चक्र

**3. वायरस रोग (मोज़ेक, पत्ती मुड़ना)**
- नियंत्रण: वेक्टर कीट (सफेद मक्खी, एफिड्स)
- उपयोग: नीमास्त्र नियमित रूप से
- हटाएं: संक्रमित पौधे
- उपयोग: प्रतिरोधी किस्में

**4. जड़ सड़न**
- लगाएं: ट्राइकोडर्मा समृद्ध कंपोस्ट
- सुनिश्चित करें: अच्छी जल निकासी
- उपयोग: उठी हुई क्यारियां
- लगाएं: रोपण के समय बीजामृत

**सामान्य रोकथाम:**
- बीजामृत से बीज उपचार
- नियमित जीवामृत अनुप्रयोग
- कंपोस्ट से संतुलित पोषण
- फसल चक्र
- उचित दूरी`,
    },
    fertilizer: {
      en: `**Organic Fertilizer Guide:**

**1. Vermicompost**
- NPK: 1.5-1.0-0.8 + micronutrients
- Apply: 2-5 tons/acre
- Best for: All crops, soil conditioning
- Frequency: Every crop season

**2. Enriched Vermicompost**
- Enhanced with Trichoderma and PSB
- Apply: 1-2 tons/acre
- Best for: Disease-prone crops
- Benefit: Dual action - nutrition + protection

**3. BGA (Blue Green Algae)**
- Fixes atmospheric nitrogen
- Apply: 10 kg/acre for paddy
- Best for: Rice, waterlogged crops
- Frequency: Once per season

**4. Panchgavya**
- Growth promoter + immunity booster
- Dilute: 3% solution
- Apply: Foliar spray every 15 days
- Best for: Vegetables, fruits

**5. Jeevamrit**
- Liquid microbial culture
- Dilute: 1:10
- Apply: Soil drench or foliar
- Frequency: Every 15 days

**Application Schedule:**
- Basal: Vermicompost at planting
- 15 days: Jeevamrit
- 30 days: Panchgavya spray
- 45 days: Vermiwash foliar
- Repeat cycle`,
      hi: `**जैविक उर्वरक गाइड:**

**1. वर्मीकंपोस्ट**
- NPK: 1.5-1.0-0.8 + सूक्ष्म पोषक तत्व
- लगाएं: 2-5 टन/एकड़
- सर्वश्रेष्ठ: सभी फसलों, मिट्टी सुधार के लिए
- आवृत्ति: हर फसल सीजन

**2. समृद्ध वर्मीकंपोस्ट**
- ट्राइकोडर्मा और PSB से समृद्ध
- लगाएं: 1-2 टन/एकड़
- सर्वश्रेष्ठ: रोग-प्रवण फसलों के लिए
- लाभ: दोहरी क्रिया - पोषण + सुरक्षा

**3. BGA (ब्लू ग्रीन एल्गी)**
- वायुमंडलीय नाइट्रोजन स्थिर करता है
- लगाएं: धान के लिए 10 किलो/एकड़
- सर्वश्रेष्ठ: चावल, जलमग्न फसलों के लिए
- आवृत्ति: सीजन में एक बार

**4. पंचगव्य**
- ग्रोथ प्रमोटर + इम्युनिटी बूस्टर
- मिलाएं: 3% घोल
- लगाएं: हर 15 दिन फोलियर स्प्रे
- सर्वश्रेष्ठ: सब्जियां, फल

**5. जीवामृत**
- तरल सूक्ष्म जीव संस्कृति
- मिलाएं: 1:10
- लगाएं: मिट्टी में या फोलियर
- आवृत्ति: हर 15 दिन

**अनुप्रयोग अनुसूची:**
- बेसल: रोपण के समय वर्मीकंपोस्ट
- 15 दिन: जीवामृत
- 30 दिन: पंचगव्य स्प्रे
- 45 दिन: वर्मीवाश फोलियर
- चक्र दोहराएं`,
    },
  };

  if (query_lower.includes('jeevamrit') || query_lower.includes('जीवामृत')) {
    return responses.jeevamrit[lang];
  }
  if (query_lower.includes('pest') || query_lower.includes('insect') || query_lower.includes('keet') || query_lower.includes('कीट')) {
    return responses.pest[lang];
  }
  if (query_lower.includes('disease') || query_lower.includes('rog') || query_lower.includes('रोग')) {
    return responses.disease[lang];
  }
  if (query_lower.includes('fertilizer') || query_lower.includes('khad') || query_lower.includes('खाद')) {
    return responses.fertilizer[lang];
  }

  // Default response
  return lang === 'en'
    ? `Thank you for your question about **"${query}"**. Here's what I can help you with:

**General Organic Farming Tips:**

1. **Soil Health First**
   - Add organic matter regularly
   - Use vermicompost as basal dose
   - Maintain soil pH between 6.5-7.5

2. **Integrated Pest Management**
   - Use Neemastra for regular prevention
   - Apply Bramastra for active infestations
   - Practice crop rotation

3. **Nutrient Management**
   - Jeevamrit every 15 days
   - Vermiwash as foliar spray
   - Panchgavya for growth stages

4. **Water Management**
   - Drip irrigation preferred
   - Morning watering recommended
   - Avoid waterlogging

**For specific queries, ask about:**
- How to make Jeevamrit
- Pest control methods
- Disease management
- Organic fertilizers

Would you like more detailed information on any of these topics?`
    : `**"${query}"** के बारे में आपके प्रश्न के लिए धन्यवाद। यहां मैं आपकी कैसे मदद कर सकता हूं:

**सामान्य जैविक खेती युक्तियां:**

1. **पहले मिट्टी का स्वास्थ्य**
   - नियमित रूप से जैविक पदार्थ मिलाएं
   - बेसल खुराक के रूप में वर्मीकंपोस्ट का उपयोग करें
   - मिट्टी का pH 6.5-7.5 बनाए रखें

2. **एकीकृत कीट प्रबंधन**
   - नियमित रोकथाम के लिए नीमास्त्र का उपयोग करें
   - सक्रमण के लिए ब्रह्मास्त्र लगाएं
   - फसल चक्र अपनाएं

3. **पोषक तत्व प्रबंधन**
   - हर 15 दिन जीवामृत
   - फोलियर स्प्रे के रूप में वर्मीवाश
   - विकास अवस्थाओं के लिए पंचगव्य

4. **जल प्रबंधन**
   - ड्रिप सिंचाई बेहतर
   - सुबह पानी दें
   - जलजमाव से बचें

**विशिष्ट प्रश्नों के लिए पूछें:**
- जीवामृत बनाने की विधि
- कीट नियंत्रण विधियां
- रोग प्रबंधन
- जैविक उर्वरक

क्या आप इनमें से किसी विषय पर अधिक विस्तृत जानकारी चाहेंगे?`;
}

export function getDiseaseDiagnosis(_imageDescription: string, lang: 'en' | 'hi'): string {
  return lang === 'en'
    ? `**AI Plant Diagnosis Report**

Based on the image analysis, here's what I found:

**Probable Issue:** Fungal Leaf Spot / Early Blight

**Confidence Level:** 85%

**Symptoms Observed:**
- Dark brown spots on leaves
- Yellowing around spots
- Spots have concentric rings

**Organic Treatment Plan:**

**Step 1: Immediate Action**
- Remove and destroy infected leaves
- Do not compost infected material
- Improve air circulation around plants

**Step 2: Organic Spray**
- Mix 3% neem oil solution
- Add pinch of turmeric
- Spray every 3 days for 2 weeks

**Step 3: Soil Treatment**
- Apply Trichoderma-enriched vermicompost
- Add Jeevamrit to soil
- Maintain proper drainage

**Step 4: Prevention**
- Spray Neemastra weekly
- Avoid overhead watering
- Practice crop rotation

**Recommended Products from Our Store:**
- Neemastra (Rs. 100/litre)
- Enriched Vermicompost (Rs. 15/kg)
- Vermiwash (Rs. 80/litre)

**Follow-up:** If symptoms persist after 2 weeks, please share another photo.`
    : `**एआई पौधा निदान रिपोर्ट**

छवि विश्लेषण के आधार पर, यहां मैंने जो पाया:

**संभावित समस्या:** फंगल पत्ती धब्बा / अर्ली ब्लाइट

**विश्वास स्तर:** 85%

**प्रेक्षित लक्षण:**
- पत्तियों पर गहरे भूरे धब्बे
- धब्बों के चारों ओर पीलापन
- धब्बों में वृत्ताकार छल्ले

**जैविक उपचार योजना:**

**चरण 1: तत्काल कार्रवाई**
- संक्रमित पत्तियों को हटाएं और नष्ट करें
- संक्रमित सामग्री को कंपोस्ट न करें
- पौधों के आसपास हवा का संचार बेहतर करें

**चरण 2: जैविक स्प्रे**
- 3% नीम तेल घोल तैयार करें
- थोड़ी हल्दी मिलाएं
- 2 सप्ताह तक हर 3 दिन स्प्रे करें

**चरण 3: मिट्टी उपचार**
- ट्राइकोडर्मा-समृद्ध वर्मीकंपोस्ट लगाएं
- मिट्टी में जीवामृत डालें
- उचित जल निकासी बनाए रखें

**चरण 4: रोकथाम**
- हर हफ्ते नीमास्त्र स्प्रे करें
- ऊपर से पानी देने से बचें
- फसल चक्र अपनाएं

**हमारे स्टोर से अनुशंसित उत्पाद:**
- नीमास्त्र (Rs. 100/लीटर)
- समृद्ध वर्मीकंपोस्ट (Rs. 15/किलो)
- वर्मीवाश (Rs. 80/लीटर)

**फॉलो-अप:** यदि 2 सप्ताह बाद लक्षण बने रहें, तो कृपया एक और फोटो साझा करें।`;
}
