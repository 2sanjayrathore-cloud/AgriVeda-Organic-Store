export interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  unit: string;
  image: string;
  description: string;
  stock: number;
  rating: number;
  barcode: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Sale {
  id: string;
  orderId: string;
  studentName: string;
  studentId: string;
  date: string;
  product: string;
  productId: number;
  quantity: number;
  pricePerUnit: number;
  totalAmount: number;
  buyerName: string;
  buyerPhone: string;
  buyerEmail: string;
  buyerAddress: string;
  paymentMode: string;
  paymentStatus: string;
  amountReceived: number;
}

export interface Expense {
  id: string;
  category: string;
  amount: number;
  description: string;
  date: string;
}

export interface Student {
  id: string;
  name: string;
  phone: string;
  accessCode: string;
  active: boolean;
  totalSales: number;
  totalRevenue: number;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export interface LoyaltyCustomer {
  phone: string;
  name: string;
  points: number;
  totalSpent: number;
  visits: number;
}

export interface InventoryLog {
  id: string;
  productId: number;
  productName: string;
  change: number;
  reason: string;
  date: string;
}

export interface Notification {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
  timestamp: number;
}

export type Language = 'en' | 'hi';
export type UserRole = 'guest' | 'student' | 'admin';
