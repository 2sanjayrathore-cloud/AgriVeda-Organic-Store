import { useApp } from '@/context/AppContext';
import { CheckCircle, XCircle, Info, X } from 'lucide-react';

export default function ToastNotifications() {
  const { notifications, removeNotification } = useApp();

  if (notifications.length === 0) return null;

  return (
    <div className="fixed top-20 right-4 z-[100] space-y-2">
      {notifications.map((note) => (
        <div
          key={note.id}
          className={`flex items-center space-x-2 px-4 py-3 rounded-lg shadow-lg transform transition-all duration-300 animate-slide-in-right max-w-sm ${
            note.type === 'success'
              ? 'bg-[#4A8C42] text-white'
              : note.type === 'error'
              ? 'bg-[#C75B39] text-white'
              : 'bg-[#5B8DB8] text-white'
          }`}
        >
          {note.type === 'success' ? (
            <CheckCircle className="h-5 w-5 flex-shrink-0" />
          ) : note.type === 'error' ? (
            <XCircle className="h-5 w-5 flex-shrink-0" />
          ) : (
            <Info className="h-5 w-5 flex-shrink-0" />
          )}
          <span className="text-sm font-medium flex-1">{note.message}</span>
          <button
            onClick={() => removeNotification(note.id)}
            className="p-1 rounded hover:bg-white/20 transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      ))}
    </div>
  );
}
