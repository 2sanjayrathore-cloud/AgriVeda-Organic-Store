import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { useTranslation } from '@/hooks/useTranslation';
import {
  Leaf,
  ShoppingCart,
  Menu,
  X,
  Bot,
  Stethoscope,
  GraduationCap,
  Shield,
  Globe,
  LogOut,
  ChevronDown,
} from 'lucide-react';

export default function Navigation() {
  const { language, setLanguage, cart, isAdminLoggedIn, logoutAdmin, userRole, logoutStudent } = useApp();
  const { t } = useTranslation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const isActive = (path: string) => location.pathname === path;

  const navLinks = [
    { to: '/products', label: t('products'), icon: Leaf },
    { to: '/ai-doctor', label: t('aiDoctor'), icon: Stethoscope },
    { to: '/ai-chat', label: t('aiChat'), icon: Bot },
    { to: '/student', label: t('studentPortal'), icon: GraduationCap },
  ];

  const handleLogout = () => {
    if (isAdminLoggedIn) {
      logoutAdmin();
      navigate('/');
    } else if (userRole === 'student') {
      logoutStudent();
      navigate('/');
    }
  };

  return (
    <nav className="bg-[#2D5A27] text-[#FAFAF5] sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 group">
            <Leaf className="h-7 w-7 text-[#D4A017] group-hover:rotate-12 transition-transform duration-300" />
            <span className="text-xl font-bold tracking-wide">AgriVeda</span>
          </Link>

          {/* Desktop Links */}
          <div className="hidden md:flex items-center space-x-1">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 hover:bg-[#4A8C42] hover:scale-105 active:scale-95 ${
                  isActive(link.to) ? 'bg-[#4A8C42] ring-1 ring-[#D4A017]' : ''
                }`}
              >
                <link.icon className="h-4 w-4" />
                <span>{link.label}</span>
              </Link>
            ))}
            {isAdminLoggedIn && (
              <Link
                to="/admin/dashboard"
                className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 hover:bg-[#4A8C42] hover:scale-105 active:scale-95 ${
                  isActive('/admin/dashboard') ? 'bg-[#4A8C42] ring-1 ring-[#D4A017]' : ''
                }`}
              >
                <Shield className="h-4 w-4" />
                <span>{t('dashboard')}</span>
              </Link>
            )}
          </div>

          {/* Right Side */}
          <div className="flex items-center space-x-3">
            {/* Language Toggle */}
            <div className="relative">
              <button
                onClick={() => setLangOpen(!langOpen)}
                className="flex items-center space-x-1 px-3 py-1.5 rounded-md text-sm hover:bg-[#4A8C42] transition-all duration-200 active:scale-95"
              >
                <Globe className="h-4 w-4" />
                <span className="uppercase font-semibold">{language}</span>
                <ChevronDown className="h-3 w-3" />
              </button>
              {langOpen && (
                <div className="absolute right-0 mt-2 w-32 bg-white rounded-md shadow-lg py-1 z-50">
                  <button
                    onClick={() => { setLanguage('en'); setLangOpen(false); }}
                    className={`block w-full text-left px-4 py-2 text-sm ${language === 'en' ? 'bg-[#8FAE76] text-white' : 'text-gray-700 hover:bg-gray-100'} transition-colors`}
                  >
                    {t('english')}
                  </button>
                  <button
                    onClick={() => { setLanguage('hi'); setLangOpen(false); }}
                    className={`block w-full text-left px-4 py-2 text-sm ${language === 'hi' ? 'bg-[#8FAE76] text-white' : 'text-gray-700 hover:bg-gray-100'} transition-colors`}
                  >
                    {t('hindi')}
                  </button>
                </div>
              )}
            </div>

            {/* Cart */}
            <Link
              to="/cart"
              className="relative p-2 rounded-md hover:bg-[#4A8C42] transition-all duration-200 active:scale-95"
            >
              <ShoppingCart className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#D4A017] text-[#3B2417] text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center animate-pulse">
                  {cartCount}
                </span>
              )}
            </Link>

            {/* Admin Login/Logout */}
            {isAdminLoggedIn || userRole === 'student' ? (
              <button
                onClick={handleLogout}
                className="hidden md:flex items-center space-x-1 px-3 py-2 rounded-md text-sm hover:bg-[#4A8C42] transition-all duration-200 active:scale-95"
              >
                <LogOut className="h-4 w-4" />
                <span>{t('logout')}</span>
              </button>
            ) : (
              <Link
                to="/admin"
                className="hidden md:flex items-center space-x-1 px-3 py-2 rounded-md text-sm hover:bg-[#4A8C42] transition-all duration-200 active:scale-95"
              >
                <Shield className="h-4 w-4" />
                <span>{t('adminLogin')}</span>
              </Link>
            )}

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden p-2 rounded-md hover:bg-[#4A8C42] transition-all duration-200 active:scale-95"
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div className="md:hidden pb-4 border-t border-[#4A8C42] mt-2 pt-2">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setMobileOpen(false)}
                className={`flex items-center space-x-2 px-3 py-2.5 rounded-md text-sm font-medium transition-all ${
                  isActive(link.to) ? 'bg-[#4A8C42]' : 'hover:bg-[#4A8C42]/60'
                }`}
              >
                <link.icon className="h-4 w-4" />
                <span>{link.label}</span>
              </Link>
            ))}
            {isAdminLoggedIn && (
              <Link
                to="/admin/dashboard"
                onClick={() => setMobileOpen(false)}
                className="flex items-center space-x-2 px-3 py-2.5 rounded-md text-sm font-medium hover:bg-[#4A8C42]/60"
              >
                <Shield className="h-4 w-4" />
                <span>{t('dashboard')}</span>
              </Link>
            )}
            {(isAdminLoggedIn || userRole === 'student') ? (
              <button
                onClick={() => { handleLogout(); setMobileOpen(false); }}
                className="flex items-center space-x-2 px-3 py-2.5 rounded-md text-sm font-medium hover:bg-[#4A8C42]/60 w-full"
              >
                <LogOut className="h-4 w-4" />
                <span>{t('logout')}</span>
              </button>
            ) : (
              <Link
                to="/admin"
                onClick={() => setMobileOpen(false)}
                className="flex items-center space-x-2 px-3 py-2.5 rounded-md text-sm font-medium hover:bg-[#4A8C42]/60"
              >
                <Shield className="h-4 w-4" />
                <span>{t('adminLogin')}</span>
              </Link>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}
