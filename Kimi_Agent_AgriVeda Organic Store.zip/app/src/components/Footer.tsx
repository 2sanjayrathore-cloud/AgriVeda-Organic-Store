import { Link } from 'react-router-dom';
import { useTranslation } from '@/hooks/useTranslation';
import { Leaf, Phone, Mail, MapPin, ExternalLink } from 'lucide-react';

export default function Footer() {
  const { t } = useTranslation();

  return (
    <footer className="bg-[#3B2417] text-[#FAFAF5] mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <Leaf className="h-6 w-6 text-[#D4A017]" />
              <span className="text-xl font-bold">AgriVeda</span>
            </Link>
            <p className="text-sm text-[#F5F1E8]/80 leading-relaxed">
              Pure Organic Inputs for Healthy Farming. Nature-based solutions crafted by students for sustainable agriculture.
            </p>
            <div className="flex items-center space-x-1 text-[#D4A017]">
              <img src="/organic-badge.jpg" alt="Organic Certified" className="h-12 w-12 rounded-full object-cover" />
              <span className="text-xs font-medium">Certified Organic</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-[#D4A017]">Quick Links</h3>
            <ul className="space-y-2">
              {[
                { to: '/products', label: t('products') },
                { to: '/ai-doctor', label: t('aiDoctor') },
                { to: '/ai-chat', label: t('aiChat') },
                { to: '/student', label: t('studentPortal') },
              ].map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className="text-sm text-[#F5F1E8]/80 hover:text-[#D4A017] transition-colors duration-200 flex items-center space-x-1"
                  >
                    <ExternalLink className="h-3 w-3" />
                    <span>{link.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-[#D4A017]">{t('contactUs')}</h3>
            <ul className="space-y-3">
              <li className="flex items-center space-x-2 text-sm">
                <Phone className="h-4 w-4 text-[#8FAE76]" />
                <span>7877612427</span>
              </li>
              <li className="flex items-center space-x-2 text-sm">
                <Mail className="h-4 w-4 text-[#8FAE76]" />
                <span>sanjayrathorevbyl@gmail.com</span>
              </li>
              <li className="flex items-start space-x-2 text-sm">
                <MapPin className="h-4 w-4 text-[#8FAE76] mt-0.5" />
                <span>Organic Store, Agriculture College Campus, India</span>
              </li>
            </ul>
          </div>

          {/* Store Hours */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-[#D4A017]">Store Hours</h3>
            <ul className="space-y-2 text-sm text-[#F5F1E8]/80">
              <li className="flex justify-between">
                <span>Monday - Saturday</span>
                <span className="text-[#8FAE76]">9 AM - 6 PM</span>
              </li>
              <li className="flex justify-between">
                <span>Sunday</span>
                <span className="text-[#C75B39]">Closed</span>
              </li>
              <li className="pt-2 border-t border-[#F5F1E8]/20">
                <span className="text-[#D4A017] font-medium">Online Orders: 24/7</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-10 pt-6 border-t border-[#F5F1E8]/20 flex flex-col md:flex-row items-center justify-between">
          <p className="text-xs text-[#F5F1E8]/60">
            Made with care by College Students. All rights reserved.
          </p>
          <p className="text-xs text-[#F5F1E8]/60 mt-2 md:mt-0">
            AgriVeda Organic Store - {new Date().getFullYear()}
          </p>
        </div>
      </div>
    </footer>
  );
}
