import { Outlet } from 'react-router-dom';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import ToastNotifications from '@/components/ToastNotifications';
import { ScrollToTop } from '@/components/ScrollToTop';

export default function Layout() {
  return (
    <div className="min-h-screen bg-[#F5F1E8] flex flex-col">
      <ScrollToTop />
      <Navigation />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
      <ToastNotifications />
    </div>
  );
}
