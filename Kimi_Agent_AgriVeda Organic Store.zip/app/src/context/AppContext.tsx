import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { Language, UserRole, CartItem, Sale, Expense, Student, Notification, LoyaltyCustomer, InventoryLog, Product } from '@/types';
import { products as defaultProducts } from '@/data/products';
import { adminPhone, adminEmail } from '@/data/products';

interface AppState {
  language: Language;
  setLanguage: (lang: Language) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  currentStudent: Student | null;
  setCurrentStudent: (student: Student | null) => void;
  cart: CartItem[];
  addToCart: (product: Product, quantity: number) => void;
  removeFromCart: (productId: number) => void;
  updateCartQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  sales: Sale[];
  addSale: (sale: Sale) => void;
  deleteSale: (saleId: string) => void;
  expenses: Expense[];
  addExpense: (expense: Expense) => void;
  deleteExpense: (expenseId: string) => void;
  students: Student[];
  addStudent: (student: Student) => void;
  toggleStudentStatus: (studentId: string) => void;
  removeStudent: (studentId: string) => void;
  products: Product[];
  updateProduct: (product: Product) => void;
  inventory: InventoryLog[];
  addInventoryLog: (log: InventoryLog) => void;
  loyaltyCustomers: LoyaltyCustomer[];
  addLoyaltyPoints: (phone: string, name: string, points: number, spent: number) => void;
  notifications: Notification[];
  addNotification: (message: string, type: 'success' | 'error' | 'info') => void;
  removeNotification: (id: string) => void;
  isAdminLoggedIn: boolean;
  loginAdmin: (password: string) => boolean;
  logoutAdmin: () => void;
  loginStudent: (accessCode: string) => boolean;
  logoutStudent: () => void;
  adminPhone: string;
  adminEmail: string;
  generateOrderId: () => string;
  exportToExcel: (data: any[], filename: string) => void;
}

const AppContext = createContext<AppState | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('agri-veda-language');
    return (saved as Language) || 'en';
  });

  const [userRole, setUserRole] = useState<UserRole>('guest');
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null);
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('agri-veda-cart');
    return saved ? JSON.parse(saved) : [];
  });
  const [sales, setSales] = useState<Sale[]>(() => {
    const saved = localStorage.getItem('agri-veda-sales');
    return saved ? JSON.parse(saved) : [];
  });
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('agri-veda-expenses');
    return saved ? JSON.parse(saved) : [];
  });
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('agri-veda-students');
    return saved ? JSON.parse(saved) : [
      { id: 'STU001', name: 'Rahul Kumar', phone: '9876543210', accessCode: 'AGV2024', active: true, totalSales: 45, totalRevenue: 25000 },
      { id: 'STU002', name: 'Priya Sharma', phone: '9876543211', accessCode: 'AGV2025', active: true, totalSales: 38, totalRevenue: 18500 },
      { id: 'STU003', name: 'Amit Singh', phone: '9876543212', accessCode: 'AGV2026', active: false, totalSales: 20, totalRevenue: 12000 },
    ];
  });
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('agri-veda-products');
    return saved ? JSON.parse(saved) : defaultProducts;
  });
  const [inventory, setInventory] = useState<InventoryLog[]>(() => {
    const saved = localStorage.getItem('agri-veda-inventory');
    return saved ? JSON.parse(saved) : [];
  });
  const [loyaltyCustomers, setLoyaltyCustomers] = useState<LoyaltyCustomer[]>(() => {
    const saved = localStorage.getItem('agri-veda-loyalty');
    return saved ? JSON.parse(saved) : [];
  });
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(() => {
    return localStorage.getItem('agri-veda-admin') === 'true';
  });

  useEffect(() => {
    localStorage.setItem('agri-veda-cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('agri-veda-sales', JSON.stringify(sales));
  }, [sales]);

  useEffect(() => {
    localStorage.setItem('agri-veda-expenses', JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem('agri-veda-students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('agri-veda-products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('agri-veda-inventory', JSON.stringify(inventory));
  }, [inventory]);

  useEffect(() => {
    localStorage.setItem('agri-veda-loyalty', JSON.stringify(loyaltyCustomers));
  }, [loyaltyCustomers]);

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('agri-veda-language', lang);
  }, []);

  const addToCart = useCallback((product: Product, quantity: number) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
  }, []);

  const removeFromCart = useCallback((productId: number) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  }, []);

  const updateCartQuantity = useCallback((productId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  }, [removeFromCart]);

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  const addSale = useCallback((sale: Sale) => {
    setSales(prev => [sale, ...prev]);
  }, []);

  const deleteSale = useCallback((saleId: string) => {
    setSales(prev => prev.filter(s => s.id !== saleId));
  }, []);

  const addExpense = useCallback((expense: Expense) => {
    setExpenses(prev => [expense, ...prev]);
  }, []);

  const deleteExpense = useCallback((expenseId: string) => {
    setExpenses(prev => prev.filter(e => e.id !== expenseId));
  }, []);

  const addStudent = useCallback((student: Student) => {
    setStudents(prev => [...prev, student]);
  }, []);

  const toggleStudentStatus = useCallback((studentId: string) => {
    setStudents(prev =>
      prev.map(s => s.id === studentId ? { ...s, active: !s.active } : s)
    );
  }, []);

  const removeStudent = useCallback((studentId: string) => {
    setStudents(prev => prev.filter(s => s.id !== studentId));
  }, []);

  const updateProduct = useCallback((updatedProduct: Product) => {
    setProducts(prev =>
      prev.map(p => p.id === updatedProduct.id ? updatedProduct : p)
    );
  }, []);

  const addInventoryLog = useCallback((log: InventoryLog) => {
    setInventory(prev => [log, ...prev]);
    setProducts(prev =>
      prev.map(p =>
        p.id === log.productId
          ? { ...p, stock: Math.max(0, p.stock + log.change) }
          : p
      )
    );
  }, []);

  const addLoyaltyPoints = useCallback((phone: string, name: string, points: number, spent: number) => {
    setLoyaltyCustomers(prev => {
      const existing = prev.find(c => c.phone === phone);
      if (existing) {
        return prev.map(c =>
          c.phone === phone
            ? { ...c, points: c.points + points, totalSpent: c.totalSpent + spent, visits: c.visits + 1 }
            : c
        );
      }
      return [...prev, { phone, name, points, totalSpent: spent, visits: 1 }];
    });
  }, []);

  const addNotification = useCallback((message: string, type: 'success' | 'error' | 'info') => {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    setNotifications(prev => [...prev, { id, message, type, timestamp: Date.now() }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 3000);
  }, []);

  const removeNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const loginAdmin = useCallback((password: string) => {
    if (password === '7877612427' || password === 'admin123') {
      setIsAdminLoggedIn(true);
      setUserRole('admin');
      localStorage.setItem('agri-veda-admin', 'true');
      return true;
    }
    return false;
  }, []);

  const logoutAdmin = useCallback(() => {
    setIsAdminLoggedIn(false);
    setUserRole('guest');
    localStorage.removeItem('agri-veda-admin');
  }, []);

  const loginStudent = useCallback((accessCode: string) => {
    const student = students.find(s => s.accessCode === accessCode && s.active);
    if (student) {
      setCurrentStudent(student);
      setUserRole('student');
      return true;
    }
    return false;
  }, [students]);

  const logoutStudent = useCallback(() => {
    setCurrentStudent(null);
    setUserRole('guest');
  }, []);

  const generateOrderId = useCallback(() => {
    const prefix = 'AGV-';
    const random = Math.random().toString(36).substring(2, 7).toUpperCase();
    const timestamp = Date.now().toString(36).substring(-4).toUpperCase();
    return `${prefix}${random}${timestamp}`;
  }, []);

  const exportToExcel = useCallback((data: any[], filename: string) => {
    const headers = Object.keys(data[0] || {}).join(',');
    const rows = data.map(row => Object.values(row).join(',')).join('\n');
    const csv = `${headers}\n${rows}`;
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }, []);

  const value: AppState = {
    language,
    setLanguage,
    userRole,
    setUserRole,
    currentStudent,
    setCurrentStudent,
    cart,
    addToCart,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    sales,
    addSale,
    deleteSale,
    expenses,
    addExpense,
    deleteExpense,
    students,
    addStudent,
    toggleStudentStatus,
    removeStudent,
    products,
    updateProduct,
    inventory,
    addInventoryLog,
    loyaltyCustomers,
    addLoyaltyPoints,
    notifications,
    addNotification,
    removeNotification,
    isAdminLoggedIn,
    loginAdmin,
    logoutAdmin,
    loginStudent,
    logoutStudent,
    adminPhone,
    adminEmail,
    generateOrderId,
    exportToExcel,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}
