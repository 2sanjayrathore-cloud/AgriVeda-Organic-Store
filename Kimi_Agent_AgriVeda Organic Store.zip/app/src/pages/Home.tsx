import { Link } from 'react-router-dom';
import { useTranslation } from '@/hooks/useTranslation';
import { useApp } from '@/context/AppContext';
import { products, categories } from '@/data/products';
import {
  Leaf, Shield, GraduationCap, Bot, ArrowRight, Star,
  ShoppingCart, Play, CheckCircle, TrendingUp, Users, Award, Stethoscope,
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { useState } from 'react';

export default function Home() {
  const { t, language } = useTranslation();
  const { addToCart, addNotification } = useApp();
  const [activeCategory, setActiveCategory] = useState('All');

  const featuredProducts = products.slice(0, 8);
  const filteredProducts = activeCategory === 'All'
    ? featuredProducts
    : featuredProducts.filter(p => p.category === activeCategory);

  const features = [
    { icon: Shield, title: t('organic'), desc: 'Certified organic products, chemical-free and safe for all crops' },
    { icon: GraduationCap, title: t('studentCrafted'), desc: 'Prepared and managed by agriculture students with expert guidance' },
    { icon: Bot, title: t('aiPowered'), desc: 'AI-powered farming assistant and plant disease doctor' },
    { icon: Leaf, title: t('directFromCollege'), desc: 'Direct from college farm to your field, fresh and authentic' },
  ];

  const testimonials = [
    { name: t('farmer1Name'), quote: t('farmer1Quote'), image: '/testimonial-1.jpg' },
    { name: t('farmer2Name'), quote: t('farmer2Quote'), image: '/testimonial-2.jpg' },
    { name: t('farmer3Name'), quote: t('farmer3Quote'), image: '/testimonial-3.jpg' },
  ];

  const stats = [
    { icon: TrendingUp, value: '15,000+', label: 'Orders Delivered' },
    { icon: Users, value: '8,000+', label: 'Happy Farmers' },
    { icon: Leaf, value: '16', label: 'Organic Products' },
    { icon: Award, value: '100%', label: 'Satisfaction' },
  ];

  const handleAddToCart = (product: typeof products[0]) => {
    addToCart(product, 1);
    addNotification(`${product.name} added to cart!`, 'success');
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/hero-organic-farm.jpg"
            alt="Organic Farm"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#2D5A27]/90 via-[#2D5A27]/70 to-transparent" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-2xl space-y-6">
            <div className="inline-flex items-center space-x-2 bg-[#D4A017]/20 backdrop-blur-sm px-4 py-2 rounded-full border border-[#D4A017]/30">
              <Leaf className="h-4 w-4 text-[#D4A017]" />
              <span className="text-[#D4A017] text-sm font-medium">
                {language === 'en' ? '100% Organic & Natural' : '100% जैविक और प्राकृतिक'}
              </span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-[#FAFAF5] leading-tight">
              {t('tagline')}
            </h1>
            <p className="text-lg text-[#F5F1E8]/90 max-w-xl">
              {language === 'en'
                ? 'Nature-based solutions crafted by students for sustainable agriculture. From vermicompost to traditional formulations, we have everything your farm needs.'
                : 'सतत कृषि के लिए छात्रों द्वारा बनाए गए प्रकृति-आधारित समाधान। वर्मीकंपोस्ट से पारंपरिक formulations तक, हमारे पास आपके खेत के लिए सब कुछ है।'}
            </p>
            <div className="flex flex-wrap gap-4 pt-2">
              <Link
                to="/products"
                className="inline-flex items-center space-x-2 bg-[#D4A017] text-[#3B2417] px-6 py-3 rounded-xl font-semibold hover:bg-[#D4A017]/90 transition-all duration-300 hover:scale-105 active:scale-95 shadow-lg"
              >
                <ShoppingCart className="h-5 w-5" />
                <span>{t('exploreProducts')}</span>
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/ai-doctor"
                className="inline-flex items-center space-x-2 bg-[#8FAE76] text-white px-6 py-3 rounded-xl font-semibold hover:bg-[#4A8C42] transition-all duration-300 hover:scale-105 active:scale-95 shadow-lg"
              >
                <Play className="h-5 w-5" />
                <span>{t('aiDoctor')}</span>
              </Link>
            </div>
            {/* QR Code */}
            <div className="mt-4 inline-flex items-center space-x-3 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-xl">
              <QRCodeSVG value={window.location.origin} size={64} level="M" />
              <div>
                <p className="text-sm font-medium text-[#FAFAF5]">{t('qrCodeAccess')}</p>
                <p className="text-xs text-[#F5F1E8]/70">Scan to shop organic products</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-[#2D5A27]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, idx) => (
              <div key={idx} className="text-center">
                <stat.icon className="h-8 w-8 text-[#D4A017] mx-auto mb-2" />
                <p className="text-2xl font-bold text-[#FAFAF5]">{stat.value}</p>
                <p className="text-sm text-[#F5F1E8]/70">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-[#F5F1E8]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-[#2D5A27] flex items-center justify-center space-x-2">
              <Leaf className="h-8 w-8 text-[#4A8C42]" />
              <span>{t('ourProducts')}</span>
            </h2>
            <p className="mt-2 text-[#5C3D2E]">
              {language === 'en' ? 'Premium organic inputs for your farm' : 'आपके खेत के लिए प्रीमियम जैविक इनपुट'}
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  activeCategory === cat
                    ? 'bg-[#2D5A27] text-white shadow-md'
                    : 'bg-white text-[#5C3D2E] hover:bg-[#8FAE76]/20'
                }`}
              >
                {cat === 'All' ? t('all') : cat}
              </button>
            ))}
          </div>

          {/* Product Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 overflow-hidden group"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-2 right-2 bg-[#8FAE76] text-white text-xs font-bold px-2 py-1 rounded-full">
                    {product.category}
                  </div>
                  {product.stock < 50 && (
                    <div className="absolute top-2 left-2 bg-[#C75B39] text-white text-xs font-bold px-2 py-1 rounded-full">
                      {t('lowStock')}
                    </div>
                  )}
                </div>
                <div className="p-4 space-y-3">
                  <h3 className="font-semibold text-[#3B2417] text-lg">{product.name}</h3>
                  <div className="flex items-center space-x-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'text-[#D4A017] fill-[#D4A017]' : 'text-gray-300'}`}
                      />
                    ))}
                    <span className="text-xs text-gray-500 ml-1">({product.rating})</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xl font-bold text-[#2D5A27]">
                      Rs. {product.price}
                      <span className="text-sm font-normal text-gray-500">/{product.unit}</span>
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleAddToCart(product)}
                      className="flex-1 flex items-center justify-center space-x-1 bg-[#2D5A27] text-white py-2 rounded-lg hover:bg-[#4A8C42] transition-all duration-200 active:scale-95 text-sm font-medium"
                    >
                      <ShoppingCart className="h-4 w-4" />
                      <span>{t('addToCart')}</span>
                    </button>
                    <Link
                      to={`/products?id=${product.id}`}
                      className="flex items-center justify-center bg-[#D4A017] text-[#3B2417] px-3 py-2 rounded-lg hover:bg-[#D4A017]/80 transition-all duration-200 active:scale-95"
                    >
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-8">
            <Link
              to="/products"
              className="inline-flex items-center space-x-2 bg-[#2D5A27] text-white px-6 py-3 rounded-xl font-semibold hover:bg-[#4A8C42] transition-all duration-300 hover:scale-105 active:scale-95"
            >
              <span>{language === 'en' ? 'View All Products' : 'सभी उत्पाद देखें'}</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Categories Showcase */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-[#2D5A27]">
              {language === 'en' ? 'Product Categories' : 'उत्पाद श्रेणियां'}
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                title: language === 'en' ? 'Vermicomposting Products' : 'वर्मीकंपोस्टिंग उत्पाद',
                desc: language === 'en' ? 'Earthworms, vermicompost, vermiwash and complete kits for organic waste management and soil enrichment.' : 'जैविक अपशिष्ट प्रबंधन और मिट्टी समृद्धि के लिए अर्थवर्म, वर्मीकंपोस्ट, वर्मीवाश और संपूर्ण किट।',
                image: '/product-vermicompost.jpg',
                products: ['Earthworm', 'Vermicompost', 'Vermiwash', 'Vermicomposting Kit'],
              },
              {
                title: language === 'en' ? 'Traditional Formulations' : 'पारंपरिक formulations',
                desc: language === 'en' ? 'Ancient wisdom-based organic pesticides and growth promoters - Bramastra, Neemastra, Agniastra and more.' : 'प्राचीन ज्ञान-आधारित जैविक कीटनाशक और विकास प्रोत्साहक - ब्रह्मास्त्र, नीमास्त्र, अग्नास्त्र और अधिक।',
                image: '/product-bramastra.jpg',
                products: ['Bramastra', 'Neemastra', 'Agniastra', 'Panchparni'],
              },
              {
                title: language === 'en' ? 'Growth Solutions' : 'विकास समाधान',
                desc: language === 'en' ? 'Jeevamrit, Panchgavya, Beejamrit and other growth enhancers for healthy plant development.' : 'स्वस्थ पौध विकास के लिए जीवामृत, पंचगव्य, बीजामृत और अन्य विकास बूस्टर।',
                image: '/product-jeevamrit.jpg',
                products: ['Jeevamrit', 'Panchgavya', 'Beejamrit', 'Amrit Pani'],
              },
              {
                title: language === 'en' ? 'Bio-Fertilizers' : 'जैव-उर्वरक',
                desc: language === 'en' ? 'Blue Green Algae and other microbial fertilizers for natural nitrogen fixation.' : 'प्राकृतिक नाइट्रोजन स्थिरीकरण के लिए ब्लू ग्रीन एल्गी और अन्य सूक्ष्म जीव उर्वरक।',
                image: '/product-bga.jpg',
                products: ['BGA (Blue Green Algae)'],
              },
            ].map((cat, idx) => (
              <div
                key={idx}
                className="flex flex-col sm:flex-row bg-[#F5F1E8] rounded-2xl overflow-hidden shadow-md hover:shadow-lg transition-all duration-300"
              >
                <div className="sm:w-2/5 h-48 sm:h-auto">
                  <img src={cat.image} alt={cat.title} className="w-full h-full object-cover" />
                </div>
                <div className="sm:w-3/5 p-6 flex flex-col justify-center">
                  <h3 className="text-xl font-bold text-[#2D5A27] mb-2">{cat.title}</h3>
                  <p className="text-sm text-[#5C3D2E] mb-4">{cat.desc}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {cat.products.map((p, i) => (
                      <span key={i} className="bg-[#8FAE76]/20 text-[#2D5A27] text-xs font-medium px-2 py-1 rounded-full">
                        {p}
                      </span>
                    ))}
                  </div>
                  <Link
                    to="/products"
                    className="text-[#D4A017] font-semibold text-sm flex items-center space-x-1 hover:underline"
                  >
                    <span>{t('exploreProducts')}</span>
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-[#F5F1E8]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-[#2D5A27]">{t('whyChooseUs')}</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, idx) => (
              <div
                key={idx}
                className="bg-white rounded-xl p-6 text-center shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                <div className="w-14 h-14 bg-[#8FAE76]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="h-8 w-8 text-[#2D5A27]" />
                </div>
                <h3 className="font-semibold text-[#3B2417] mb-2">{feature.title}</h3>
                <p className="text-sm text-[#5C3D2E]">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AI Doctor Promo */}
      <section className="py-16 bg-[#2D5A27]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <img
                src="/ai-doctor.jpg"
                alt="AI Plant Doctor"
                className="rounded-2xl shadow-2xl w-full max-w-md mx-auto"
              />
            </div>
            <div className="md:w-1/2 space-y-6">
              <div className="inline-flex items-center space-x-2 bg-[#D4A017]/20 px-4 py-2 rounded-full">
                <Bot className="h-4 w-4 text-[#D4A017]" />
                <span className="text-[#D4A017] text-sm font-medium">AI Powered</span>
              </div>
              <h2 className="text-3xl font-bold text-[#FAFAF5]">
                {language === 'en' ? 'AI Plant Doctor - Diagnose & Get Solutions' : 'एआई प्लांट डॉक्टर - निदान और समाधान'}
              </h2>
              <ul className="space-y-3">
                {[
                  language === 'en' ? 'Upload photo of plant problem' : 'पौधे की समस्या की फोटो अपलोड करें',
                  language === 'en' ? 'Get instant AI diagnosis' : 'त्वरित एआई निदान प्राप्त करें',
                  language === 'en' ? 'Receive organic treatment suggestions' : 'जैविक उपचार सुझाव प्राप्त करें',
                  language === 'en' ? 'Works in Hindi & English' : 'हिंदी और अंग्रेजी में काम करता है',
                ].map((item, i) => (
                  <li key={i} className="flex items-center space-x-3 text-[#F5F1E8]">
                    <CheckCircle className="h-5 w-5 text-[#D4A017] flex-shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <Link
                to="/ai-doctor"
                className="inline-flex items-center space-x-2 bg-[#D4A017] text-[#3B2417] px-6 py-3 rounded-xl font-semibold hover:bg-[#D4A017]/90 transition-all duration-300 hover:scale-105 active:scale-95 shadow-lg"
              >
                <Stethoscope className="h-5 w-5" />
                <span>{language === 'en' ? 'Try AI Doctor Now' : 'अभी एआई डॉक्टर आजमाएं'}</span>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-[#F5F1E8]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-[#2D5A27]">{t('testimonials')}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, idx) => (
              <div
                key={idx}
                className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all duration-300"
              >
                <div className="flex items-center space-x-1 mb-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-[#D4A017] fill-[#D4A017]" />
                  ))}
                </div>
                <p className="text-[#5C3D2E] mb-4 italic">"{testimonial.quote}"</p>
                <div className="flex items-center space-x-3">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="h-12 w-12 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-semibold text-[#3B2417]">{testimonial.name}</p>
                    <p className="text-xs text-[#5C3D2E]">Farmer</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
