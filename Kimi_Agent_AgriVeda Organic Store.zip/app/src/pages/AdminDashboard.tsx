import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from '@/hooks/useTranslation';
import { useApp } from '@/context/AppContext';
import { products, expenseCategories } from '@/data/products';
import { sendWhatsAppBill, printBill } from '@/utils/helpers';
import { Sale, Expense, Student, Product, InventoryLog } from '@/types';
import {
  LayoutDashboard, TrendingUp, TrendingDown, ShoppingBag, IndianRupee,
  Users, Package, BarChart3, Settings, LogOut, Search, Filter,
  Download, Plus, Trash2, Edit2, Save, X, ChevronDown, ChevronUp,
  ArrowUpDown, Eye, Printer, MessageCircle, Leaf, Loader2,
  Shield, Bell, Database, Globe, QrCode, Barcode,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, AreaChart, Area,
} from 'recharts';
import { QRCodeSVG } from 'qrcode.react';

const COLORS = ['#2D5A27', '#8FAE76', '#D4A017', '#5B8DB8', '#C75B39', '#4A8C42'];

type Tab = 'dashboard' | 'sales' | 'expenses' | 'students' | 'products' | 'inventory' | 'analytics' | 'settings';

export default function AdminDashboard() {
  const { t, language } = useTranslation();
  const navigate = useNavigate();
  const {
    isAdminLoggedIn, logoutAdmin, sales, expenses, students, products: storeProducts,
    deleteSale, addExpense, deleteExpense, addStudent, removeStudent, toggleStudentStatus,
    updateProduct, inventory, addInventoryLog, exportToExcel, addNotification, generateOrderId,
  } = useApp();

  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Form states
  const [expenseForm, setExpenseForm] = useState({ category: '', amount: '', description: '', date: new Date().toISOString().slice(0, 10) });
  const [studentForm, setStudentForm] = useState({ name: '', phone: '', accessCode: '' });
  const [inventoryForm, setInventoryForm] = useState({ productId: '', change: '', reason: '' });
  const [searchSale, setSearchSale] = useState('');
  const [dateRange, setDateRange] = useState('month');

  useEffect(() => {
    if (!isAdminLoggedIn) {
      navigate('/admin');
    }
  }, [isAdminLoggedIn, navigate]);

  if (!isAdminLoggedIn) return null;

  // Computed data
  const totalRevenue = sales.reduce((sum, s) => sum + s.totalAmount, 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const netProfit = totalRevenue - totalExpenses;
  const totalOrders = sales.length;

  const filteredSales = sales.filter(s => {
    const matchesSearch = !searchSale || s.orderId.toLowerCase().includes(searchSale.toLowerCase()) || s.buyerName.toLowerCase().includes(searchSale.toLowerCase());
    const saleDate = new Date(s.date);
    const now = new Date();
    let matchesDate = true;
    if (dateRange === 'today') {
      matchesDate = saleDate.toDateString() === now.toDateString();
    } else if (dateRange === 'week') {
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      matchesDate = saleDate >= weekAgo;
    } else if (dateRange === 'month') {
      matchesDate = saleDate.getMonth() === now.getMonth() && saleDate.getFullYear() === now.getFullYear();
    }
    return matchesSearch && matchesDate;
  });

  // Chart data
  const salesByProduct = products.map(p => ({
    name: p.name.length > 15 ? p.name.slice(0, 15) + '...' : p.name,
    sales: sales.filter(s => s.productId === p.id).reduce((sum, s) => sum + s.totalAmount, 0),
    quantity: sales.filter(s => s.productId === p.id).reduce((sum, s) => sum + s.quantity, 0),
  })).filter(p => p.sales > 0).sort((a, b) => b.sales - a.sales).slice(0, 8);

  const salesByDate = (() => {
    const grouped: Record<string, number> = {};
    sales.forEach(s => {
      const date = new Date(s.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
      grouped[date] = (grouped[date] || 0) + s.totalAmount;
    });
    return Object.entries(grouped).slice(-7).map(([date, amount]) => ({ date, amount }));
  })();

  const paymentDistribution = [
    { name: 'Cash', value: sales.filter(s => s.paymentMode === 'Cash').length },
    { name: 'UPI', value: sales.filter(s => s.paymentMode === 'UPI').length },
  ].filter(p => p.value > 0);

  const expenseByCategory = expenseCategories.map(cat => ({
    name: cat,
    amount: expenses.filter(e => e.category === cat).reduce((sum, e) => sum + e.amount, 0),
  })).filter(e => e.amount > 0);

  const studentPerformance = students.map(s => ({
    name: s.name,
    sales: sales.filter(sa => sa.studentId === s.id).reduce((sum, sa) => sum + sa.totalAmount, 0),
    orders: sales.filter(sa => sa.studentId === s.id).length,
  })).filter(s => s.sales > 0).sort((a, b) => b.sales - a.sales);

  const financialData = (() => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return months.map((month, idx) => {
      const monthSales = sales.filter(s => new Date(s.date).getMonth() === idx).reduce((sum, s) => sum + s.totalAmount, 0);
      const monthExpenses = expenses.filter(e => new Date(e.date).getMonth() === idx).reduce((sum, e) => sum + e.amount, 0);
      return { month, income: monthSales, expense: monthExpenses };
    });
  })();

  const tabs: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
    { id: 'dashboard', label: language === 'en' ? 'Dashboard' : 'डैशबोर्ड', icon: LayoutDashboard },
    { id: 'sales', label: t('sales'), icon: ShoppingBag },
    { id: 'expenses', label: t('expenses'), icon: TrendingDown },
    { id: 'students', label: t('students'), icon: Users },
    { id: 'products', label: t('products'), icon: Package },
    { id: 'inventory', label: t('inventory'), icon: Barcode },
    { id: 'analytics', label: t('analytics'), icon: BarChart3 },
    { id: 'settings', label: t('settings'), icon: Settings },
  ];

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseForm.category || !expenseForm.amount) return;
    const expense: Expense = {
      id: Date.now().toString(),
      category: expenseForm.category,
      amount: Number(expenseForm.amount),
      description: expenseForm.description,
      date: expenseForm.date,
    };
    addExpense(expense);
    setExpenseForm({ category: '', amount: '', description: '', date: new Date().toISOString().slice(0, 10) });
    addNotification('Expense added!', 'success');
  };

  const handleAddStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentForm.name || !studentForm.accessCode) return;
    const student: Student = {
      id: `STU${Date.now().toString().slice(-6)}`,
      name: studentForm.name,
      phone: studentForm.phone,
      accessCode: studentForm.accessCode,
      active: true,
      totalSales: 0,
      totalRevenue: 0,
    };
    addStudent(student);
    setStudentForm({ name: '', phone: '', accessCode: '' });
    addNotification('Student added!', 'success');
  };

  const handleInventoryUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inventoryForm.productId || !inventoryForm.change) return;
    const product = storeProducts.find(p => p.id === Number(inventoryForm.productId));
    if (!product) return;
    const log: InventoryLog = {
      id: Date.now().toString(),
      productId: product.id,
      productName: product.name,
      change: Number(inventoryForm.change),
      reason: inventoryForm.reason,
      date: new Date().toISOString(),
    };
    addInventoryLog(log);
    setInventoryForm({ productId: '', change: '', reason: '' });
    addNotification('Inventory updated!', 'success');
  };

  const handleExportSales = () => {
    exportToExcel(filteredSales, 'sales_report');
    addNotification('Sales exported!', 'success');
  };

  const handleExportExpenses = () => {
    exportToExcel(expenses, 'expenses_report');
    addNotification('Expenses exported!', 'success');
  };

  const handleDeleteSale = (id: string) => {
    if (confirm('Are you sure?')) {
      deleteSale(id);
      addNotification('Sale deleted!', 'info');
    }
  };

  const handleDeleteExpense = (id: string) => {
    if (confirm('Are you sure?')) {
      deleteExpense(id);
      addNotification('Expense deleted!', 'info');
    }
  };

  const handleDeleteStudent = (id: string) => {
    if (confirm('Are you sure?')) {
      removeStudent(id);
      addNotification('Student removed!', 'info');
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F1E8] flex">
      {/* Sidebar */}
      <aside className={`bg-[#2D5A27] text-white w-64 flex-shrink-0 ${sidebarOpen ? 'fixed inset-y-0 left-0 z-50' : 'hidden lg:block'} transition-all`}>
        <div className="p-4">
          <div className="flex items-center space-x-2 mb-8">
            <LayoutDashboard className="h-6 w-6 text-[#D4A017]" />
            <span className="font-bold text-lg">{language === 'en' ? 'Admin Panel' : 'एडमिन पैनल'}</span>
          </div>
          <nav className="space-y-1">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id); setSidebarOpen(false); }}
                className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                  activeTab === tab.id ? 'bg-[#4A8C42] font-medium' : 'hover:bg-[#4A8C42]/50'
                }`}
              >
                <tab.icon className="h-4 w-4" />
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
          <div className="mt-8 pt-4 border-t border-[#4A8C42]">
            <button
              onClick={() => { logoutAdmin(); navigate('/'); }}
              className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm hover:bg-red-500/20 transition-all"
            >
              <LogOut className="h-4 w-4" />
              <span>{t('logout')}</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main Content */}
      <div className="flex-1 min-w-0">
        {/* Top bar */}
        <div className="bg-white shadow-sm px-4 py-3 flex items-center justify-between lg:justify-end">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 rounded-lg hover:bg-gray-100">
            <LayoutDashboard className="h-5 w-5 text-[#2D5A27]" />
          </button>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="text-sm font-medium text-[#3B2417]">Admin</p>
              <p className="text-xs text-gray-500">7877612427</p>
            </div>
            <div className="w-8 h-8 bg-[#2D5A27] rounded-full flex items-center justify-center">
              <Shield className="h-4 w-4 text-white" />
            </div>
          </div>
        </div>

        <div className="p-4 lg:p-6">
          {/* DASHBOARD TAB */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              <h1 className="text-2xl font-bold text-[#2D5A27]">{language === 'en' ? 'Dashboard' : 'डैशबोर्ड'}</h1>
              {/* Stats Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: t('totalRevenue'), value: `Rs. ${totalRevenue.toLocaleString()}`, icon: IndianRupee, color: 'text-[#D4A017]', bg: 'bg-[#D4A017]/10' },
                  { label: t('totalOrders'), value: totalOrders.toString(), icon: ShoppingBag, color: 'text-[#2D5A27]', bg: 'bg-[#2D5A27]/10' },
                  { label: t('totalExpenses'), value: `Rs. ${totalExpenses.toLocaleString()}`, icon: TrendingDown, color: 'text-[#C75B39]', bg: 'bg-[#C75B39]/10' },
                  { label: t('netProfit'), value: `Rs. ${netProfit.toLocaleString()}`, icon: TrendingUp, color: netProfit >= 0 ? 'text-[#4A8C42]' : 'text-[#C75B39]', bg: netProfit >= 0 ? 'bg-[#4A8C42]/10' : 'bg-[#C75B39]/10' },
                ].map((stat, idx) => (
                  <div key={idx} className="bg-white rounded-xl p-4 shadow-sm">
                    <div className={`w-10 h-10 ${stat.bg} rounded-lg flex items-center justify-center mb-2`}>
                      <stat.icon className={`h-5 w-5 ${stat.color}`} />
                    </div>
                    <p className="text-xs text-gray-500">{stat.label}</p>
                    <p className="text-xl font-bold text-[#3B2417]">{stat.value}</p>
                  </div>
                ))}
              </div>

              {/* Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl p-4 shadow-sm">
                  <h3 className="font-semibold text-[#3B2417] mb-4">{language === 'en' ? 'Sales Trend (Last 7 Days)' : 'बिक्री प्रवृत्ति'}</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={salesByDate}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Area type="monotone" dataKey="amount" stroke="#2D5A27" fill="#8FAE76" fillOpacity={0.3} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                <div className="bg-white rounded-xl p-4 shadow-sm">
                  <h3 className="font-semibold text-[#3B2417] mb-4">{language === 'en' ? 'Top Products' : 'शीर्ष उत्पाद'}</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={salesByProduct} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" tick={{ fontSize: 12 }} />
                      <YAxis dataKey="name" type="category" tick={{ fontSize: 11 }} width={100} />
                      <Tooltip />
                      <Bar dataKey="sales" fill="#2D5A27" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Recent Sales */}
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="px-4 py-3 border-b flex items-center justify-between">
                  <h3 className="font-semibold text-[#3B2417]">{language === 'en' ? 'Recent Sales' : 'हाल की बिक्री'}</h3>
                  <button onClick={() => setActiveTab('sales')} className="text-sm text-[#2D5A27] hover:underline">{t('view')}</button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-[#F5F1E8]">
                        <th className="px-4 py-2 text-left font-semibold">{t('orderId')}</th>
                        <th className="px-4 py-2 text-left font-semibold">{t('product')}</th>
                        <th className="px-4 py-2 text-left font-semibold">{t('buyerName')}</th>
                        <th className="px-4 py-2 text-right font-semibold">{t('totalAmount')}</th>
                        <th className="px-4 py-2 text-left font-semibold">{t('status')}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sales.slice(0, 5).map(sale => (
                        <tr key={sale.id} className="border-b hover:bg-gray-50">
                          <td className="px-4 py-2 font-mono text-[#2D5A27]">{sale.orderId}</td>
                          <td className="px-4 py-2">{sale.product}</td>
                          <td className="px-4 py-2">{sale.buyerName}</td>
                          <td className="px-4 py-2 text-right font-bold">Rs. {sale.totalAmount}</td>
                          <td className="px-4 py-2">
                            <span className={`px-2 py-0.5 rounded-full text-xs ${sale.paymentStatus === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                              {sale.paymentStatus}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SALES TAB */}
          {activeTab === 'sales' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <h1 className="text-2xl font-bold text-[#2D5A27]">{t('sales')}</h1>
                <div className="flex gap-2">
                  <select
                    value={dateRange}
                    onChange={(e) => setDateRange(e.target.value)}
                    className="px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  >
                    <option value="today">{t('today')}</option>
                    <option value="week">{t('thisWeek')}</option>
                    <option value="month">{t('thisMonth')}</option>
                    <option value="all">{t('all')}</option>
                  </select>
                  <button onClick={handleExportSales} className="flex items-center space-x-1 px-3 py-2 bg-[#2D5A27] text-white rounded-lg text-sm hover:bg-[#4A8C42] transition-all active:scale-95">
                    <Download className="h-4 w-4" />
                    <span>{t('exportExcel')}</span>
                  </button>
                </div>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder={`${t('search')} Order ID or Buyer...`}
                  value={searchSale}
                  onChange={(e) => setSearchSale(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                />
              </div>
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-[#F5F1E8]">
                        <th className="px-3 py-2 text-left font-semibold">{t('orderId')}</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('date')}</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('studentName')}</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('product')}</th>
                        <th className="px-3 py-2 text-right font-semibold">{t('totalAmount')}</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('buyerName')}</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('paymentMode')}</th>
                        <th className="px-3 py-2 text-center font-semibold">{t('actions')}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredSales.map(sale => (
                        <tr key={sale.id} className="border-b hover:bg-gray-50">
                          <td className="px-3 py-2 font-mono text-[#2D5A27] font-medium">{sale.orderId}</td>
                          <td className="px-3 py-2 text-gray-500">{new Date(sale.date).toLocaleDateString('en-IN')}</td>
                          <td className="px-3 py-2">{sale.studentName}</td>
                          <td className="px-3 py-2">{sale.product}</td>
                          <td className="px-3 py-2 text-right font-bold">Rs. {sale.totalAmount}</td>
                          <td className="px-3 py-2">{sale.buyerName}</td>
                          <td className="px-3 py-2">{sale.paymentMode}</td>
                          <td className="px-3 py-2">
                            <div className="flex items-center justify-center space-x-1">
                              <button onClick={() => sendWhatsAppBill(sale)} className="p-1.5 text-green-600 hover:bg-green-50 rounded" title="WhatsApp">
                                <MessageCircle className="h-4 w-4" />
                              </button>
                              <button onClick={() => printBill(sale)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded" title="Print">
                                <Printer className="h-4 w-4" />
                              </button>
                              <button onClick={() => handleDeleteSale(sale.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded" title="Delete">
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {filteredSales.length === 0 && <p className="text-center text-gray-500 py-8">{t('noData')}</p>}
              </div>
            </div>
          )}

          {/* EXPENSES TAB */}
          {activeTab === 'expenses' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h1 className="text-2xl font-bold text-[#2D5A27]">{t('expenses')}</h1>
                <button onClick={handleExportExpenses} className="flex items-center space-x-1 px-3 py-2 bg-[#2D5A27] text-white rounded-lg text-sm hover:bg-[#4A8C42] transition-all active:scale-95">
                  <Download className="h-4 w-4" />
                  <span>{t('exportExcel')}</span>
                </button>
              </div>
              <form onSubmit={handleAddExpense} className="bg-white rounded-xl p-4 shadow-sm space-y-3">
                <h3 className="font-semibold text-[#3B2417]">{t('addExpense')}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <select
                    value={expenseForm.category}
                    onChange={(e) => setExpenseForm(prev => ({ ...prev, category: e.target.value }))}
                    required
                    className="px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  >
                    <option value="">{t('select')} {t('expenseCategory')}</option>
                    {expenseCategories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    placeholder={t('expenseAmount')}
                    value={expenseForm.amount}
                    onChange={(e) => setExpenseForm(prev => ({ ...prev, amount: e.target.value }))}
                    required
                    className="px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  />
                  <input
                    type="text"
                    placeholder={t('expenseDescription')}
                    value={expenseForm.description}
                    onChange={(e) => setExpenseForm(prev => ({ ...prev, description: e.target.value }))}
                    className="px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  />
                  <input
                    type="date"
                    value={expenseForm.date}
                    onChange={(e) => setExpenseForm(prev => ({ ...prev, date: e.target.value }))}
                    className="px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  />
                </div>
                <button type="submit" className="flex items-center space-x-1 px-4 py-2 bg-[#C75B39] text-white rounded-lg hover:bg-[#B54D2E] transition-all active:scale-95">
                  <Plus className="h-4 w-4" />
                  <span>{t('addExpense')}</span>
                </button>
              </form>
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-[#F5F1E8]">
                        <th className="px-3 py-2 text-left font-semibold">{t('date')}</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('expenseCategory')}</th>
                        <th className="px-3 py-2 text-right font-semibold">{t('expenseAmount')}</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('expenseDescription')}</th>
                        <th className="px-3 py-2 text-center font-semibold">{t('actions')}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {expenses.map(expense => (
                        <tr key={expense.id} className="border-b hover:bg-gray-50">
                          <td className="px-3 py-2">{new Date(expense.date).toLocaleDateString('en-IN')}</td>
                          <td className="px-3 py-2">{expense.category}</td>
                          <td className="px-3 py-2 text-right font-bold text-[#C75B39]">Rs. {expense.amount}</td>
                          <td className="px-3 py-2">{expense.description}</td>
                          <td className="px-3 py-2 text-center">
                            <button onClick={() => handleDeleteExpense(expense.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded">
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {expenses.length === 0 && <p className="text-center text-gray-500 py-8">{t('noData')}</p>}
              </div>
              {expenseByCategory.length > 0 && (
                <div className="bg-white rounded-xl p-4 shadow-sm">
                  <h3 className="font-semibold text-[#3B2417] mb-4">{language === 'en' ? 'Expense by Category' : 'श्रेणी के अनुसार खर्च'}</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie data={expenseByCategory} dataKey="amount" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                        {expenseByCategory.map((_, idx) => (
                          <Cell key={idx} fill={COLORS[idx % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
          )}

          {/* STUDENTS TAB */}
          {activeTab === 'students' && (
            <div className="space-y-6">
              <h1 className="text-2xl font-bold text-[#2D5A27]">{t('students')}</h1>
              <form onSubmit={handleAddStudent} className="bg-white rounded-xl p-4 shadow-sm space-y-3">
                <h3 className="font-semibold text-[#3B2417]">{language === 'en' ? 'Add Student' : 'छात्र जोड़ें'}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <input
                    type="text"
                    placeholder={t('studentName')}
                    value={studentForm.name}
                    onChange={(e) => setStudentForm(prev => ({ ...prev, name: e.target.value }))}
                    required
                    className="px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  />
                  <input
                    type="tel"
                    placeholder={t('contactNumber')}
                    value={studentForm.phone}
                    onChange={(e) => setStudentForm(prev => ({ ...prev, phone: e.target.value }))}
                    className="px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  />
                  <input
                    type="text"
                    placeholder={t('accessCode')}
                    value={studentForm.accessCode}
                    onChange={(e) => setStudentForm(prev => ({ ...prev, accessCode: e.target.value }))}
                    required
                    className="px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  />
                  <button type="submit" className="flex items-center justify-center space-x-1 px-4 py-2 bg-[#2D5A27] text-white rounded-lg hover:bg-[#4A8C42] transition-all active:scale-95">
                    <Plus className="h-4 w-4" />
                    <span>{t('add')}</span>
                  </button>
                </div>
              </form>
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-[#F5F1E8]">
                        <th className="px-3 py-2 text-left font-semibold">ID</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('studentName')}</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('contactNumber')}</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('accessCode')}</th>
                        <th className="px-3 py-2 text-center font-semibold">{t('status')}</th>
                        <th className="px-3 py-2 text-center font-semibold">{t('actions')}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {students.map(student => (
                        <tr key={student.id} className="border-b hover:bg-gray-50">
                          <td className="px-3 py-2 font-mono">{student.id}</td>
                          <td className="px-3 py-2 font-medium">{student.name}</td>
                          <td className="px-3 py-2">{student.phone}</td>
                          <td className="px-3 py-2 font-mono text-[#D4A017]">{student.accessCode}</td>
                          <td className="px-3 py-2 text-center">
                            <button
                              onClick={() => toggleStudentStatus(student.id)}
                              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                                student.active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                              }`}
                            >
                              {student.active ? t('active') : t('inactive')}
                            </button>
                          </td>
                          <td className="px-3 py-2 text-center">
                            <button onClick={() => handleDeleteStudent(student.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded">
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* PRODUCTS TAB */}
          {activeTab === 'products' && (
            <div className="space-y-4">
              <h1 className="text-2xl font-bold text-[#2D5A27]">{t('products')}</h1>
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-[#F5F1E8]">
                        <th className="px-3 py-2 text-left font-semibold">ID</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('product')}</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('expenseCategory')}</th>
                        <th className="px-3 py-2 text-right font-semibold">{t('pricePerUnit')}</th>
                        <th className="px-3 py-2 text-right font-semibold">{t('stock')}</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('barcode')}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {storeProducts.map(product => (
                        <tr key={product.id} className="border-b hover:bg-gray-50">
                          <td className="px-3 py-2">{product.id}</td>
                          <td className="px-3 py-2 font-medium">{product.name}</td>
                          <td className="px-3 py-2">{product.category}</td>
                          <td className="px-3 py-2 text-right">Rs. {product.price}/{product.unit}</td>
                          <td className="px-3 py-2 text-right">
                            <span className={`font-medium ${product.stock < 50 ? 'text-[#C75B39]' : 'text-[#4A8C42]'}`}>
                              {product.stock}
                            </span>
                          </td>
                          <td className="px-3 py-2 font-mono text-xs">{product.barcode}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* INVENTORY TAB */}
          {activeTab === 'inventory' && (
            <div className="space-y-6">
              <h1 className="text-2xl font-bold text-[#2D5A27]">{t('inventory')}</h1>
              <form onSubmit={handleInventoryUpdate} className="bg-white rounded-xl p-4 shadow-sm space-y-3">
                <h3 className="font-semibold text-[#3B2417]">{t('stockAdjustment')}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <select
                    value={inventoryForm.productId}
                    onChange={(e) => setInventoryForm(prev => ({ ...prev, productId: e.target.value }))}
                    required
                    className="px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  >
                    <option value="">{t('select')} {t('product')}</option>
                    {storeProducts.map(p => (
                      <option key={p.id} value={p.id}>{p.name} ({p.stock})</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    placeholder={t('quantity') + ' (+/-)'}
                    value={inventoryForm.change}
                    onChange={(e) => setInventoryForm(prev => ({ ...prev, change: e.target.value }))}
                    required
                    className="px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  />
                  <input
                    type="text"
                    placeholder={t('reason')}
                    value={inventoryForm.reason}
                    onChange={(e) => setInventoryForm(prev => ({ ...prev, reason: e.target.value }))}
                    className="px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  />
                  <button type="submit" className="flex items-center justify-center space-x-1 px-4 py-2 bg-[#2D5A27] text-white rounded-lg hover:bg-[#4A8C42] transition-all active:scale-95">
                    <Save className="h-4 w-4" />
                    <span>{t('update')}</span>
                  </button>
                </div>
              </form>
              {/* Low Stock Alert */}
              {storeProducts.filter(p => p.stock < 50).length > 0 && (
                <div className="bg-[#C75B39]/10 border border-[#C75B39]/30 rounded-xl p-4">
                  <h3 className="font-semibold text-[#C75B39] flex items-center space-x-2 mb-2">
                    <TrendingDown className="h-5 w-5" />
                    <span>{t('lowStockAlert')}</span>
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {storeProducts.filter(p => p.stock < 50).map(p => (
                      <span key={p.id} className="bg-white px-3 py-1 rounded-full text-sm font-medium text-[#C75B39]">
                        {p.name}: {p.stock} left
                      </span>
                    ))}
                  </div>
                </div>
              )}
              {/* Inventory Log */}
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <h3 className="px-4 py-3 font-semibold text-[#3B2417] border-b">{t('inventoryHistory')}</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-[#F5F1E8]">
                        <th className="px-3 py-2 text-left font-semibold">{t('date')}</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('product')}</th>
                        <th className="px-3 py-2 text-right font-semibold">{t('quantity')}</th>
                        <th className="px-3 py-2 text-left font-semibold">{t('reason')}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {inventory.map(log => (
                        <tr key={log.id} className="border-b hover:bg-gray-50">
                          <td className="px-3 py-2 text-gray-500">{new Date(log.date).toLocaleDateString('en-IN')}</td>
                          <td className="px-3 py-2">{log.productName}</td>
                          <td className={`px-3 py-2 text-right font-medium ${log.change > 0 ? 'text-[#4A8C42]' : 'text-[#C75B39]'}`}>
                            {log.change > 0 ? '+' : ''}{log.change}
                          </td>
                          <td className="px-3 py-2">{log.reason}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {inventory.length === 0 && <p className="text-center text-gray-500 py-8">{t('noData')}</p>}
              </div>
            </div>
          )}

          {/* ANALYTICS TAB */}
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <h1 className="text-2xl font-bold text-[#2D5A27]">{t('analytics')}</h1>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl p-4 shadow-sm">
                  <h3 className="font-semibold text-[#3B2417] mb-4">{t('financialOverview')}</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={financialData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="income" fill="#2D5A27" name={t('income')} radius={[4, 4, 0, 0]} />
                      <Bar dataKey="expense" fill="#C75B39" name={t('expense')} radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="bg-white rounded-xl p-4 shadow-sm">
                  <h3 className="font-semibold text-[#3B2417] mb-4">{t('paymentDistribution')}</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie data={paymentDistribution} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                        {paymentDistribution.map((_, idx) => (
                          <Cell key={idx} fill={COLORS[idx % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="bg-white rounded-xl p-4 shadow-sm">
                  <h3 className="font-semibold text-[#3B2417] mb-4">{t('studentPerformance')}</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={studentPerformance} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" tick={{ fontSize: 12 }} />
                      <YAxis dataKey="name" type="category" tick={{ fontSize: 11 }} width={80} />
                      <Tooltip />
                      <Bar dataKey="sales" fill="#D4A017" name={t('totalRevenue')} radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="bg-white rounded-xl p-4 shadow-sm">
                  <h3 className="font-semibold text-[#3B2417] mb-4">{t('productPerformance')}</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={salesByProduct}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-45} textAnchor="end" height={80} />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Bar dataKey="quantity" fill="#8FAE76" name={t('quantity')} radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* SETTINGS TAB */}
          {activeTab === 'settings' && (
            <div className="space-y-6">
              <h1 className="text-2xl font-bold text-[#2D5A27]">{t('settings')}</h1>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl p-6 shadow-sm space-y-4">
                  <h3 className="font-semibold text-[#3B2417] flex items-center space-x-2">
                    <Shield className="h-5 w-5 text-[#2D5A27]" />
                    <span>{language === 'en' ? 'Admin Profile' : 'एडमिन प्रोफाइल'}</span>
                  </h3>
                  <div className="space-y-3">
                    <div>
                      <label className="text-sm text-gray-500">{t('adminPhone')}</label>
                      <p className="font-medium text-[#3B2417]">7877612427</p>
                    </div>
                    <div>
                      <label className="text-sm text-gray-500">{t('adminEmail')}</label>
                      <p className="font-medium text-[#3B2417]">sanjayrathorevbyl@gmail.com</p>
                    </div>
                    <div>
                      <label className="text-sm text-gray-500">{t('storeName')}</label>
                      <p className="font-medium text-[#3B2417]">AgriVeda Organic Store</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl p-6 shadow-sm space-y-4">
                  <h3 className="font-semibold text-[#3B2417] flex items-center space-x-2">
                    <Bell className="h-5 w-5 text-[#2D5A27]" />
                    <span>{t('notificationSettings')}</span>
                  </h3>
                  <div className="space-y-3">
                    {[
                      { label: t('newSaleNotification'), default: true },
                      { label: t('newExpenseNotification'), default: true },
                      { label: t('lowStockNotification'), default: true },
                      { label: t('autoWhatsAppBill'), default: false },
                    ].map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between">
                        <span className="text-sm text-[#3B2417]">{item.label}</span>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input type="checkbox" defaultChecked={item.default} className="sr-only peer" />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:ring-4 peer-focus:ring-[#8FAE76]/30 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#2D5A27]" />
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white rounded-xl p-6 shadow-sm space-y-4">
                  <h3 className="font-semibold text-[#3B2417] flex items-center space-x-2">
                    <Database className="h-5 w-5 text-[#2D5A27]" />
                    <span>{language === 'en' ? 'Data Management' : 'डेटा प्रबंधन'}</span>
                  </h3>
                  <div className="space-y-2">
                    <button
                      onClick={() => { exportToExcel(sales, 'all_sales'); addNotification('Data exported!', 'success'); }}
                      className="w-full flex items-center justify-center space-x-2 px-4 py-2.5 border border-[#2D5A27] text-[#2D5A27] rounded-lg hover:bg-[#2D5A27] hover:text-white transition-all text-sm active:scale-95"
                    >
                      <Download className="h-4 w-4" />
                      <span>{t('backupData')}</span>
                    </button>
                    <button
                      onClick={() => {
                        if (confirm('Clear all data? This cannot be undone!')) {
                          localStorage.clear();
                          window.location.reload();
                        }
                      }}
                      className="w-full flex items-center justify-center space-x-2 px-4 py-2.5 border border-red-300 text-red-600 rounded-lg hover:bg-red-50 transition-all text-sm active:scale-95"
                    >
                      <Trash2 className="h-4 w-4" />
                      <span>{language === 'en' ? 'Reset All Data' : 'सभी डेटा रीसेट करें'}</span>
                    </button>
                  </div>
                </div>

                <div className="bg-white rounded-xl p-6 shadow-sm space-y-4">
                  <h3 className="font-semibold text-[#3B2417] flex items-center space-x-2">
                    <QrCode className="h-5 w-5 text-[#2D5A27]" />
                    <span>{language === 'en' ? 'Store QR Code' : 'स्टोर QR कोड'}</span>
                  </h3>
                  <div className="text-center">
                    <div className="inline-block p-4 bg-white rounded-xl shadow-md">
                      <QRCodeSVG value={window.location.origin} size={150} level="H" />
                    </div>
                    <p className="text-sm text-gray-500 mt-2">{language === 'en' ? 'Scan to open store' : 'स्टोर खोलने के लिए स्कैन करें'}</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
