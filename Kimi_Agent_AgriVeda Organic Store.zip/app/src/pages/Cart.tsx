import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from '@/hooks/useTranslation';
import { useApp } from '@/context/AppContext';
import {
  ShoppingCart, Minus, Plus, Trash2, ArrowRight, Leaf, Gift,
} from 'lucide-react';

export default function Cart() {
  const { t } = useTranslation();
  const { cart, updateCartQuantity, removeFromCart, clearCart, loyaltyCustomers, addNotification } = useApp();
  const navigate = useNavigate();

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discount = subtotal > 1000 ? subtotal * 0.05 : 0;
  const total = subtotal - discount;
  const loyaltyPoints = Math.floor(total / 10);

  const handleCheckout = () => {
    if (cart.length === 0) {
      addNotification('Cart is empty!', 'error');
      return;
    }
    navigate('/checkout');
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-[#F5F1E8] flex items-center justify-center">
        <div className="text-center space-y-4">
          <ShoppingCart className="h-20 w-20 text-gray-300 mx-auto" />
          <h2 className="text-2xl font-bold text-[#3B2417]">{t('cart')}</h2>
          <p className="text-[#5C3D2E]">{t('noData')}</p>
          <Link
            to="/products"
            className="inline-flex items-center space-x-2 bg-[#2D5A27] text-white px-6 py-3 rounded-xl hover:bg-[#4A8C42] transition-all active:scale-95"
          >
            <Leaf className="h-5 w-5" />
            <span>{t('continueShopping')}</span>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F1E8] py-8">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-[#2D5A27] mb-6 flex items-center space-x-2">
          <ShoppingCart className="h-8 w-8" />
          <span>{t('cart')}</span>
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cart.map((item) => (
              <div
                key={item.product.id}
                className="bg-white rounded-xl p-4 shadow-md flex items-center space-x-4 hover:shadow-lg transition-shadow"
              >
                <img
                  src={item.product.image}
                  alt={item.product.name}
                  className="h-20 w-20 rounded-lg object-cover flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-[#3B2417] truncate">{item.product.name}</h3>
                  <p className="text-sm text-gray-500">{item.product.unit}</p>
                  <p className="text-[#2D5A27] font-bold">Rs. {item.product.price}</p>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                    className="w-8 h-8 rounded-lg bg-[#F5F1E8] flex items-center justify-center hover:bg-[#8FAE76]/20 transition-all active:scale-90"
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                  <span className="w-8 text-center font-bold">{item.quantity}</span>
                  <button
                    onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                    className="w-8 h-8 rounded-lg bg-[#F5F1E8] flex items-center justify-center hover:bg-[#8FAE76]/20 transition-all active:scale-90"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
                <div className="text-right min-w-[80px]">
                  <p className="font-bold text-[#2D5A27]">Rs. {item.product.price * item.quantity}</p>
                </div>
                <button
                  onClick={() => removeFromCart(item.product.id)}
                  className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all active:scale-90"
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            ))}

            <button
              onClick={clearCart}
              className="text-sm text-red-500 hover:text-red-700 transition-colors flex items-center space-x-1"
            >
              <Trash2 className="h-4 w-4" />
              <span>Clear Cart</span>
            </button>
          </div>

          {/* Order Summary */}
          <div className="space-y-4">
            <div className="bg-white rounded-xl p-6 shadow-md">
              <h3 className="font-bold text-[#3B2417] mb-4">{t('orderSummary')}</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-[#5C3D2E]">{t('subtotal')}</span>
                  <span className="font-medium">Rs. {subtotal.toFixed(2)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span className="flex items-center space-x-1">
                      <Gift className="h-4 w-4" />
                      <span>{t('discount')} (5%)</span>
                    </span>
                    <span className="font-medium">-Rs. {discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-[#D4A017]">
                  <span className="flex items-center space-x-1">
                    <Leaf className="h-4 w-4" />
                    <span>{t('loyaltyPoints')}</span>
                  </span>
                  <span className="font-medium">+{loyaltyPoints} pts</span>
                </div>
                <div className="border-t pt-3 flex justify-between font-bold text-lg">
                  <span>{t('total')}</span>
                  <span className="text-[#2D5A27]">Rs. {total.toFixed(2)}</span>
                </div>
              </div>
              <button
                onClick={handleCheckout}
                className="w-full mt-4 bg-[#D4A017] text-[#3B2417] py-3 rounded-xl font-semibold hover:bg-[#D4A017]/80 transition-all active:scale-95 flex items-center justify-center space-x-2"
              >
                <span>{t('proceedCheckout')}</span>
                <ArrowRight className="h-5 w-5" />
              </button>
              <Link
                to="/products"
                className="block text-center mt-3 text-sm text-[#5C3D2E] hover:text-[#2D5A27] transition-colors"
              >
                {t('continueShopping')}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
