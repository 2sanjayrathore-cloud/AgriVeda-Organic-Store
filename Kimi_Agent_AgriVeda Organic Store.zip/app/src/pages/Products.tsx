import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useTranslation } from '@/hooks/useTranslation';
import { useApp } from '@/context/AppContext';
import { products, categories } from '@/data/products';
import {
  Search, Filter, ShoppingCart, Star, ArrowRight, Minus, Plus, X,
  Barcode, CheckCircle,
} from 'lucide-react';

export default function Products() {
  const { t, language } = useTranslation();
  const { addToCart, addNotification } = useApp();
  const [searchParams] = useSearchParams();

  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [sortBy, setSortBy] = useState('name');
  const [selectedProduct, setSelectedProduct] = useState<typeof products[0] | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [barcodeInput, setBarcodeInput] = useState('');
  const [showBarcode, setShowBarcode] = useState(false);

  useEffect(() => {
    const id = searchParams.get('id');
    if (id) {
      const product = products.find(p => p.id === Number(id));
      if (product) setSelectedProduct(product);
    }
  }, [searchParams]);

  const filtered = products
    .filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.description.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = category === 'All' || p.category === category;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      return 0;
    });

  const handleAddToCart = (product: typeof products[0], qty: number) => {
    addToCart(product, qty);
    addNotification(`${product.name} x${qty} added to cart!`, 'success');
    setSelectedProduct(null);
    setQuantity(1);
  };

  const handleBarcodeSearch = () => {
    const product = products.find(p => p.barcode === barcodeInput || p.id === Number(barcodeInput));
    if (product) {
      setSelectedProduct(product);
      setShowBarcode(false);
      setBarcodeInput('');
    } else {
      addNotification('Product not found!', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F1E8] py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#2D5A27] mb-2">{t('products')}</h1>
          <p className="text-[#5C3D2E]">
            {language === 'en' ? `${filtered.length} organic products available` : `${filtered.length} जैविक उत्पाद उपलब्ध`}
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl p-4 shadow-md mb-6 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder={t('searchProducts')}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] focus:border-transparent outline-none transition-all"
              />
            </div>
            {/* Category */}
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="pl-10 pr-8 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none appearance-none bg-white min-w-[180px]"
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat === 'All' ? t('all') : cat}</option>
                ))}
              </select>
            </div>
            {/* Sort */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none bg-white min-w-[160px]"
            >
              <option value="name">{t('nameAZ')}</option>
              <option value="price-low">{t('priceLowHigh')}</option>
              <option value="price-high">{t('priceHighLow')}</option>
            </select>
            {/* Barcode */}
            <button
              onClick={() => setShowBarcode(!showBarcode)}
              className="flex items-center space-x-2 px-4 py-2.5 bg-[#8FAE76]/20 text-[#2D5A27] rounded-lg hover:bg-[#8FAE76]/30 transition-all active:scale-95"
            >
              <Barcode className="h-4 w-4" />
              <span className="text-sm font-medium">{t('scanBarcode')}</span>
            </button>
          </div>
          {showBarcode && (
            <div className="flex gap-2 pt-2 border-t">
              <input
                type="text"
                placeholder={t('enterManually')}
                value={barcodeInput}
                onChange={(e) => setBarcodeInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleBarcodeSearch()}
                className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                autoFocus
              />
              <button
                onClick={handleBarcodeSearch}
                className="px-4 py-2 bg-[#2D5A27] text-white rounded-lg hover:bg-[#4A8C42] transition-all active:scale-95"
              >
                {t('search')}
              </button>
            </div>
          )}
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filtered.map((product) => (
            <div
              key={product.id}
              onClick={() => { setSelectedProduct(product); setQuantity(1); }}
              className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 overflow-hidden cursor-pointer group"
            >
              <div className="relative h-52 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-2 left-2 bg-[#8FAE76] text-white text-xs font-bold px-2 py-1 rounded-full">
                  {product.category}
                </div>
                <div className="absolute top-2 right-2 bg-[#D4A017] text-[#3B2417] text-xs font-bold px-2 py-1 rounded-full">
                  {product.barcode}
                </div>
              </div>
              <div className="p-4 space-y-2">
                <h3 className="font-semibold text-[#3B2417] text-lg">{product.name}</h3>
                <p className="text-sm text-[#5C3D2E] line-clamp-2">{product.description}</p>
                <div className="flex items-center space-x-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`h-3.5 w-3.5 ${i < Math.floor(product.rating) ? 'text-[#D4A017] fill-[#D4A017]' : 'text-gray-300'}`}
                    />
                  ))}
                  <span className="text-xs text-gray-500">{product.rating}</span>
                </div>
                <div className="flex items-center justify-between pt-1">
                  <span className="text-lg font-bold text-[#2D5A27]">
                    Rs. {product.price}
                    <span className="text-xs font-normal text-gray-500">/{product.unit}</span>
                  </span>
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                    product.stock > 100 ? 'bg-green-100 text-green-700' :
                    product.stock > 20 ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'
                  }`}>
                    {product.stock > 20 ? `${product.stock} ${t('inStock')}` : t('lowStock')}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16">
            <Search className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <p className="text-xl text-gray-500">{t('noData')}</p>
          </div>
        )}
      </div>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setSelectedProduct(null)}>
          <div
            className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative">
              <img
                src={selectedProduct.image}
                alt={selectedProduct.name}
                className="w-full h-64 object-cover rounded-t-2xl"
              />
              <button
                onClick={() => setSelectedProduct(null)}
                className="absolute top-4 right-4 bg-white rounded-full p-2 shadow-lg hover:bg-gray-100 transition-all active:scale-90"
              >
                <X className="h-5 w-5" />
              </button>
              <div className="absolute bottom-4 left-4 bg-[#8FAE76] text-white text-sm font-bold px-3 py-1 rounded-full">
                {selectedProduct.category}
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-[#3B2417]">{selectedProduct.name}</h2>
                  <p className="text-sm text-gray-500">{selectedProduct.barcode}</p>
                </div>
                <div className="flex items-center space-x-1 bg-[#D4A017]/20 px-3 py-1 rounded-full">
                  <Star className="h-4 w-4 text-[#D4A017] fill-[#D4A017]" />
                  <span className="font-semibold text-[#3B2417]">{selectedProduct.rating}</span>
                </div>
              </div>

              <p className="text-[#5C3D2E] leading-relaxed">{selectedProduct.description}</p>

              <div className="flex items-center justify-between bg-[#F5F1E8] rounded-xl p-4">
                <div>
                  <p className="text-3xl font-bold text-[#2D5A27]">
                    Rs. {selectedProduct.price}
                    <span className="text-sm font-normal text-gray-500">/{selectedProduct.unit}</span>
                  </p>
                  <p className="text-sm text-gray-500">
                    {selectedProduct.stock > 0 ? `${selectedProduct.stock} units available` : 'Out of stock'}
                  </p>
                </div>
              </div>

              {/* Quantity Selector */}
              <div className="flex items-center space-x-4">
                <span className="font-medium text-[#3B2417]">{t('quantity')}:</span>
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 rounded-lg bg-[#F5F1E8] flex items-center justify-center hover:bg-[#8FAE76]/20 transition-all active:scale-90"
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                  <span className="text-xl font-bold w-8 text-center">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 rounded-lg bg-[#F5F1E8] flex items-center justify-center hover:bg-[#8FAE76]/20 transition-all active:scale-90"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
                <span className="text-lg font-bold text-[#2D5A27]">
                  Total: Rs. {selectedProduct.price * quantity}
                </span>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => handleAddToCart(selectedProduct, quantity)}
                  className="flex-1 flex items-center justify-center space-x-2 bg-[#2D5A27] text-white py-3 rounded-xl hover:bg-[#4A8C42] transition-all duration-200 active:scale-95 font-semibold"
                >
                  <ShoppingCart className="h-5 w-5" />
                  <span>{t('addToCart')}</span>
                </button>
                <button
                  onClick={() => handleAddToCart(selectedProduct, quantity)}
                  className="flex-1 flex items-center justify-center space-x-2 bg-[#D4A017] text-[#3B2417] py-3 rounded-xl hover:bg-[#D4A017]/80 transition-all duration-200 active:scale-95 font-semibold"
                >
                  <CheckCircle className="h-5 w-5" />
                  <span>{t('buyNow')}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
