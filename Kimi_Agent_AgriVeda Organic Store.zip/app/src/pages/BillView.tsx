import { useParams, useNavigate } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { sendWhatsAppBill, printBill } from '@/utils/helpers';
import {
  ArrowLeft, Printer, MessageCircle, Download, CheckCircle,
  ShoppingBag, Calendar, User, Phone, MapPin, CreditCard,
} from 'lucide-react';

export default function BillView() {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const { sales, addNotification } = useApp();

  const sale = sales.find(s => s.orderId === orderId);

  if (!sale) {
    return (
      <div className="min-h-screen bg-[#F5F1E8] flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl text-gray-500">Bill not found</p>
          <button onClick={() => navigate('/')} className="mt-4 text-[#2D5A27] hover:underline">Go Home</button>
        </div>
      </div>
    );
  }

  const handleWhatsApp = () => {
    sendWhatsAppBill(sale);
    addNotification('Bill sent on WhatsApp!', 'success');
  };

  const handlePrint = () => {
    printBill(sale);
  };

  const handleDownload = () => {
    const billHTML = `
<!DOCTYPE html>
<html><head><title>AgriVeda Bill ${sale.orderId}</title>
<style>
body{font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;color:#3B2417}
.header{text-align:center;border-bottom:3px solid #2D5A27;padding-bottom:20px;margin-bottom:20px}
.header h1{color:#2D5A27;margin:0;font-size:28px}
.header p{color:#5C3D2E;margin:5px 0}
.section{margin-bottom:15px}
.section h3{color:#2D5A27;border-bottom:1px solid #F5F1E8;padding-bottom:5px;font-size:16px}
.row{display:flex;justify-content:space-between;padding:5px 0}
.row.total{font-weight:bold;font-size:18px;border-top:2px solid #2D5A27;padding-top:10px;margin-top:10px;color:#2D5A27}
.footer{text-align:center;margin-top:30px;padding-top:20px;border-top:1px solid #F5F1E8;color:#5C3D2E}
.badge{display:inline-block;padding:3px 12px;border-radius:12px;font-size:12px;font-weight:bold}
.paid{background:#8FAE76;color:#fff}
.pending{background:#C75B39;color:#fff}
table{width:100%;border-collapse:collapse}
th,td{padding:8px;text-align:left;border-bottom:1px solid #F5F1E8}
th{background:#F5F1E8;font-weight:600;color:#2D5A27}
</style></head><body>
<div class="header">
<h1>AgriVeda Organic Store</h1>
<p>Pure Organic Inputs for Healthy Farming</p>
<p>Phone: 7877612427 | Email: sanjayrathorevbyl@gmail.com</p>
</div>
<div class="section">
<h3>Order Details</h3>
<div class="row"><span>Order ID:</span><span>${sale.orderId}</span></div>
<div class="row"><span>Date:</span><span>${new Date(sale.date).toLocaleString('en-IN')}</span></div>
</div>
<div class="section">
<h3>Seller Information</h3>
<div class="row"><span>Student Name:</span><span>${sale.studentName}</span></div>
<div class="row"><span>Student ID:</span><span>${sale.studentId}</span></div>
</div>
<div class="section">
<h3>Buyer Information</h3>
<div class="row"><span>Name:</span><span>${sale.buyerName}</span></div>
<div class="row"><span>Phone:</span><span>${sale.buyerPhone}</span></div>
${sale.buyerEmail ? `<div class="row"><span>Email:</span><span>${sale.buyerEmail}</span></div>` : ''}
${sale.buyerAddress ? `<div class="row"><span>Address:</span><span>${sale.buyerAddress}</span></div>` : ''}
</div>
<div class="section">
<h3>Product Details</h3>
<table>
<tr><th>Product</th><th>Qty</th><th>Price</th><th>Total</th></tr>
<tr><td>${sale.product}</td><td>${sale.quantity}</td><td>Rs. ${sale.pricePerUnit}</td><td>Rs. ${sale.totalAmount}</td></tr>
</table>
<div class="row total"><span>Total Amount:</span><span>Rs. ${sale.totalAmount}</span></div>
</div>
<div class="section">
<h3>Payment Information</h3>
<div class="row"><span>Payment Mode:</span><span>${sale.paymentMode}</span></div>
<div class="row"><span>Payment Status:</span><span class="badge ${sale.paymentStatus === 'Paid' ? 'paid' : 'pending'}">${sale.paymentStatus}</span></div>
<div class="row"><span>Amount Received:</span><span>Rs. ${sale.amountReceived}</span></div>
</div>
<div class="footer">
<p><strong>Thank you for choosing organic!</strong></p>
<p>Support sustainable farming with AgriVeda.</p>
<p style="font-size:11px;margin-top:10px">This is a computer generated bill.</p>
</div>
</body></html>`;
    const blob = new Blob([billHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AgriVeda_Bill_${sale.orderId}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    addNotification('Bill downloaded!', 'success');
  };

  return (
    <div className="min-h-screen bg-[#F5F1E8] py-8">
      <div className="max-w-2xl mx-auto px-4">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center space-x-1 text-[#5C3D2E] hover:text-[#2D5A27] mb-6 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back</span>
        </button>

        {/* Actions */}
        <div className="flex flex-wrap gap-2 mb-4">
          <button onClick={handleWhatsApp} className="flex items-center space-x-1 px-3 py-2 bg-green-500 text-white rounded-lg text-sm hover:bg-green-600 transition-all active:scale-95">
            <MessageCircle className="h-4 w-4" />
            <span>WhatsApp</span>
          </button>
          <button onClick={handlePrint} className="flex items-center space-x-1 px-3 py-2 bg-[#5B8DB8] text-white rounded-lg text-sm hover:bg-[#4A7BA7] transition-all active:scale-95">
            <Printer className="h-4 w-4" />
            <span>Print</span>
          </button>
          <button onClick={handleDownload} className="flex items-center space-x-1 px-3 py-2 bg-[#2D5A27] text-white rounded-lg text-sm hover:bg-[#4A8C42] transition-all active:scale-95">
            <Download className="h-4 w-4" />
            <span>Download PDF</span>
          </button>
        </div>

        {/* Bill */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#2D5A27] to-[#4A8C42] text-white p-6 text-center">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <ShoppingBag className="h-8 w-8 text-[#D4A017]" />
              <h1 className="text-2xl font-bold">AgriVeda Organic Store</h1>
            </div>
            <p className="text-white/80 text-sm">Pure Organic Inputs for Healthy Farming</p>
            <p className="text-white/60 text-xs mt-1">Phone: 7877612427 | sanjayrathorevbyl@gmail.com</p>
          </div>

          <div className="p-6 space-y-6">
            {/* Order Info */}
            <div className="flex items-center justify-between pb-4 border-b">
              <div>
                <p className="text-sm text-gray-500">Order ID</p>
                <p className="text-xl font-bold text-[#2D5A27] font-mono">{sale.orderId}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-500">Date</p>
                <p className="font-medium">{new Date(sale.date).toLocaleString('en-IN')}</p>
              </div>
            </div>

            {/* Seller */}
            <div>
              <h3 className="font-semibold text-[#3B2417] mb-2 flex items-center space-x-1">
                <User className="h-4 w-4 text-[#8FAE76]" />
                <span>Seller Information</span>
              </h3>
              <p className="text-sm"><span className="text-gray-500">Name:</span> {sale.studentName}</p>
              <p className="text-sm"><span className="text-gray-500">ID:</span> {sale.studentId}</p>
            </div>

            {/* Buyer */}
            <div>
              <h3 className="font-semibold text-[#3B2417] mb-2 flex items-center space-x-1">
                <User className="h-4 w-4 text-[#8FAE76]" />
                <span>Buyer Information</span>
              </h3>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <p><span className="text-gray-500">Name:</span> {sale.buyerName}</p>
                <p><span className="text-gray-500">Phone:</span> {sale.buyerPhone}</p>
                {sale.buyerEmail && <p><span className="text-gray-500">Email:</span> {sale.buyerEmail}</p>}
                {sale.buyerAddress && <p className="col-span-2"><span className="text-gray-500">Address:</span> {sale.buyerAddress}</p>}
              </div>
            </div>

            {/* Product */}
            <div>
              <h3 className="font-semibold text-[#3B2417] mb-2 flex items-center space-x-1">
                <ShoppingBag className="h-4 w-4 text-[#8FAE76]" />
                <span>Product Details</span>
              </h3>
              <table className="w-full text-sm">
                <thead className="bg-[#F5F1E8]">
                  <tr>
                    <th className="px-3 py-2 text-left font-semibold">Product</th>
                    <th className="px-3 py-2 text-right font-semibold">Qty</th>
                    <th className="px-3 py-2 text-right font-semibold">Price</th>
                    <th className="px-3 py-2 text-right font-semibold">Total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="px-3 py-3">{sale.product}</td>
                    <td className="px-3 py-3 text-right">{sale.quantity}</td>
                    <td className="px-3 py-3 text-right">Rs. {sale.pricePerUnit}</td>
                    <td className="px-3 py-3 text-right font-bold">Rs. {sale.totalAmount}</td>
                  </tr>
                </tbody>
              </table>
              <div className="flex justify-between items-center pt-3 border-t-2 border-[#2D5A27]">
                <span className="font-bold text-lg text-[#3B2417]">Total Amount</span>
                <span className="text-2xl font-bold text-[#2D5A27]">Rs. {sale.totalAmount}</span>
              </div>
            </div>

            {/* Payment */}
            <div>
              <h3 className="font-semibold text-[#3B2417] mb-2 flex items-center space-x-1">
                <CreditCard className="h-4 w-4 text-[#8FAE76]" />
                <span>Payment Information</span>
              </h3>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div className="bg-[#F5F1E8] rounded-lg p-3 text-center">
                  <p className="text-gray-500">Mode</p>
                  <p className="font-semibold">{sale.paymentMode}</p>
                </div>
                <div className="bg-[#F5F1E8] rounded-lg p-3 text-center">
                  <p className="text-gray-500">Status</p>
                  <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-bold ${sale.paymentStatus === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                    {sale.paymentStatus}
                  </span>
                </div>
                <div className="bg-[#F5F1E8] rounded-lg p-3 text-center">
                  <p className="text-gray-500">Received</p>
                  <p className="font-semibold">Rs. {sale.amountReceived}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="bg-[#F5F1E8] p-6 text-center">
            <p className="font-semibold text-[#2D5A27]">Thank you for choosing organic!</p>
            <p className="text-sm text-[#5C3D2E] mt-1">Support sustainable farming with AgriVeda.</p>
            <div className="mt-3 flex items-center justify-center space-x-1 text-xs text-gray-500">
              <CheckCircle className="h-3 w-3" />
              <span>Computer generated bill</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
