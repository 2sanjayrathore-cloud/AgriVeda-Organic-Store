import { useState, useEffect } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { useApp } from '@/context/AppContext';
import { products } from '@/data/products';
import { sendWhatsAppBill, printBill, formatPrice, formatDateTime } from '@/utils/helpers';
import { Sale } from '@/types';
import {
  GraduationCap, Lock, CheckCircle, Send, Printer, MessageCircle,
  Plus, Eye, Search, ArrowLeft, X,
  TrendingUp, ShoppingBag, IndianRupee, Loader2,
} from 'lucide-react';

export default function StudentPortal() {
  const { t, language } = useTranslation();
  const { currentStudent, loginStudent, logoutStudent, sales, addSale, generateOrderId, addNotification, userRole } = useApp();

  const [accessCode, setAccessCode] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [lastSale, setLastSale] = useState<Sale | null>(null);
  const [viewMode, setViewMode] = useState<'form' | 'history'>('form');
  const [filterProduct, setFilterProduct] = useState('');
  const [filterDate, setFilterDate] = useState('');

  const [formData, setFormData] = useState({
    productId: '',
    quantity: 1,
    buyerName: '',
    buyerPhone: '',
    buyerEmail: '',
    buyerAddress: '',
    paymentMode: 'Cash',
    paymentStatus: 'Paid',
    amountReceived: 0,
  });

  const selectedProduct = products.find(p => p.id === Number(formData.productId));
  const totalAmount = selectedProduct ? selectedProduct.price * formData.quantity : 0;

  const mySales = sales.filter(s => s.studentId === currentStudent?.id);
  const filteredSales = mySales.filter(s => {
    const matchesProduct = !filterProduct || s.product.toLowerCase().includes(filterProduct.toLowerCase());
    const matchesDate = !filterDate || s.date.startsWith(filterDate);
    return matchesProduct && matchesDate;
  });

  const totalRevenue = mySales.reduce((sum, s) => sum + s.totalAmount, 0);

  useEffect(() => {
    if (selectedProduct) {
      setFormData(prev => ({ ...prev, amountReceived: totalAmount }));
    }
  }, [formData.quantity, formData.productId, selectedProduct, totalAmount]);

  const handleLogin = () => {
    if (loginStudent(accessCode)) {
      addNotification('Login successful!', 'success');
    } else {
      addNotification('Invalid access code!', 'error');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct || !currentStudent) return;

    const sale: Sale = {
      id: Date.now().toString(),
      orderId: generateOrderId(),
      studentName: currentStudent.name,
      studentId: currentStudent.id,
      date: new Date().toISOString(),
      product: selectedProduct.name,
      productId: selectedProduct.id,
      quantity: formData.quantity,
      pricePerUnit: selectedProduct.price,
      totalAmount: totalAmount,
      buyerName: formData.buyerName,
      buyerPhone: formData.buyerPhone,
      buyerEmail: formData.buyerEmail,
      buyerAddress: formData.buyerAddress,
      paymentMode: formData.paymentMode,
      paymentStatus: formData.paymentStatus,
      amountReceived: formData.amountReceived,
    };

    addSale(sale);
    setLastSale(sale);
    setShowSuccess(true);

    // Reset form
    setFormData({
      productId: '',
      quantity: 1,
      buyerName: '',
      buyerPhone: '',
      buyerEmail: '',
      buyerAddress: '',
      paymentMode: 'Cash',
      paymentStatus: 'Paid',
      amountReceived: 0,
    });

    addNotification(`Sale recorded! Order ID: ${sale.orderId}`, 'success');
  };

  const handleWhatsApp = () => {
    if (lastSale) {
      sendWhatsAppBill(lastSale);
      addNotification('Bill sent on WhatsApp!', 'success');
    }
  };

  const handlePrint = () => {
    if (lastSale) {
      printBill(lastSale);
    }
  };

  const handleRecordAnother = () => {
    setShowSuccess(false);
    setLastSale(null);
  };

  // Login Gate
  if (userRole !== 'student' || !currentStudent) {
    return (
      <div className="min-h-screen bg-[#F5F1E8] flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl p-8 shadow-xl max-w-md w-full text-center space-y-6">
          <div className="w-20 h-20 bg-[#8FAE76]/20 rounded-full flex items-center justify-center mx-auto">
            <GraduationCap className="h-10 w-10 text-[#2D5A27]" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-[#2D5A27]">{t('studentPortal')}</h2>
            <p className="text-[#5C3D2E] mt-1">{t('onlyApprovedStudents')}</p>
          </div>
          <div className="space-y-3">
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="password"
                placeholder={t('accessCode')}
                value={accessCode}
                onChange={(e) => setAccessCode(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#2D5A27] outline-none text-center tracking-widest text-lg"
              />
            </div>
            <button
              onClick={handleLogin}
              className="w-full bg-[#2D5A27] text-white py-3 rounded-xl font-semibold hover:bg-[#4A8C42] transition-all active:scale-95"
            >
              {t('verify')}
            </button>
          </div>
          <p className="text-xs text-gray-500">{t('contactAdmin')}</p>
        </div>
      </div>
    );
  }

  // Success Modal
  if (showSuccess && lastSale) {
    return (
      <div className="min-h-screen bg-[#F5F1E8] flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl p-8 shadow-xl max-w-md w-full text-center space-y-4">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle className="h-10 w-10 text-[#4A8C42]" />
          </div>
          <h2 className="text-2xl font-bold text-[#2D5A27]">{t('saleRecorded')}</h2>
          <div className="bg-[#F5F1E8] rounded-xl p-4 text-left space-y-2">
            <p><span className="text-gray-500">{t('orderId')}:</span> <span className="font-bold text-[#2D5A27]">{lastSale.orderId}</span></p>
            <p><span className="text-gray-500">{t('product')}:</span> {lastSale.product}</p>
            <p><span className="text-gray-500">{t('quantity')}:</span> {lastSale.quantity}</p>
            <p><span className="text-gray-500">{t('totalAmount')}:</span> <span className="font-bold">Rs. {lastSale.totalAmount}</span></p>
            <p><span className="text-gray-500">{t('buyerName')}:</span> {lastSale.buyerName}</p>
          </div>
          <div className="space-y-2">
            <button
              onClick={handleWhatsApp}
              className="w-full flex items-center justify-center space-x-2 bg-green-500 text-white py-3 rounded-xl font-semibold hover:bg-green-600 transition-all active:scale-95"
            >
              <MessageCircle className="h-5 w-5" />
              <span>{t('sendWhatsApp')}</span>
            </button>
            <button
              onClick={handlePrint}
              className="w-full flex items-center justify-center space-x-2 bg-[#5B8DB8] text-white py-3 rounded-xl font-semibold hover:bg-[#4A7BA7] transition-all active:scale-95"
            >
              <Printer className="h-5 w-5" />
              <span>{t('printBill')}</span>
            </button>
            <button
              onClick={handleRecordAnother}
              className="w-full flex items-center justify-center space-x-2 bg-[#2D5A27] text-white py-3 rounded-xl font-semibold hover:bg-[#4A8C42] transition-all active:scale-95"
            >
              <Plus className="h-5 w-5" />
              <span>{t('recordAnother')}</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F1E8] py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-[#2D5A27] flex items-center space-x-2">
              <GraduationCap className="h-7 w-7" />
              <span>{t('studentPortal')}</span>
            </h1>
            <p className="text-sm text-[#5C3D2E]">{language === 'en' ? 'Welcome' : 'स्वागत है'}, {currentStudent.name}</p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewMode(viewMode === 'form' ? 'history' : 'form')}
              className="flex items-center space-x-1 px-4 py-2 bg-white rounded-lg shadow-sm hover:shadow-md transition-all text-sm font-medium text-[#2D5A27] active:scale-95"
            >
              {viewMode === 'form' ? <Eye className="h-4 w-4" /> : <ArrowLeft className="h-4 w-4" />}
              <span>{viewMode === 'form' ? t('viewSales') : t('back')}</span>
            </button>
            <button
              onClick={logoutStudent}
              className="px-4 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-all text-sm font-medium active:scale-95"
            >
              {t('logout')}
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-xl p-4 shadow-sm text-center">
            <ShoppingBag className="h-6 w-6 text-[#2D5A27] mx-auto mb-1" />
            <p className="text-2xl font-bold text-[#2D5A27]">{mySales.length}</p>
            <p className="text-xs text-gray-500">{language === 'en' ? 'Total Sales' : 'कुल बिक्री'}</p>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm text-center">
            <IndianRupee className="h-6 w-6 text-[#D4A017] mx-auto mb-1" />
            <p className="text-2xl font-bold text-[#D4A017]">Rs. {totalRevenue}</p>
            <p className="text-xs text-gray-500">{language === 'en' ? 'Revenue' : 'राजस्व'}</p>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm text-center">
            <TrendingUp className="h-6 w-6 text-[#8FAE76] mx-auto mb-1" />
            <p className="text-2xl font-bold text-[#4A8C42]">{mySales.filter(s => new Date(s.date).toISOString().slice(0, 7) === new Date().toISOString().slice(0, 7)).length}</p>
            <p className="text-xs text-gray-500">{t('thisMonth')}</p>
          </div>
        </div>

        {viewMode === 'form' ? (
          /* Sales Entry Form */
          <form onSubmit={handleSubmit} className="bg-white rounded-xl p-6 shadow-md space-y-4">
            <h2 className="text-xl font-bold text-[#2D5A27] mb-4">{t('recordSale')}</h2>

            {/* Order ID Display */}
            <div className="bg-[#F5F1E8] rounded-lg p-3 flex items-center justify-between">
              <span className="text-sm text-gray-500">{t('orderId')}</span>
              <span className="font-mono font-bold text-[#2D5A27]">{generateOrderId()}</span>
            </div>

            {/* Student & Date */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-[#5C3D2E]">{t('studentName')}</label>
                <input type="text" value={currentStudent.name} disabled className="w-full px-3 py-2 bg-gray-50 border rounded-lg text-gray-500" />
              </div>
              <div>
                <label className="text-sm font-medium text-[#5C3D2E]">{t('date')}</label>
                <input type="text" value={new Date().toLocaleDateString('en-IN')} disabled className="w-full px-3 py-2 bg-gray-50 border rounded-lg text-gray-500" />
              </div>
            </div>

            {/* Product Selection */}
            <div>
              <label className="text-sm font-medium text-[#5C3D2E]">{t('product')} <span className="text-red-500">*</span></label>
              <select
                value={formData.productId}
                onChange={(e) => setFormData(prev => ({ ...prev, productId: e.target.value }))}
                required
                className="w-full px-3 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
              >
                <option value="">{language === 'en' ? 'Select Product' : 'उत्पाद चुनें'}</option>
                {products.map(p => (
                  <option key={p.id} value={p.id}>{p.name} - Rs. {p.price}/{p.unit}</option>
                ))}
              </select>
            </div>

            {/* Quantity & Price */}
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-[#5C3D2E]">{t('quantity')} <span className="text-red-500">*</span></label>
                <input
                  type="number"
                  min={1}
                  value={formData.quantity}
                  onChange={(e) => setFormData(prev => ({ ...prev, quantity: Math.max(1, Number(e.target.value)) }))}
                  className="w-full px-3 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium text-[#5C3D2E]">{t('pricePerUnit')}</label>
                <input type="text" value={selectedProduct ? `Rs. ${selectedProduct.price}` : '-'} disabled className="w-full px-3 py-2.5 bg-gray-50 border rounded-lg text-gray-500" />
              </div>
              <div>
                <label className="text-sm font-medium text-[#5C3D2E]">{t('totalAmount')}</label>
                <input type="text" value={totalAmount > 0 ? `Rs. ${totalAmount}` : '-'} disabled className="w-full px-3 py-2.5 bg-[#8FAE76]/10 border border-[#8FAE76] rounded-lg font-bold text-[#2D5A27]" />
              </div>
            </div>

            {/* Buyer Info */}
            <div className="border-t pt-4">
              <h3 className="font-semibold text-[#3B2417] mb-3">{language === 'en' ? 'Buyer Information' : 'खरीदार की जानकारी'}</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-[#5C3D2E]">{t('buyerName')} <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    value={formData.buyerName}
                    onChange={(e) => setFormData(prev => ({ ...prev, buyerName: e.target.value }))}
                    required
                    className="w-full px-3 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-[#5C3D2E]">{t('contactNumber')} <span className="text-red-500">*</span></label>
                  <input
                    type="tel"
                    value={formData.buyerPhone}
                    onChange={(e) => setFormData(prev => ({ ...prev, buyerPhone: e.target.value }))}
                    required
                    className="w-full px-3 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                    placeholder="9876543210"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-3">
                <div>
                  <label className="text-sm font-medium text-[#5C3D2E]">{t('buyerEmail')}</label>
                  <input
                    type="email"
                    value={formData.buyerEmail}
                    onChange={(e) => setFormData(prev => ({ ...prev, buyerEmail: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-[#5C3D2E]">{t('address')}</label>
                  <input
                    type="text"
                    value={formData.buyerAddress}
                    onChange={(e) => setFormData(prev => ({ ...prev, buyerAddress: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Payment */}
            <div className="border-t pt-4">
              <h3 className="font-semibold text-[#3B2417] mb-3">{t('paymentMode')}</h3>
              <div className="grid grid-cols-3 gap-4">
                <select
                  value={formData.paymentMode}
                  onChange={(e) => setFormData(prev => ({ ...prev, paymentMode: e.target.value }))}
                  className="px-3 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                >
                  <option value="Cash">{t('cash')}</option>
                  <option value="UPI">{t('upi')}</option>
                </select>
                <select
                  value={formData.paymentStatus}
                  onChange={(e) => setFormData(prev => ({ ...prev, paymentStatus: e.target.value }))}
                  className="px-3 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                >
                  <option value="Paid">{t('paid')}</option>
                  <option value="Pending">{t('pending')}</option>
                </select>
                <div>
                  <input
                    type="number"
                    value={formData.amountReceived}
                    onChange={(e) => setFormData(prev => ({ ...prev, amountReceived: Number(e.target.value) }))}
                    className="w-full px-3 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none"
                    placeholder="Amount Received"
                  />
                </div>
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="w-full flex items-center justify-center space-x-2 bg-[#D4A017] text-[#3B2417] py-3 rounded-xl font-semibold hover:bg-[#D4A017]/80 transition-all active:scale-95 mt-4"
            >
              <Send className="h-5 w-5" />
              <span>{t('submit')}</span>
            </button>
          </form>
        ) : (
          /* Sales History */
          <div className="bg-white rounded-xl p-6 shadow-md">
            <h2 className="text-xl font-bold text-[#2D5A27] mb-4">{t('mySales')}</h2>
            <div className="flex gap-2 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder={t('searchProducts')}
                  value={filterProduct}
                  onChange={(e) => setFilterProduct(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none text-sm"
                />
              </div>
              <input
                type="date"
                value={filterDate}
                onChange={(e) => setFilterDate(e.target.value)}
                className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none text-sm"
              />
            </div>

            {filteredSales.length === 0 ? (
              <p className="text-center text-gray-500 py-8">{t('noData')}</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-[#F5F1E8] text-left">
                      <th className="px-3 py-2 font-semibold">{t('orderId')}</th>
                      <th className="px-3 py-2 font-semibold">{t('date')}</th>
                      <th className="px-3 py-2 font-semibold">{t('product')}</th>
                      <th className="px-3 py-2 font-semibold">{t('quantity')}</th>
                      <th className="px-3 py-2 font-semibold">{t('totalAmount')}</th>
                      <th className="px-3 py-2 font-semibold">{t('buyerName')}</th>
                      <th className="px-3 py-2 font-semibold">{t('paymentStatus')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredSales.map(sale => (
                      <tr key={sale.id} className="border-b hover:bg-gray-50">
                        <td className="px-3 py-2 font-mono text-[#2D5A27] font-medium">{sale.orderId}</td>
                        <td className="px-3 py-2 text-gray-500">{new Date(sale.date).toLocaleDateString('en-IN')}</td>
                        <td className="px-3 py-2">{sale.product}</td>
                        <td className="px-3 py-2">{sale.quantity}</td>
                        <td className="px-3 py-2 font-bold">Rs. {sale.totalAmount}</td>
                        <td className="px-3 py-2">{sale.buyerName}</td>
                        <td className="px-3 py-2">
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                            sale.paymentStatus === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                          }`}>
                            {sale.paymentStatus}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
