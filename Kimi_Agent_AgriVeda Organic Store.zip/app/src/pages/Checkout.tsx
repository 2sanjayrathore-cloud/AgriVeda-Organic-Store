import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from '@/hooks/useTranslation';
import { useApp } from '@/context/AppContext';
import { QRCodeSVG } from 'qrcode.react';
import {
  CreditCard, CheckCircle, ArrowLeft, Smartphone, Banknote,
  MapPin, User, Phone, Mail, Leaf, Loader2,
} from 'lucide-react';

export default function Checkout() {
  const { t, language } = useTranslation();
  const { cart, clearCart, addNotification, generateOrderId, addLoyaltyPoints } = useApp();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    paymentMode: 'cod',
  });
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);
  const [orderId, setOrderId] = useState('');

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discount = subtotal > 1000 ? subtotal * 0.05 : 0;
  const total = subtotal - discount;
  const loyaltyPoints = Math.floor(total / 10);

  const upiId = 'agrivedastore@upi';
  const upiUrl = `upi://pay?pa=${upiId}&pn=AgriVeda&am=${total.toFixed(2)}&cu=INR&tn=Order`;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handlePlaceOrder = async () => {
    if (!formData.name || !formData.phone || !formData.address) {
      addNotification('Please fill all required fields!', 'error');
      return;
    }

    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));

    const newOrderId = generateOrderId();
    setOrderId(newOrderId);

    // Add loyalty points
    addLoyaltyPoints(formData.phone, formData.name, loyaltyPoints, total);

    setIsProcessing(false);
    setOrderComplete(true);
    clearCart();
  };

  if (cart.length === 0 && !orderComplete) {
    navigate('/cart');
    return null;
  }

  if (orderComplete) {
    return (
      <div className="min-h-screen bg-[#F5F1E8] flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl p-8 shadow-xl text-center max-w-md w-full space-y-4">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle className="h-10 w-10 text-[#4A8C42]" />
          </div>
          <h2 className="text-2xl font-bold text-[#2D5A27]">{t('orderConfirmed')}</h2>
          <p className="text-[#5C3D2E]">{t('thankYou')}</p>
          <div className="bg-[#F5F1E8] rounded-xl p-4">
            <p className="text-sm text-[#5C3D2E]">{t('orderNumber')}</p>
            <p className="text-xl font-bold text-[#2D5A27]">{orderId}</p>
          </div>
          <div className="bg-[#D4A017]/10 rounded-xl p-3 flex items-center justify-center space-x-2">
            <Leaf className="h-5 w-5 text-[#D4A017]" />
            <span className="text-[#D4A017] font-medium">+{loyaltyPoints} Loyalty Points Earned!</span>
          </div>
          <button
            onClick={() => navigate('/')}
            className="w-full bg-[#2D5A27] text-white py-3 rounded-xl font-semibold hover:bg-[#4A8C42] transition-all active:scale-95"
          >
            {t('continueShopping')}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F1E8] py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <button
          onClick={() => navigate('/cart')}
          className="flex items-center space-x-1 text-[#5C3D2E] hover:text-[#2D5A27] mb-6 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>{t('back')}</span>
        </button>

        <h1 className="text-3xl font-bold text-[#2D5A27] mb-6">
          {language === 'en' ? 'Checkout' : 'चेकआउट'}
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Customer Info */}
          <div className="space-y-4">
            <div className="bg-white rounded-xl p-6 shadow-md">
              <h3 className="font-bold text-[#3B2417] mb-4 flex items-center space-x-2">
                <User className="h-5 w-5 text-[#2D5A27]" />
                <span>{language === 'en' ? 'Customer Information' : 'ग्राहक जानकारी'}</span>
              </h3>
              <div className="space-y-3">
                <div>
                  <label className="text-sm font-medium text-[#5C3D2E] flex items-center space-x-1">
                    <span>{t('buyerName')}</span>
                    <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none mt-1"
                    required
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-[#5C3D2E] flex items-center space-x-1">
                    <Phone className="h-4 w-4" />
                    <span>{t('contactNumber')}</span>
                    <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none mt-1"
                    required
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-[#5C3D2E] flex items-center space-x-1">
                    <Mail className="h-4 w-4" />
                    <span>{t('buyerEmail')}</span>
                    <span className="text-gray-400 text-xs">({t('optional')})</span>
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-[#5C3D2E] flex items-center space-x-1">
                    <MapPin className="h-4 w-4" />
                    <span>{t('address')}</span>
                    <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    rows={3}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#2D5A27] outline-none mt-1 resize-none"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Payment Method */}
            <div className="bg-white rounded-xl p-6 shadow-md">
              <h3 className="font-bold text-[#3B2417] mb-4 flex items-center space-x-2">
                <CreditCard className="h-5 w-5 text-[#2D5A27]" />
                <span>{t('paymentMode')}</span>
              </h3>
              <div className="space-y-2">
                <label className={`flex items-center space-x-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                  formData.paymentMode === 'cod' ? 'border-[#2D5A27] bg-[#8FAE76]/10' : 'border-gray-200'
                }`}>
                  <input
                    type="radio"
                    name="paymentMode"
                    value="cod"
                    checked={formData.paymentMode === 'cod'}
                    onChange={handleInputChange}
                    className="hidden"
                  />
                  <Banknote className="h-5 w-5 text-[#2D5A27]" />
                  <div>
                    <p className="font-medium text-[#3B2417]">{t('cash')}</p>
                    <p className="text-xs text-gray-500">{language === 'en' ? 'Pay on delivery' : 'डिलीवरी पर भुगतान'}</p>
                  </div>
                </label>
                <label className={`flex items-center space-x-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                  formData.paymentMode === 'upi' ? 'border-[#2D5A27] bg-[#8FAE76]/10' : 'border-gray-200'
                }`}>
                  <input
                    type="radio"
                    name="paymentMode"
                    value="upi"
                    checked={formData.paymentMode === 'upi'}
                    onChange={handleInputChange}
                    className="hidden"
                  />
                  <Smartphone className="h-5 w-5 text-[#2D5A27]" />
                  <div>
                    <p className="font-medium text-[#3B2417]">{t('upi')}</p>
                    <p className="text-xs text-gray-500">Scan QR to pay</p>
                  </div>
                </label>
              </div>
            </div>
          </div>

          {/* Order Summary & QR */}
          <div className="space-y-4">
            {formData.paymentMode === 'upi' && (
              <div className="bg-white rounded-xl p-6 shadow-md text-center">
                <h3 className="font-bold text-[#3B2417] mb-2">{language === 'en' ? 'Scan to Pay' : 'भुगतान के लिए स्कैन करें'}</h3>
                <p className="text-sm text-gray-500 mb-4">{language === 'en' ? 'Use any UPI app' : 'किसी भी यूपीआई ऐप का उपयोग करें'}</p>
                <div className="inline-block p-4 bg-white rounded-xl shadow-md">
                  <QRCodeSVG value={upiUrl} size={200} level="H" />
                </div>
                <p className="text-sm text-[#5C3D2E] mt-3">UPI ID: <span className="font-mono font-bold">{upiId}</span></p>
                <p className="text-lg font-bold text-[#2D5A27] mt-2">Rs. {total.toFixed(2)}</p>
              </div>
            )}

            <div className="bg-white rounded-xl p-6 shadow-md">
              <h3 className="font-bold text-[#3B2417] mb-4">{t('orderSummary')}</h3>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {cart.map((item) => (
                  <div key={item.product.id} className="flex justify-between text-sm">
                    <span className="text-[#5C3D2E]">{item.product.name} x{item.quantity}</span>
                    <span className="font-medium">Rs. {(item.product.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
              <div className="border-t mt-3 pt-3 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-[#5C3D2E]">{t('subtotal')}</span>
                  <span>Rs. {subtotal.toFixed(2)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>{t('discount')}</span>
                    <span>-Rs. {discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg pt-2 border-t">
                  <span>{t('total')}</span>
                  <span className="text-[#2D5A27]">Rs. {total.toFixed(2)}</span>
                </div>
              </div>
              <button
                onClick={handlePlaceOrder}
                disabled={isProcessing}
                className="w-full mt-4 bg-[#2D5A27] text-white py-3 rounded-xl font-semibold hover:bg-[#4A8C42] transition-all active:scale-95 disabled:opacity-70 flex items-center justify-center space-x-2"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    <span>{language === 'en' ? 'Processing...' : 'प्रोसेसिंग...'}</span>
                  </>
                ) : (
                  <>
                    <CheckCircle className="h-5 w-5" />
                    <span>{t('placeOrder')}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
