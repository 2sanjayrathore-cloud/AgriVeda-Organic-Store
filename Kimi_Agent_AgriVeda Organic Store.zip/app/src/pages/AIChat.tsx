import { useState, useRef, useEffect } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { useApp } from '@/context/AppContext';
import { getAIResponse } from '@/utils/helpers';
import {
  Bot, Send, Leaf, Loader2, Mic, Languages, User,
  Sprout, Bug, FlaskConical, CloudSun, Droplets, Shovel,
} from 'lucide-react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const quickPrompts = [
  { icon: FlaskConical, text: { en: 'How to make Jeevamrit?', hi: 'जीवामृत कैसे बनाएं?' } },
  { icon: Bug, text: { en: 'Pest control for tomatoes?', hi: 'टमाटर के लिए कीट नियंत्रण?' } },
  { icon: Sprout, text: { en: 'Best organic fertilizer?', hi: 'सर्वश्रेष्ठ जैविक उर्वरक?' } },
  { icon: CloudSun, text: { en: 'Disease in paddy leaves?', hi: 'धान के पत्तों में रोग?' } },
  { icon: Droplets, text: { en: 'How to use Panchgavya?', hi: 'पंचगव्य का उपयोग कैसे करें?' } },
  { icon: Shovel, text: { en: 'Soil improvement tips?', hi: 'मिट्टी सुधार के उपाय?' } },
];

export default function AIChat() {
  const { language, setLanguage } = useApp();
  const { t } = useTranslation();
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: language === 'en'
        ? `Hello! I'm your AI Farming Assistant. Ask me anything about organic farming, pest control, fertilizers, or plant diseases. I can help in both Hindi and English!`
        : `नमस्ते! मैं आपका एआई कृषि सहायक हूं। जैविक खेती, कीट नियंत्रण, उर्वरक, या पौध रोगों के बारे में कुछ भी पूछें। मैं हिंदी और अंग्रेजी दोनों में मदद कर सकता हूं!`,
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (text?: string) => {
    const message = text || input;
    if (!message.trim()) return;

    setMessages(prev => [...prev, { role: 'user', content: message }]);
    setInput('');
    setIsLoading(true);

    // Simulate AI thinking
    await new Promise(resolve => setTimeout(resolve, 1500));

    const response = getAIResponse(message, language as 'en' | 'hi');

    setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    setIsLoading(false);
  };

  const handleVoiceInput = () => {
    if (!('webkitSpeechRecognition' in window)) {
      alert('Voice input not supported in this browser.');
      return;
    }
    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput(transcript);
    };
    recognition.start();
  };

  const formatMessage = (content: string) => {
    const lines = content.split('\n');
    return lines.map((line, i) => {
      const trimmed = line.trim();
      if (trimmed === '') return <div key={i} className="h-1" />;

      // Headers
      if (trimmed.match(/^\*\*.*\*\*$/)) {
        return (
          <h3 key={i} className="font-bold text-[#2D5A27] mt-3 mb-1 text-sm">
            {trimmed.replace(/\*\*/g, '')}
          </h3>
        );
      }
      if (trimmed.match(/^#{1,3}\s/)) {
        return (
          <h3 key={i} className="font-bold text-[#2D5A27] mt-3 mb-1 text-sm">
            {trimmed.replace(/^#{1,3}\s/, '')}
          </h3>
        );
      }
      // Numbered lists
      if (trimmed.match(/^\d+[.\)]\s/)) {
        return (
          <div key={i} className="flex items-start space-x-2 ml-2">
            <span className="text-[#D4A017] font-bold text-xs mt-0.5">{trimmed.match(/^\d+/)?.[0]}.</span>
            <span className="text-sm">{trimmed.replace(/^\d+[.\)]\s/, '')}</span>
          </div>
        );
      }
      // Bullet points
      if (trimmed.startsWith('-') || trimmed.startsWith('*')) {
        return (
          <div key={i} className="flex items-start space-x-2 ml-2">
            <Leaf className="h-3 w-3 text-[#8FAE76] mt-1 flex-shrink-0" />
            <span className="text-sm">{trimmed.substring(1).trim()}</span>
          </div>
        );
      }
      // Bold inline
      if (trimmed.includes('**')) {
        const parts = trimmed.split(/(\*\*.*?\*\*)/g);
        return (
          <p key={i} className="text-sm">
            {parts.map((part, j) =>
              part.match(/^\*\*.*\*\*$/) ? (
                <strong key={j} className="text-[#2D5A27]">{part.replace(/\*\*/g, '')}</strong>
              ) : (
                <span key={j}>{part}</span>
              )
            )}
          </p>
        );
      }
      return <p key={i} className="text-sm">{trimmed}</p>;
    });
  };

  return (
    <div className="h-[calc(100vh-64px)] bg-[#F5F1E8] flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#2D5A27] to-[#4A8C42] text-white py-4">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <Bot className="h-5 w-5" />
              </div>
              <div>
                <h1 className="text-lg font-bold">{t('aiChat')}</h1>
                <p className="text-xs text-white/80">
                  {language === 'en' ? 'Your organic farming assistant' : 'आपका जैविक खेती सहायक'}
                </p>
              </div>
            </div>
            <button
              onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
              className="flex items-center space-x-1 bg-white/20 px-3 py-1.5 rounded-lg hover:bg-white/30 transition-all text-sm active:scale-95"
            >
              <Languages className="h-4 w-4" />
              <span>{language === 'en' ? 'Hindi' : 'English'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto space-y-4">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className="flex items-start space-x-2 max-w-[85%]">
                {msg.role === 'assistant' && (
                  <div className="w-8 h-8 bg-[#2D5A27] rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <Bot className="h-4 w-4 text-white" />
                  </div>
                )}
                <div
                  className={`rounded-2xl px-4 py-3 ${
                    msg.role === 'user'
                      ? 'bg-[#2D5A27] text-white rounded-br-sm'
                      : 'bg-white text-[#3B2417] rounded-bl-sm shadow-md'
                  }`}
                >
                  <div className="space-y-0.5">
                    {formatMessage(msg.content)}
                  </div>
                </div>
                {msg.role === 'user' && (
                  <div className="w-8 h-8 bg-[#D4A017] rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <User className="h-4 w-4 text-white" />
                  </div>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="flex items-start space-x-2">
                <div className="w-8 h-8 bg-[#2D5A27] rounded-full flex items-center justify-center flex-shrink-0">
                  <Bot className="h-4 w-4 text-white" />
                </div>
                <div className="bg-white rounded-2xl rounded-bl-sm px-4 py-3 shadow-md">
                  <div className="flex items-center space-x-2">
                    <Loader2 className="h-4 w-4 text-[#2D5A27] animate-spin" />
                    <span className="text-sm text-[#5C3D2E]">{t('typing')}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>
      </div>

      {/* Quick Prompts */}
      {messages.length <= 2 && (
        <div className="max-w-4xl mx-auto w-full px-4 pb-2">
          <p className="text-xs text-[#5C3D2E] mb-2 font-medium">{t('quickPrompts')}:</p>
          <div className="flex flex-wrap gap-2">
            {quickPrompts.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(prompt.text[language as 'en' | 'hi'])}
                className="flex items-center space-x-1 bg-white px-3 py-2 rounded-lg shadow-sm hover:shadow-md hover:bg-[#8FAE76]/10 transition-all text-sm text-[#3B2417] active:scale-95"
              >
                <prompt.icon className="h-3.5 w-3.5 text-[#8FAE76]" />
                <span>{prompt.text[language as 'en' | 'hi']}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="border-t bg-white py-4">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder={t('askAnything')}
              className="flex-1 px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#2D5A27] focus:border-transparent outline-none transition-all"
            />
            <button
              onClick={handleVoiceInput}
              className={`p-3 rounded-xl transition-all active:scale-90 ${
                isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-[#F5F1E8] hover:bg-[#8FAE76]/20'
              }`}
            >
              <Mic className="h-5 w-5" />
            </button>
            <button
              onClick={() => handleSend()}
              disabled={isLoading || !input.trim()}
              className="p-3 rounded-xl bg-[#2D5A27] text-white hover:bg-[#4A8C42] transition-all active:scale-90 disabled:opacity-50"
            >
              <Send className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
