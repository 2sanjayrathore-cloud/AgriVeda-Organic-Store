import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from '@/hooks/useTranslation';
import { useApp } from '@/context/AppContext';
import { Shield, Lock, Phone, ArrowRight } from 'lucide-react';

export default function AdminLogin() {
  const { t, language } = useTranslation();
  const { loginAdmin, isAdminLoggedIn } = useApp();
  const navigate = useNavigate();

  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  if (isAdminLoggedIn) {
    navigate('/admin/dashboard');
    return null;
  }

  const handleLogin = () => {
    setError('');
    if (!password) {
      setError(language === 'en' ? 'Please enter password' : 'कृपया पासवर्ड दर्ज करें');
      return;
    }
    if (loginAdmin(password)) {
      navigate('/admin/dashboard');
    } else {
      setError(language === 'en' ? 'Invalid password!' : 'अमान्य पासवर्ड!');
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F1E8] flex items-center justify-center px-4">
      <div className="bg-white rounded-2xl p-8 shadow-xl max-w-md w-full space-y-6">
        <div className="text-center space-y-3">
          <div className="w-20 h-20 bg-[#2D5A27]/10 rounded-full flex items-center justify-center mx-auto">
            <Shield className="h-10 w-10 text-[#2D5A27]" />
          </div>
          <h1 className="text-2xl font-bold text-[#2D5A27]">{t('adminLogin')}</h1>
          <p className="text-sm text-[#5C3D2E]">
            {language === 'en' ? 'This area is restricted to admin only' : 'यह क्षेत्र केवल एडमिन के लिए है'}
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-[#5C3D2E] flex items-center space-x-1 mb-1">
              <Phone className="h-4 w-4" />
              <span>{language === 'en' ? 'Admin Password' : 'एडमिन पासवर्ड'}</span>
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="password"
                placeholder={language === 'en' ? 'Enter admin password' : 'एडमिन पासवर्ड दर्ज करें'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#2D5A27] outline-none transition-all"
              />
            </div>
            <p className="text-xs text-gray-400 mt-1">
              {language === 'en' ? 'Hint: Your phone number (7877612427)' : 'संकेत: आपका फोन नंबर'}
            </p>
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 px-4 py-2 rounded-lg text-sm">
              {error}
            </div>
          )}

          <button
            onClick={handleLogin}
            className="w-full flex items-center justify-center space-x-2 bg-[#2D5A27] text-white py-3 rounded-xl font-semibold hover:bg-[#4A8C42] transition-all active:scale-95"
          >
            <span>{t('login')}</span>
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
