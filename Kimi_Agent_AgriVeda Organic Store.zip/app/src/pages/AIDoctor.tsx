import { useState, useRef, useEffect } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { useApp } from '@/context/AppContext';
import { getDiseaseDiagnosis } from '@/utils/helpers';
import {
  Stethoscope, Upload, Camera, Send, Leaf, Loader2,
  CheckCircle, AlertTriangle, Sprout, Mic, X,
  ImageIcon, Languages,
} from 'lucide-react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  image?: string;
}

export default function AIDoctor() {
  const { language, setLanguage } = useApp();
  const { t } = useTranslation();
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: language === 'en'
        ? 'Hello! I am your AI Plant Doctor. Upload a photo of your plant problem or describe the symptoms, and I will provide organic treatment suggestions.'
        : 'नमस्ते! मैं आपका एआई प्लांट डॉक्टर हूं। अपनी पौधे की समस्या की फोटो अपलोड करें या लक्षण बताएं, और मैं जैविक उपचार सुझाव दूंगा।',
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setUploadedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = async () => {
    if (!input.trim() && !uploadedImage) return;

    const userMessage: Message = {
      role: 'user',
      content: input || (language === 'en' ? 'Please analyze this plant image.' : 'कृपया इस पौधे की छवि का विश्लेषण करें।'),
      image: uploadedImage || undefined,
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 2000));

    const diagnosis = getDiseaseDiagnosis(input || 'plant disease', language as 'en' | 'hi');

    setMessages(prev => [
      ...prev,
      { role: 'assistant', content: diagnosis },
    ]);
    setIsLoading(false);
    setUploadedImage(null);
  };

  const handleVoiceInput = () => {
    if (!('webkitSpeechRecognition' in window)) {
      alert('Voice input not supported in this browser.');
      return;
    }
    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.lang = language === 'hi' ? 'hi-IN' : 'en-IN';
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput(transcript);
    };
    recognition.start();
  };

  const formatMessage = (content: string) => {
    return content.split('\n').map((line, i) => {
      if (line.startsWith('**') && line.endsWith('**')) {
        return <h3 key={i} className="font-bold text-[#2D5A27] mt-3 mb-1">{line.replace(/\*\*/g, '')}</h3>;
      }
      if (line.startsWith('**')) {
        return <h3 key={i} className="font-bold text-[#2D5A27] mt-3 mb-1">{line.replace(/\*\*/g, '')}</h3>;
      }
      if (line.match(/^\d+\./)) {
        return <p key={i} className="ml-4 text-sm">{line}</p>;
      }
      if (line.startsWith('-') || line.startsWith('*')) {
        return <li key={i} className="ml-4 text-sm">{line.substring(1).trim()}</li>;
      }
      if (line.trim() === '') {
        return <div key={i} className="h-2" />;
      }
      return <p key={i} className="text-sm">{line}</p>;
    });
  };

  return (
    <div className="min-h-screen bg-[#F5F1E8] flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#2D5A27] to-[#4A8C42] text-white py-6">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <Stethoscope className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">{t('aiDoctor')}</h1>
                <p className="text-sm text-white/80">
                  {language === 'en' ? 'AI-powered plant diagnosis & organic solutions' : 'एआई-संचालित पौधा निदान और जैविक समाधान'}
                </p>
              </div>
            </div>
            <button
              onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
              className="flex items-center space-x-2 bg-white/20 px-4 py-2 rounded-lg hover:bg-white/30 transition-all active:scale-95"
            >
              <Languages className="h-4 w-4" />
              <span className="text-sm font-medium">{language === 'en' ? 'Hindi' : 'English'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 max-w-4xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 space-y-4 overflow-y-auto">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                msg.role === 'user'
                  ? 'bg-[#2D5A27] text-white rounded-br-sm'
                  : 'bg-white text-[#3B2417] rounded-bl-sm shadow-md'
              }`}
            >
              {msg.image && (
                <img
                  src={msg.image}
                  alt="Uploaded"
                  className="max-w-xs rounded-lg mb-2"
                />
              )}
              <div className="space-y-0.5">
                {formatMessage(msg.content)}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white rounded-2xl rounded-bl-sm px-4 py-3 shadow-md">
              <div className="flex items-center space-x-2">
                <Loader2 className="h-5 w-5 text-[#2D5A27] animate-spin" />
                <span className="text-sm text-[#5C3D2E]">{t('typing')}</span>
              </div>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Image Preview */}
      {uploadedImage && (
        <div className="max-w-4xl mx-auto w-full px-4 pb-2">
          <div className="relative inline-block">
            <img src={uploadedImage} alt="Preview" className="h-24 rounded-lg" />
            <button
              onClick={() => setUploadedImage(null)}
              className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="border-t bg-white py-4">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-2.5 rounded-xl bg-[#F5F1E8] hover:bg-[#8FAE76]/20 transition-all active:scale-90"
              title={t('uploadPhoto')}
            >
              <ImageIcon className="h-5 w-5 text-[#5C3D2E]" />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
            <button
              onClick={() => cameraInputRef.current?.click()}
              className="p-2.5 rounded-xl bg-[#F5F1E8] hover:bg-[#8FAE76]/20 transition-all active:scale-90"
              title={t('takePhoto')}
            >
              <Camera className="h-5 w-5 text-[#5C3D2E]" />
            </button>
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleImageUpload}
              className="hidden"
            />
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder={t('describeProblem')}
              className="flex-1 px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#2D5A27] focus:border-transparent outline-none transition-all"
            />
            <button
              onClick={handleVoiceInput}
              className={`p-2.5 rounded-xl transition-all active:scale-90 ${
                isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-[#F5F1E8] hover:bg-[#8FAE76]/20'
              }`}
              title={t('voiceInput')}
            >
              <Mic className="h-5 w-5" />
            </button>
            <button
              onClick={handleSend}
              disabled={isLoading || (!input.trim() && !uploadedImage)}
              className="p-2.5 rounded-xl bg-[#2D5A27] text-white hover:bg-[#4A8C42] transition-all active:scale-90 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
