import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  decimal,
  bigint,
  json,
  boolean,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id"),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  phone: varchar("phone", { length: 20 }),
  role: mysqlEnum("role", ["user", "admin", "student"]).default("user").notNull(),
  loyaltyPoints: int("loyaltyPoints").default(0),
  preferredLanguage: mysqlEnum("preferredLanguage", ["en", "hi"]).default("en"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export const categories = mysqlTable("categories", {
  id: serial("id"),
  name: varchar("name", { length: 255 }).notNull(),
  nameHi: varchar("nameHi", { length: 255 }),
  description: text("description"),
  descriptionHi: text("descriptionHi"),
  image: text("image"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const products = mysqlTable("products", {
  id: serial("id"),
  name: varchar("name", { length: 255 }).notNull(),
  nameHi: varchar("nameHi", { length: 255 }),
  description: text("description"),
  descriptionHi: text("descriptionHi"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  unit: varchar("unit", { length: 50 }).default("kg").notNull(),
  categoryId: bigint("categoryId", { mode: "number", unsigned: true }).notNull(),
  image: text("image"),
  stock: int("stock").default(0).notNull(),
  minOrder: int("minOrder").default(1),
  isActive: boolean("isActive").default(true),
  benefits: json("benefits").$type<string[]>(),
  benefitsHi: json("benefitsHi").$type<string[]>(),
  usage: text("usage"),
  usageHi: text("usageHi"),
  barcode: varchar("barcode", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export const customers = mysqlTable("customers", {
  id: serial("id"),
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  email: varchar("email", { length: 320 }),
  address: text("address"),
  village: varchar("village", { length: 255 }),
  district: varchar("district", { length: 255 }),
  state: varchar("state", { length: 255 }),
  pincode: varchar("pincode", { length: 10 }),
  loyaltyPoints: int("loyaltyPoints").default(0),
  totalOrders: int("totalOrders").default(0),
  totalSpent: decimal("totalSpent", { precision: 10, scale: 2 }).default("0"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export const orders = mysqlTable("orders", {
  id: serial("id"),
  orderNumber: varchar("orderNumber", { length: 50 }).notNull().unique(),
  customerId: bigint("customerId", { mode: "number", unsigned: true }),
  customerName: varchar("customerName", { length: 255 }).notNull(),
  customerPhone: varchar("customerPhone", { length: 20 }).notNull(),
  customerEmail: varchar("customerEmail", { length: 320 }),
  customerAddress: text("customerAddress"),
  totalAmount: decimal("totalAmount", { precision: 10, scale: 2 }).notNull(),
  discount: decimal("discount", { precision: 10, scale: 2 }).default("0"),
  finalAmount: decimal("finalAmount", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"]).default("pending"),
  paymentMethod: mysqlEnum("paymentMethod", ["cod", "upi", "qr", "card"]).default("cod"),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "paid", "failed", "refunded"]).default("pending"),
  upiTransactionId: varchar("upiTransactionId", { length: 100 }),
  notes: text("notes"),
  studentId: bigint("studentId", { mode: "number", unsigned: true }),
  studentName: varchar("studentName", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export const orderItems = mysqlTable("orderItems", {
  id: serial("id"),
  orderId: bigint("orderId", { mode: "number", unsigned: true }).notNull(),
  productId: bigint("productId", { mode: "number", unsigned: true }).notNull(),
  productName: varchar("productName", { length: 255 }).notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  unit: varchar("unit", { length: 50 }).notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  total: decimal("total", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const sales = mysqlTable("sales", {
  id: serial("id"),
  studentName: varchar("studentName", { length: 255 }).notNull(),
  studentPhone: varchar("studentPhone", { length: 20 }),
  studentEmail: varchar("studentEmail", { length: 320 }),
  buyerName: varchar("buyerName", { length: 255 }).notNull(),
  buyerPhone: varchar("buyerPhone", { length: 20 }).notNull(),
  buyerEmail: varchar("buyerEmail", { length: 320 }),
  buyerAddress: text("buyerAddress"),
  productId: bigint("productId", { mode: "number", unsigned: true }).notNull(),
  productName: varchar("productName", { length: 255 }).notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  unit: varchar("unit", { length: 50 }).notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  totalAmount: decimal("totalAmount", { precision: 10, scale: 2 }).notNull(),
  paymentMethod: mysqlEnum("paymentMethod", ["cash", "upi", "qr", "bank_transfer"]).default("cash"),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "paid", "partial"]).default("pending"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const expenses = mysqlTable("expenses", {
  id: serial("id"),
  category: varchar("category", { length: 255 }).notNull(),
  description: text("description").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  paidBy: varchar("paidBy", { length: 255 }),
  paymentMethod: mysqlEnum("paymentMethod", ["cash", "upi", "bank_transfer", "card"]).default("cash"),
  receiptUrl: text("receiptUrl"),
  createdBy: bigint("createdBy", { mode: "number", unsigned: true }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const inventory = mysqlTable("inventory", {
  id: serial("id"),
  productId: bigint("productId", { mode: "number", unsigned: true }).notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  unit: varchar("unit", { length: 50 }).notNull(),
  type: mysqlEnum("type", ["addition", "reduction", "adjustment"]).notNull(),
  reason: text("reason"),
  batchNumber: varchar("batchNumber", { length: 100 }),
  expiryDate: timestamp("expiryDate"),
  createdBy: bigint("createdBy", { mode: "number", unsigned: true }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const chatMessages = mysqlTable("chatMessages", {
  id: serial("id"),
  userId: bigint("userId", { mode: "number", unsigned: true }),
  sessionId: varchar("sessionId", { length: 255 }).notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const diseaseDiagnoses = mysqlTable("diseaseDiagnoses", {
  id: serial("id"),
  userId: bigint("userId", { mode: "number", unsigned: true }),
  farmerName: varchar("farmerName", { length: 255 }),
  farmerPhone: varchar("farmerPhone", { length: 20 }),
  cropType: varchar("cropType", { length: 255 }),
  symptoms: text("symptoms"),
  imageUrl: text("imageUrl"),
  diagnosis: text("diagnosis"),
  recommendedProduct: varchar("recommendedProduct", { length: 255 }),
  organicSolution: text("organicSolution"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const loyaltyTransactions = mysqlTable("loyaltyTransactions", {
  id: serial("id"),
  customerId: bigint("customerId", { mode: "number", unsigned: true }).notNull(),
  orderId: bigint("orderId", { mode: "number", unsigned: true }),
  points: int("points").notNull(),
  type: mysqlEnum("type", ["earned", "redeemed", "bonus"]).notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const activityLogs = mysqlTable("activityLogs", {
  id: serial("id"),
  userId: bigint("userId", { mode: "number", unsigned: true }),
  action: varchar("action", { length: 255 }).notNull(),
  entity: varchar("entity", { length: 100 }),
  entityId: bigint("entityId", { mode: "number", unsigned: true }),
  details: json("details"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;
export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;
export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = typeof orderItems.$inferInsert;
export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = typeof customers.$inferInsert;
export type Sale = typeof sales.$inferSelect;
export type InsertSale = typeof sales.$inferInsert;
export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = typeof expenses.$inferInsert;
export type Inventory = typeof inventory.$inferSelect;
export type InsertInventory = typeof inventory.$inferInsert;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type DiseaseDiagnosis = typeof diseaseDiagnoses.$inferSelect;
export type LoyaltyTransaction = typeof loyaltyTransactions.$inferSelect;
export type ActivityLog = typeof activityLogs.$inferSelect;
