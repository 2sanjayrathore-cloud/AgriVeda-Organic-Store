import { authRouter } from "./auth-router";
import { productRouter } from "./product-router";
import { orderRouter } from "./order-router";
import { salesRouter, expenseRouter } from "./sales-router";
import { dashboardRouter } from "./dashboard-router";
import { aiRouter } from "./ai-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  product: productRouter,
  order: orderRouter,
  sales: salesRouter,
  expense: expenseRouter,
  dashboard: dashboardRouter,
  ai: aiRouter,
});

export type AppRouter = typeof appRouter;
