import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { sales, expenses } from "@db/schema";
import { eq, desc, and, gte, lte, sql } from "drizzle-orm";

export const salesRouter = createRouter({
  create: publicQuery
    .input(
      z.object({
        studentName: z.string().min(1),
        studentPhone: z.string().optional(),
        studentEmail: z.string().optional(),
        buyerName: z.string().min(1),
        buyerPhone: z.string().min(10),
        buyerEmail: z.string().optional(),
        buyerAddress: z.string().optional(),
        productId: z.number(),
        productName: z.string(),
        quantity: z.number().min(0.1),
        unit: z.string(),
        price: z.number(),
        totalAmount: z.number(),
        paymentMethod: z.enum(["cash", "upi", "qr", "bank_transfer"]).default("cash"),
        paymentStatus: z.enum(["pending", "paid", "partial"]).default("pending"),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(sales).values({
        studentName: input.studentName,
        studentPhone: input.studentPhone,
        studentEmail: input.studentEmail,
        buyerName: input.buyerName,
        buyerPhone: input.buyerPhone,
        buyerEmail: input.buyerEmail,
        buyerAddress: input.buyerAddress,
        productId: input.productId,
        productName: input.productName,
        quantity: input.quantity.toFixed(2),
        unit: input.unit,
        price: input.price.toFixed(2),
        totalAmount: input.totalAmount.toFixed(2),
        paymentMethod: input.paymentMethod,
        paymentStatus: input.paymentStatus,
        notes: input.notes,
      });
      return { id: Number(result[0].insertId) };
    }),

  list: adminQuery
    .input(
      z.object({
        startDate: z.string().optional(),
        endDate: z.string().optional(),
        studentName: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      
      if (input?.startDate) {
        conditions.push(gte(sales.createdAt, new Date(input.startDate)));
      }
      if (input?.endDate) {
        conditions.push(lte(sales.createdAt, new Date(input.endDate)));
      }
      if (input?.studentName) {
        conditions.push(eq(sales.studentName, input.studentName));
      }
      
      return db.select()
        .from(sales)
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .orderBy(desc(sales.createdAt));
    }),

  stats: adminQuery.query(async () => {
    const db = getDb();
    
    const totalSales = await db.select({ total: sql`sum(totalAmount)` }).from(sales)
      .where(eq(sales.paymentStatus, "paid"));
    const pendingSales = await db.select({ total: sql`sum(totalAmount)` }).from(sales)
      .where(eq(sales.paymentStatus, "pending"));
    const todaySales = await db.select({ total: sql`sum(totalAmount)` }).from(sales)
      .where(and(
        eq(sales.paymentStatus, "paid"),
        gte(sales.createdAt, new Date(new Date().setHours(0, 0, 0, 0)))
      ));
    
    const totalExpenses = await db.select({ total: sql`sum(amount)` }).from(expenses);
    
    const totalRevenue = Number(totalSales[0]?.total || 0);
    const totalExpense = Number(totalExpenses[0]?.total || 0);
    
    return {
      totalSales: totalRevenue,
      pendingSales: Number(pendingSales[0]?.total || 0),
      todaySales: Number(todaySales[0]?.total || 0),
      totalExpenses: totalExpense,
      netProfit: totalRevenue - totalExpense,
    };
  }),
});

export const expenseRouter = createRouter({
  create: adminQuery
    .input(
      z.object({
        category: z.string().min(1),
        description: z.string().min(1),
        amount: z.number().min(0.01),
        paidBy: z.string().optional(),
        paymentMethod: z.enum(["cash", "upi", "bank_transfer", "card"]).default("cash"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const result = await db.insert(expenses).values({
        ...input,
        amount: input.amount.toFixed(2),
        createdBy: ctx.user?.id,
      });
      return { id: Number(result[0].insertId) };
    }),

  list: adminQuery
    .input(
      z.object({
        category: z.string().optional(),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      
      if (input?.category) {
        conditions.push(eq(expenses.category, input.category));
      }
      if (input?.startDate) {
        conditions.push(gte(expenses.createdAt, new Date(input.startDate)));
      }
      if (input?.endDate) {
        conditions.push(lte(expenses.createdAt, new Date(input.endDate)));
      }
      
      return db.select()
        .from(expenses)
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .orderBy(desc(expenses.createdAt));
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(expenses).where(eq(expenses.id, input.id));
      return { success: true };
    }),
});
