import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { orders, orderItems, products, customers } from "@db/schema";
import { eq, desc, and, gte, sql } from "drizzle-orm";

export const orderRouter = createRouter({
  create: publicQuery
    .input(
      z.object({
        customerName: z.string().min(1),
        customerPhone: z.string().min(10),
        customerEmail: z.string().email().optional(),
        customerAddress: z.string().optional(),
        items: z.array(
          z.object({
            productId: z.number(),
            productName: z.string(),
            quantity: z.number().min(0.1),
            unit: z.string(),
            price: z.number(),
            total: z.number(),
          })
        ),
        totalAmount: z.number(),
        discount: z.number().default(0),
        finalAmount: z.number(),
        paymentMethod: z.enum(["cod", "upi", "qr", "card"]).default("cod"),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      
      const orderNumber = `AGR${Date.now().toString(36).toUpperCase()}`;
      
      const orderResult = await db.insert(orders).values({
        orderNumber,
        customerName: input.customerName,
        customerPhone: input.customerPhone,
        customerEmail: input.customerEmail,
        customerAddress: input.customerAddress,
        totalAmount: input.totalAmount.toFixed(2),
        discount: input.discount.toFixed(2),
        finalAmount: input.finalAmount.toFixed(2),
        paymentMethod: input.paymentMethod,
        notes: input.notes,
      });
      
      const orderId = Number(orderResult[0].insertId);
      
      for (const item of input.items) {
        await db.insert(orderItems).values({
          orderId,
          productId: item.productId,
          productName: item.productName,
          quantity: item.quantity.toFixed(2),
          unit: item.unit,
          price: item.price.toFixed(2),
          total: item.total.toFixed(2),
        });
        
        await db.update(products)
          .set({ stock: sql`stock - ${item.quantity}` })
          .where(eq(products.id, item.productId));
      }
      
      const existingCustomer = await db.select()
        .from(customers)
        .where(eq(customers.phone, input.customerPhone));
      
      if (existingCustomer.length > 0) {
        const cust = existingCustomer[0];
        await db.update(customers)
          .set({
            totalOrders: (cust.totalOrders || 0) + 1,
            totalSpent: ((parseFloat(cust.totalSpent?.toString() || "0")) + input.finalAmount).toFixed(2),
            loyaltyPoints: (cust.loyaltyPoints || 0) + Math.floor(input.finalAmount / 10),
          })
          .where(eq(customers.id, cust.id));
      } else {
        await db.insert(customers).values({
          name: input.customerName,
          phone: input.customerPhone,
          email: input.customerEmail,
          address: input.customerAddress,
          totalOrders: 1,
          totalSpent: input.finalAmount.toFixed(2),
          loyaltyPoints: Math.floor(input.finalAmount / 10),
        });
      }
      
      return { orderId, orderNumber };
    }),

  list: adminQuery
    .input(
      z.object({
        status: z.string().optional(),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      
      if (input?.status) {
        conditions.push(eq(orders.status, input.status as any));
      }
      if (input?.startDate) {
        conditions.push(gte(orders.createdAt, new Date(input.startDate)));
      }
      
      return db.select()
        .from(orders)
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .orderBy(desc(orders.createdAt));
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const order = await db.select()
        .from(orders)
        .where(eq(orders.id, input.id));
      
      if (order.length === 0) return null;
      
      const items = await db.select()
        .from(orderItems)
        .where(eq(orderItems.orderId, input.id));
      
      return { ...order[0], items };
    }),

  getByOrderNumber: publicQuery
    .input(z.object({ orderNumber: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const order = await db.select()
        .from(orders)
        .where(eq(orders.orderNumber, input.orderNumber));
      
      if (order.length === 0) return null;
      
      const items = await db.select()
        .from(orderItems)
        .where(eq(orderItems.orderId, order[0].id));
      
      return { ...order[0], items };
    }),

  updateStatus: adminQuery
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"]),
        paymentStatus: z.enum(["pending", "paid", "failed", "refunded"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const updateData: any = { status: input.status };
      if (input.paymentStatus) updateData.paymentStatus = input.paymentStatus;
      
      await db.update(orders)
        .set(updateData)
        .where(eq(orders.id, input.id));
      
      return { success: true };
    }),

  stats: adminQuery.query(async () => {
    const db = getDb();
    
    const totalOrders = await db.select({ count: sql`count(*)` }).from(orders);
    const totalRevenue = await db.select({ total: sql`sum(finalAmount)` }).from(orders);
    const pendingOrders = await db.select({ count: sql`count(*)` }).from(orders).where(eq(orders.status, "pending"));
    const todayOrders = await db.select({ count: sql`count(*)` }).from(orders)
      .where(gte(orders.createdAt, new Date(new Date().setHours(0, 0, 0, 0))));
    
    return {
      totalOrders: Number(totalOrders[0]?.count || 0),
      totalRevenue: Number(totalRevenue[0]?.total || 0),
      pendingOrders: Number(pendingOrders[0]?.count || 0),
      todayOrders: Number(todayOrders[0]?.count || 0),
    };
  }),
});
