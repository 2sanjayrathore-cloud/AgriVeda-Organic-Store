import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { products, categories } from "@db/schema";
import { eq, desc, like, and } from "drizzle-orm";

export const productRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        categoryId: z.number().optional(),
        search: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      
      if (input?.categoryId) {
        conditions.push(eq(products.categoryId, input.categoryId));
      }
      if (input?.search) {
        conditions.push(like(products.name, `%${input.search}%`));
      }
      
      const result = await db
        .select()
        .from(products)
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .orderBy(desc(products.createdAt));
      
      return result;
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(products)
        .where(eq(products.id, input.id));
      return result[0] || null;
    }),

  categories: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(categories).orderBy(categories.name);
  }),

  create: adminQuery
    .input(
      z.object({
        name: z.string().min(1),
        nameHi: z.string().optional(),
        description: z.string().optional(),
        descriptionHi: z.string().optional(),
        price: z.string(),
        unit: z.string().default("kg"),
        categoryId: z.number(),
        image: z.string().optional(),
        stock: z.number().default(0),
        minOrder: z.number().default(1),
        benefits: z.array(z.string()).optional(),
        benefitsHi: z.array(z.string()).optional(),
        usage: z.string().optional(),
        usageHi: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(products).values({
        name: input.name,
        nameHi: input.nameHi,
        description: input.description,
        descriptionHi: input.descriptionHi,
        price: input.price,
        unit: input.unit,
        categoryId: input.categoryId,
        image: input.image,
        stock: input.stock,
        minOrder: input.minOrder,
        benefits: input.benefits,
        benefitsHi: input.benefitsHi,
        usage: input.usage,
        usageHi: input.usageHi,
      });
      return result;
    }),

  update: adminQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        nameHi: z.string().optional(),
        description: z.string().optional(),
        descriptionHi: z.string().optional(),
        price: z.string().optional(),
        unit: z.string().optional(),
        categoryId: z.number().optional(),
        image: z.string().optional(),
        stock: z.number().optional(),
        minOrder: z.number().optional(),
        isActive: z.boolean().optional(),
        benefits: z.array(z.string()).optional(),
        benefitsHi: z.array(z.string()).optional(),
        usage: z.string().optional(),
        usageHi: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(products).set(data).where(eq(products.id, id));
      return { success: true };
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(products).where(eq(products.id, input.id));
      return { success: true };
    }),
});
