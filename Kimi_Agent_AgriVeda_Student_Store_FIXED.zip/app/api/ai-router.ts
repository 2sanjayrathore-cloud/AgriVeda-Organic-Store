import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { chatMessages, diseaseDiagnoses } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const aiRouter = createRouter({
  chat: publicQuery
    .input(
      z.object({
        message: z.string().min(1),
        sessionId: z.string(),
        userId: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      
      // Store user message
      await db.insert(chatMessages).values({
        userId: input.userId,
        sessionId: input.sessionId,
        role: "user",
        message: input.message,
      });
      
      // Simple AI responses for common agricultural questions
      const message = input.message.toLowerCase();
      let response = "";
      
      if (message.includes("hello") || message.includes("hi") || message.includes("namaste")) {
        response = "Namaste! 🙏 Welcome to AgriVeda Organic Store. I am your AI farming assistant. How can I help you today? I can help with:\n\n1. 🌱 Crop disease identification\n2. 💚 Organic input recommendations\n3. 📋 Product information\n4. 🌾 Farming tips and best practices";
      } else if (message.includes("disease") || message.includes("pest") || message.includes("problem")) {
        response = "I can help you identify and treat crop diseases! Please:\n\n📸 Upload a photo of the affected plant/leaf\n📝 Describe the symptoms (yellowing, spots, wilting, etc.)\n🌱 Tell me which crop you're growing\n\nOur AI Doctor will analyze and recommend the best organic treatment using our products like Bramastra, Neemastra, or Agniastra.";
      } else if (message.includes("price") || message.includes("cost") || message.includes("rate")) {
        response = "Here are our popular product prices:\n\n🪱 Vermicompost: ₹10/kg\n🌿 Enriched Vermicompost: ₹15/kg\n💧 Vermiwash: ₹120/liter\n🌊 BGA: ₹80/kg\n🛡️ Neemastra: ₹100/liter\n⚡ Agniastra: ₹130/liter\n🌟 Panchgavya: ₹200/liter\n🌱 Jeevamrit: ₹85/liter\n\nVisit our Products page for complete pricing!";
      } else if (message.includes("vermicompost") || message.includes("khad")) {
        response = "Our Vermicompost is premium quality! Here's why farmers love it:\n\n✅ Rich in NPK nutrients\n✅ Contains beneficial microbes\n✅ Improves soil structure\n✅ 100% organic & chemical-free\n✅ Only ₹10/kg (Minimum 5kg)\n\nUsage: Mix 1:3 with soil for pots, or apply 2-5 tonnes/acre for field crops.";
      } else if (message.includes("order") || message.includes("buy") || message.includes("purchase")) {
        response = "Ordering is easy! 🛒\n\n1. Browse products on our website\n2. Add items to cart\n3. Checkout with your details\n4. Pay via UPI, QR code, or Cash on Delivery\n\nWe'll send your order confirmation via WhatsApp and prepare your bill instantly!\n\nFor bulk orders (50+ kg), contact us for special student pricing.";
      } else if (message.includes("organic") || message.includes("natural")) {
        response = "All our products are 100% organic! 🌿\n\nWe are students from College of Agriculture, Balaghat, producing these inputs ourselves using:\n\n🪱 Earthworm composting\n🐄 Cow-based preparations\n🌿 Herbal extracts\n🦠 Microbial cultures\n\nNo chemicals, no synthetics - pure nature's goodness for your farm!";
      } else if (message.includes("student") || message.includes("college")) {
        response = "We are proud students of College of Agriculture, Balaghat! 🎓\n\nThis organic store is our initiative to provide farmers with authentic, affordable organic inputs while gaining entrepreneurial experience.\n\nAll products are prepared under expert guidance in our college labs and farms.";
      } else {
        response = "Thank you for your question! 🙏\n\nAs your AI farming assistant, I can help with:\n\n🌾 Crop disease identification (upload photos)\n💚 Organic input recommendations\n📊 Product information and pricing\n🌱 Farming best practices\n📞 Connecting you with our team\n\nCould you please provide more details so I can assist you better?";
      }
      
      // Store AI response
      await db.insert(chatMessages).values({
        userId: input.userId,
        sessionId: input.sessionId,
        role: "assistant",
        message: response,
      });
      
      return { response };
    }),

  getChatHistory: publicQuery
    .input(z.object({ sessionId: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.select()
        .from(chatMessages)
        .where(eq(chatMessages.sessionId, input.sessionId))
        .orderBy(chatMessages.createdAt);
    }),

  diagnose: publicQuery
    .input(
      z.object({
        farmerName: z.string().optional(),
        farmerPhone: z.string().optional(),
        cropType: z.string().min(1),
        symptoms: z.string().min(1),
        imageUrl: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      
      // Store diagnosis request
      const result = await db.insert(diseaseDiagnoses).values({
        farmerName: input.farmerName,
        farmerPhone: input.farmerPhone,
        cropType: input.cropType,
        symptoms: input.symptoms,
        imageUrl: input.imageUrl,
      });
      
      const diagnosisId = Number(result[0].insertId);
      
      // Simple rule-based diagnosis
      const symptoms = input.symptoms.toLowerCase();
      
      let diagnosis = "";
      let recommendedProduct = "";
      let organicSolution = "";
      
      if (symptoms.includes("yellow") || symptoms.includes("pila")) {
        diagnosis = "The yellowing of leaves indicates possible nitrogen deficiency, fungal infection, or viral disease.";
        recommendedProduct = "Panchgavya + Vermiwash";
        organicSolution = "1. Apply Panchgavya (30ml/liter water) to roots weekly\n2. Spray Vermiwash diluted 1:10 on leaves\n3. Add Enriched Vermicompost to soil\n4. Ensure proper drainage";
      } else if (symptoms.includes("spot") || symptoms.includes("daag") || symptoms.includes("blight")) {
        diagnosis = "Leaf spot/blight symptoms suggest fungal or bacterial infection.";
        recommendedProduct = "Bramastra + Neemastra";
        organicSolution = "1. Spray Bramastra (100ml/15L water) every 7 days\n2. Alternate with Neemastra spray\n3. Remove and destroy infected leaves\n4. Improve air circulation between plants";
      } else if (symptoms.includes("worm") || symptoms.includes("caterpillar") || symptoms.includes("sundi")) {
        diagnosis = "Presence of caterpillars or worms causing damage to leaves and fruits.";
        recommendedProduct = "Agniastra + Bramastra";
        organicSolution = "1. Spray Agniastra (50ml/15L water) in evening\n2. Follow with Bramastra after 3 days\n3. Hand-pick visible caterpillars\n4. Use light traps at night";
      } else if (symptoms.includes("suck") || symptoms.includes("aphid") || symptoms.includes("whitefly") || symptoms.includes("jassid")) {
        diagnosis = "Sucking pests like aphids, whiteflies, or jassids are attacking the plant.";
        recommendedProduct = "Neemastra + Vermiwash";
        organicSolution = "1. Spray Neemastra (100ml/15L water) weekly\n2. Add few drops of soap for better sticking\n3. Release beneficial insects if possible\n4. Spray Vermiwash to boost plant immunity";
      } else if (symptoms.includes("root") || symptoms.includes("wilt") || symptoms.includes("murjha")) {
        diagnosis = "Root rot or wilting indicates fungal infection in roots or waterlogging.";
        recommendedProduct = "Jeevamrit + Enriched Vermicompost";
        organicSolution = "1. Drench soil with Jeevamrit (200L/acre)\n2. Add Enriched Vermicompost (contains Trichoderma)\n3. Improve drainage immediately\n4. Reduce watering frequency";
      } else {
        diagnosis = "Based on the symptoms described, the plant may be under stress from environmental factors, nutrient deficiency, or early-stage disease.";
        recommendedProduct = "Jeevamrit + Panchgavya";
        organicSolution = "1. Apply Jeevamrit to soil (200L/acre)\n2. Spray Panchgavya (30ml/liter) on foliage\n3. Ensure balanced watering\n4. Monitor closely for symptom changes\n\nIf symptoms persist, please upload a clear photo for better diagnosis.";
      }
      
      // Update diagnosis with results
      await db.update(diseaseDiagnoses)
        .set({ diagnosis, recommendedProduct, organicSolution })
        .where(eq(diseaseDiagnoses.id, diagnosisId));
      
      return {
        diagnosisId,
        diagnosis,
        recommendedProduct,
        organicSolution,
      };
    }),

  getDiagnoses: publicQuery
    .input(z.object({ phone: z.string().optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      if (input.phone) {
        return db.select()
          .from(diseaseDiagnoses)
          .where(eq(diseaseDiagnoses.farmerPhone, input.phone))
          .orderBy(desc(diseaseDiagnoses.createdAt));
      }
      return db.select()
        .from(diseaseDiagnoses)
        .orderBy(desc(diseaseDiagnoses.createdAt))
        .limit(20);
    }),
});
