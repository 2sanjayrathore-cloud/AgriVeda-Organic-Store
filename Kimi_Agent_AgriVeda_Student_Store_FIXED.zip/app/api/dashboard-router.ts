import { z } from "zod";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { orders, sales, expenses, products, customers } from "@db/schema";
import { sql, eq, gte, desc } from "drizzle-orm";

export const dashboardRouter = createRouter({
  overview: adminQuery.query(async () => {
    const db = getDb();
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    
    const orderRevenue = await db.select({ total: sql`COALESCE(sum(finalAmount), 0)` }).from(orders)
      .where(eq(orders.paymentStatus, "paid"));
    
    const salesRevenue = await db.select({ total: sql`COALESCE(sum(totalAmount), 0)` }).from(sales)
      .where(eq(sales.paymentStatus, "paid"));
    
    const totalExpenses = await db.select({ total: sql`COALESCE(sum(amount), 0)` }).from(expenses);
    
    const todayOrders = await db.select({ total: sql`COALESCE(sum(finalAmount), 0)` }).from(orders)
      .where(gte(orders.createdAt, today));
    
    const monthOrders = await db.select({ total: sql`COALESCE(sum(finalAmount), 0)` }).from(orders)
      .where(gte(orders.createdAt, monthStart));
    
    const totalOrdersCount = await db.select({ count: sql`count(*)` }).from(orders);
    
    const totalCustomers = await db.select({ count: sql`count(*)` }).from(customers);
    
    const lowStock = await db.select()
      .from(products)
      .where(sql`stock < 50`)
      .orderBy(products.stock)
      .limit(5);
    
    const recentOrders = await db.select()
      .from(orders)
      .orderBy(desc(orders.createdAt))
      .limit(10);
    
    const totalRevenue = Number(orderRevenue[0]?.total || 0) + Number(salesRevenue[0]?.total || 0);
    const totalExpense = Number(totalExpenses[0]?.total || 0);
    
    return {
      totalRevenue,
      totalExpenses: totalExpense,
      netProfit: totalRevenue - totalExpense,
      todayRevenue: Number(todayOrders[0]?.total || 0),
      monthRevenue: Number(monthOrders[0]?.total || 0),
      totalOrders: Number(totalOrdersCount[0]?.count || 0),
      totalCustomers: Number(totalCustomers[0]?.count || 0),
      lowStockProducts: lowStock,
      recentOrders,
      topProducts: [],
    };
  }),

  chartData: adminQuery
    .input(
      z.object({
        period: z.enum(["week", "month", "year"]).default("month"),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const now = new Date();
      let startDate: Date;
      
      switch (input?.period || "month") {
        case "week":
          startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          break;
        case "year":
          startDate = new Date(now.getFullYear(), 0, 1);
          break;
        default:
          startDate = new Date(now.getFullYear(), now.getMonth(), 1);
      }
      
      const dailyRevenue = await db.select({
        date: sql`DATE(createdAt)`,
        revenue: sql`COALESCE(sum(finalAmount), 0)`,
        orders: sql`count(*)`,
      }).from(orders)
        .where(gte(orders.createdAt, startDate))
        .groupBy(sql`DATE(createdAt)`)
        .orderBy(sql`date`);
      
      const dailyExpenses = await db.select({
        date: sql`DATE(createdAt)`,
        amount: sql`COALESCE(sum(amount), 0)`,
      }).from(expenses)
        .where(gte(expenses.createdAt, startDate))
        .groupBy(sql`DATE(createdAt)`)
        .orderBy(sql`date`);
      
      return { dailyRevenue, dailyExpenses };
    }),
});
