import { useState } from "react";
import { useLanguage } from "@/hooks/useLanguage";
import { trpc } from "@/providers/trpc";
import { toast } from "sonner";
import { motion } from "framer-motion";
import {
  GraduationCap,
  Send,
  Receipt,
  MessageCircle,
  CheckCircle,
  RotateCcw,
} from "lucide-react";

export default function StudentSales() {
  const { t } = useLanguage();
  const [showForm, setShowForm] = useState(false);
  const [successData, setSuccessData] = useState<any>(null);
  
  const [form, setForm] = useState({
    studentName: "",
    studentPhone: "",
    studentEmail: "",
    buyerName: "",
    buyerPhone: "",
    buyerEmail: "",
    buyerAddress: "",
    productId: "",
    productName: "",
    quantity: "",
    unit: "kg",
    price: "",
    paymentMethod: "cash" as const,
    paymentStatus: "pending" as const,
    notes: "",
  });

  const { data: products } = trpc.product.list.useQuery({});
  const utils = trpc.useUtils();

  const createSale = trpc.sales.create.useMutation({
    onSuccess: (data) => {
      setSuccessData({ ...form, id: data.id });
      setShowForm(false);
      utils.sales.list.invalidate();
      utils.sales.stats.invalidate();
      toast.success(t("Sale recorded successfully!", "बिक्री सफलतापूर्वक दर्ज की गई!"));
      setForm({ studentName: "", studentPhone: "", studentEmail: "", buyerName: "", buyerPhone: "", buyerEmail: "", buyerAddress: "", productId: "", productName: "", quantity: "", unit: "kg", price: "", paymentMethod: "cash", paymentStatus: "pending", notes: "" });
    },
    onError: (error) => {
      toast.error(error.message || t("Failed to record sale", "बिक्री दर्ज करने में विफल"));
    },
  });

  const handleSubmit = () => {
    if (!form.studentName || !form.buyerName || !form.buyerPhone || !form.productId || !form.quantity || !form.price) {
      toast.error(t("Please fill all required fields", "कृपया सभी आवश्यक फ़ील्ड भरें"));
      return;
    }
    const product = products?.find((p: any) => p.id === Number(form.productId));
    createSale.mutate({
      studentName: form.studentName,
      studentPhone: form.studentPhone || undefined,
      studentEmail: form.studentEmail || undefined,
      buyerName: form.buyerName,
      buyerPhone: form.buyerPhone,
      buyerEmail: form.buyerEmail || undefined,
      buyerAddress: form.buyerAddress || undefined,
      productId: Number(form.productId),
      productName: product?.name || form.productName,
      quantity: parseFloat(form.quantity),
      unit: product?.unit || form.unit,
      price: parseFloat(form.price),
      totalAmount: parseFloat(form.quantity) * parseFloat(form.price),
      paymentMethod: form.paymentMethod,
      paymentStatus: form.paymentStatus,
      notes: form.notes || undefined,
    });
  };

  const handleWhatsAppSend = () => {
    if (!successData) return;
    const message = `*AgriVeda Organic Store - Sale Receipt*\n\n*Student:* ${successData.studentName}\n*Buyer:* ${successData.buyerName}\n*Product:* ${successData.productName}\n*Quantity:* ${successData.quantity} ${successData.unit}\n*Price:* Rs.${successData.price}/${successData.unit}\n*Total:* Rs.${parseFloat(successData.quantity) * parseFloat(successData.price)}\n*Payment:* ${successData.paymentMethod?.toUpperCase()} (${successData.paymentStatus})\n\nThank you for supporting organic farming!\nCollege of Agriculture, Balaghat`;
    window.open(`https://wa.me/91${successData.buyerPhone}?text=${encodeURIComponent(message)}`, "_blank");
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-400 to-indigo-600 flex items-center justify-center mx-auto mb-3">
          <GraduationCap className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-gray-800">{t("Student Sales Portal", "छात्र बिक्री पोर्टल")}</h1>
        <p className="text-gray-500">{t("Record sales made by students", "छात्रों द्वारा की गई बिक्री दर्ज करें")}</p>
      </motion.div>

      {successData ? (
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="bg-white rounded-2xl shadow-lg p-8 text-center border border-green-200">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-2">{t("Sale Recorded Successfully!", "बिक्री सफलतापूर्वक दर्ज की गई!")}</h2>
          <p className="text-gray-500 mb-6">{t("The sale has been saved and admin has been notified.", "बिक्री सहेज ली गई है और एडमिन को सूचित किया गया है।")}</p>
          <div className="bg-gray-50 rounded-xl p-6 text-left max-w-md mx-auto mb-6">
            <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2"><Receipt className="w-5 h-5 text-green-600" />{t("Sale Summary", "बिक्री सारांश")}</h3>
            <div className="space-y-2 text-sm">
              <p><span className="text-gray-500">{t("Student", "छात्र")}:</span> {successData.studentName}</p>
              <p><span className="text-gray-500">{t("Buyer", "खरीदार")}:</span> {successData.buyerName}</p>
              <p><span className="text-gray-500">{t("Product", "उत्पाद")}:</span> {successData.productName}</p>
              <p><span className="text-gray-500">{t("Quantity", "मात्रा")}:</span> {successData.quantity} {successData.unit}</p>
              <p><span className="text-gray-500">{t("Total Amount", "कुल राशि")}:</span> Rs.{parseFloat(successData.quantity) * parseFloat(successData.price)}</p>
            </div>
          </div>
          <div className="flex flex-wrap justify-center gap-3">
            <button onClick={handleWhatsAppSend} className="flex items-center gap-2 px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-xl font-medium transition-all hover:scale-105"><MessageCircle className="w-5 h-5" />{t("Send WhatsApp Receipt", "व्हाट्सएप रसीद भेजें")}</button>
            <button onClick={() => setSuccessData(null)} className="flex items-center gap-2 px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-medium transition-all"><RotateCcw className="w-5 h-5" />{t("New Sale", "नई बिक्री")}</button>
          </div>
        </motion.div>
      ) : !showForm ? (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center">
          <button onClick={() => setShowForm(true)} className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white rounded-2xl font-semibold text-lg transition-all hover:scale-105 shadow-lg">
            <GraduationCap className="w-6 h-6" />{t("New Sales Entry", "नई बिक्री एंट्री")}
          </button>
          <p className="text-gray-400 mt-4 text-sm">{t("Click to record a new sale", "नई बिक्री दर्ज करने के लिए क्लिक करें")}</p>
        </motion.div>
      ) : (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-2xl shadow-lg p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-6 flex items-center gap-2"><Receipt className="w-5 h-5 text-blue-600" />{t("Sales Entry Form", "बिक्री एंट्री फॉर्म")}</h2>
          <div className="space-y-6">
            <div className="bg-blue-50 rounded-xl p-4">
              <h3 className="font-semibold text-blue-800 mb-3 flex items-center gap-2"><GraduationCap className="w-4 h-4" />{t("Student Details", "छात्र विवरण")}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div><label className="block text-sm font-medium text-gray-700 mb-1">{t("Student Name", "छात्र का नाम")} *</label><input type="text" value={form.studentName} onChange={(e) => setForm({ ...form, studentName: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" /></div>
                <div><label className="block text-sm font-medium text-gray-700 mb-1">{t("Phone", "फोन")}</label><input type="tel" value={form.studentPhone} onChange={(e) => setForm({ ...form, studentPhone: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" /></div>
                <div><label className="block text-sm font-medium text-gray-700 mb-1">{t("Email", "ईमेल")}</label><input type="email" value={form.studentEmail} onChange={(e) => setForm({ ...form, studentEmail: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" /></div>
              </div>
            </div>
            <div className="bg-green-50 rounded-xl p-4">
              <h3 className="font-semibold text-green-800 mb-3">{t("Buyer Details", "खरीदार विवरण")}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><label className="block text-sm font-medium text-gray-700 mb-1">{t("Buyer Name", "खरीदार का नाम")} *</label><input type="text" value={form.buyerName} onChange={(e) => setForm({ ...form, buyerName: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 outline-none" /></div>
                <div><label className="block text-sm font-medium text-gray-700 mb-1">{t("Phone", "फोन")} *</label><input type="tel" value={form.buyerPhone} onChange={(e) => setForm({ ...form, buyerPhone: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 outline-none" /></div>
                <div><label className="block text-sm font-medium text-gray-700 mb-1">{t("Email", "ईमेल")}</label><input type="email" value={form.buyerEmail} onChange={(e) => setForm({ ...form, buyerEmail: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 outline-none" /></div>
                <div><label className="block text-sm font-medium text-gray-700 mb-1">{t("Address", "पता")}</label><input type="text" value={form.buyerAddress} onChange={(e) => setForm({ ...form, buyerAddress: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 outline-none" /></div>
              </div>
            </div>
            <div className="bg-purple-50 rounded-xl p-4">
              <h3 className="font-semibold text-purple-800 mb-3">{t("Product Details", "उत्पाद विवरण")}</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t("Product", "उत्पाद")} *</label>
                  <select value={form.productId} onChange={(e) => { const product = products?.find((p: any) => p.id === Number(e.target.value)); setForm({ ...form, productId: e.target.value, productName: product?.name || "", unit: product?.unit || "kg", price: product?.price?.toString() || "" }); }} className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none">
                    <option value="">{t("Select Product", "उत्पाद चुनें")}</option>
                    {products?.map((p: any) => (<option key={p.id} value={p.id}>{p.name} (Rs.{p.price}/{p.unit})</option>))}
                  </select>
                </div>
                <div><label className="block text-sm font-medium text-gray-700 mb-1">{t("Quantity", "मात्रा")} *</label><input type="number" step="0.1" min="0" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" /></div>
                <div><label className="block text-sm font-medium text-gray-700 mb-1">{t("Price per unit (Rs.)", "प्रति यूनिट मूल्य")} *</label><input type="number" step="0.01" min="0" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" /></div>
              </div>
              {form.quantity && form.price && (
                <div className="mt-4 bg-white rounded-lg p-3 flex items-center justify-between">
                  <span className="text-gray-600">{t("Total Amount", "कुल राशि")}:</span>
                  <span className="text-xl font-bold text-purple-700">Rs.{(parseFloat(form.quantity) * parseFloat(form.price)).toFixed(2)}</span>
                </div>
              )}
            </div>
            <div className="bg-yellow-50 rounded-xl p-4">
              <h3 className="font-semibold text-yellow-800 mb-3">{t("Payment Details", "भुगतान विवरण")}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div><label className="block text-sm font-medium text-gray-700 mb-1">{t("Payment Method", "भुगतान विधि")}</label><select value={form.paymentMethod} onChange={(e) => setForm({ ...form, paymentMethod: e.target.value as any })} className="w-full px-4 py-2 border border-gray-200 rounded-lg outline-none"><option value="cash">{t("Cash", "नकद")}</option><option value="upi">UPI</option><option value="qr">QR Code</option><option value="bank_transfer">{t("Bank Transfer", "बैंक ट्रांसफर")}</option></select></div>
                <div><label className="block text-sm font-medium text-gray-700 mb-1">{t("Payment Status", "भुगतान स्थिति")}</label><select value={form.paymentStatus} onChange={(e) => setForm({ ...form, paymentStatus: e.target.value as any })} className="w-full px-4 py-2 border border-gray-200 rounded-lg outline-none"><option value="pending">{t("Pending", "लंबित")}</option><option value="paid">{t("Paid", "भुगतान किया")}</option><option value="partial">{t("Partial", "आंशिक")}</option></select></div>
                <div><label className="block text-sm font-medium text-gray-700 mb-1">{t("Notes", "नोट्स")}</label><input type="text" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="w-full px-4 py-2 border border-gray-200 rounded-lg outline-none" /></div>
              </div>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setShowForm(false)} className="flex-1 px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition-all">{t("Cancel", "रद्द करें")}</button>
              <button onClick={handleSubmit} disabled={createSale.isPending} className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white rounded-xl font-medium transition-all disabled:opacity-50">
                {createSale.isPending ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <><Send className="w-5 h-5" />{t("Submit Sale", "बिक्री जमा करें")}</>}
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
