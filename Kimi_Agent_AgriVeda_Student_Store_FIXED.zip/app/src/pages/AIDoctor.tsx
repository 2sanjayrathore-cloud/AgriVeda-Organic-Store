import { useState, useRef } from "react";
import { useLanguage } from "@/hooks/useLanguage";
import { trpc } from "@/providers/trpc";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import {
  Stethoscope,
  Camera,
  Upload,
  Send,
  Leaf,
  Bug,
  FlaskConical,
  AlertCircle,
  Sprout,
  Microscope,
  ShieldCheck,
  Sun,
} from "lucide-react";

export default function AIDoctor() {
  const { t } = useLanguage();
  const [cropType, setCropType] = useState("");
  const [symptoms, setSymptoms] = useState("");
  const [farmerName, setFarmerName] = useState("");
  const [farmerPhone, setFarmerPhone] = useState("");
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const diagnoseMutation = trpc.ai.diagnose.useMutation({
    onSuccess: (_data) => {
      toast.success(t("Diagnosis complete!", "निदान पूरा हुआ!"));
    },
    onError: () => {
      toast.error(t("Diagnosis failed. Please try again.", "निदान विफल। कृपया पुनः प्रयास करें।"));
    },
  });

  const diagnosis = diagnoseMutation.data;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleCameraCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setShowCamera(true);
      }
    } catch {
      toast.error(t("Camera access denied", "कैमरा एक्सेस अस्वीकृत"));
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext("2d")?.drawImage(video, 0, 0);
      const dataUrl = canvas.toDataURL("image/jpeg");
      setImagePreview(dataUrl);
      setShowCamera(false);
      
      const stream = video.srcObject as MediaStream;
      stream?.getTracks().forEach((track) => track.stop());
    }
  };

  const handleDiagnose = () => {
    if (!cropType.trim() || !symptoms.trim()) {
      toast.error(t("Please fill crop type and symptoms", "कृपया फसल प्रकार और लक्षण भरें"));
      return;
    }

    diagnoseMutation.mutate({
      cropType,
      symptoms,
      farmerName: farmerName || undefined,
      farmerPhone: farmerPhone || undefined,
      imageUrl: imagePreview || undefined,
    });
  };

  const handleWhatsAppShare = () => {
    if (!diagnosis) return;
    const message = `*AgriVeda AI Crop Diagnosis*\n\n*Crop:* ${cropType}\n*Symptoms:* ${symptoms}\n\n*Diagnosis:* ${diagnosis.diagnosis}\n\n*Recommended:* ${diagnosis.recommendedProduct}\n\n*Solution:* ${diagnosis.organicSolution}`;
    window.open(`https://wa.me/917877612427?text=${encodeURIComponent(message)}`, "_blank");
  };

  const handleReset = () => {
    setCropType("");
    setSymptoms("");
    setImagePreview(null);
    diagnoseMutation.reset();
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center mx-auto mb-4 shadow-lg">
          <Stethoscope className="w-10 h-10 text-white" />
        </div>
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          {t("AI Crop Doctor", "एआई फसल डॉक्टर")}
        </h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          {t(
            "Upload a photo or describe symptoms to get instant organic treatment recommendations from our AI-powered crop doctor.",
            "तुरंत जैविक उपचार सिफारिशें प्राप्त करने के लिए एक फोटो अपलोड करें या लक्षणों का वर्णन करें।"
          )}
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white rounded-2xl shadow-md p-6"
        >
          <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <Microscope className="w-5 h-5 text-green-600" />
            {t("Describe the Problem", "समस्या का वर्णन करें")}
          </h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t("Crop Type", "फसल प्रकार")} *
              </label>
              <input
                type="text"
                value={cropType}
                onChange={(e) => setCropType(e.target.value)}
                placeholder={t("e.g., Tomato, Rice, Wheat", "जैसे, टमाटर, धान, गेहूं")}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {t("Symptoms", "लक्षण")} *
              </label>
              <textarea
                value={symptoms}
                onChange={(e) => setSymptoms(e.target.value)}
                placeholder={t("Describe what you see: yellow leaves, spots, wilting, pests, etc.", "जो आप देखते हैं उसका वर्णन करें: पीली पत्तियां, धब्बे, मुरझाना, कीड़े, आदि।")}
                rows={4}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t("Your Name (optional)", "आपका नाम (वैकल्पिक)")}
                </label>
                <input
                  type="text"
                  value={farmerName}
                  onChange={(e) => setFarmerName(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t("Phone (optional)", "फोन (वैकल्पिक)")}
                </label>
                <input
                  type="tel"
                  value={farmerPhone}
                  onChange={(e) => setFarmerPhone(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t("Upload Photo (optional)", "फोटो अपलोड करें (वैकल्पिक)")}
              </label>
              <div className="flex gap-3">
                <label className="flex-1 flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed border-green-300 rounded-xl hover:border-green-500 hover:bg-green-50 cursor-pointer transition-all">
                  <Upload className="w-5 h-5 text-green-600" />
                  <span className="text-sm text-green-700">{t("Choose File", "फाइल चुनें")}</span>
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </label>
                <button
                  onClick={handleCameraCapture}
                  className="flex items-center justify-center gap-2 px-4 py-3 bg-green-100 hover:bg-green-200 rounded-xl transition-all"
                >
                  <Camera className="w-5 h-5 text-green-600" />
                  <span className="text-sm text-green-700">{t("Camera", "कैमरा")}</span>
                </button>
              </div>

              {showCamera && (
                <div className="mt-4 relative">
                  <video ref={videoRef} className="w-full rounded-xl" />
                  <canvas ref={canvasRef} className="hidden" />
                  <button
                    onClick={capturePhoto}
                    className="absolute bottom-4 left-1/2 -translate-x-1/2 px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-full font-medium"
                  >
                    {t("Capture", "कैप्चर")}
                  </button>
                </div>
              )}

              {imagePreview && !showCamera && (
                <div className="mt-4 relative">
                  <img src={imagePreview} alt="Preview" className="w-full rounded-xl max-h-60 object-contain bg-gray-50" />
                  <button
                    onClick={() => setImagePreview(null)}
                    className="absolute top-2 right-2 w-8 h-8 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center"
                  >
                    <AlertCircle className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>

            <button
              onClick={handleDiagnose}
              disabled={diagnoseMutation.isPending}
              className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white rounded-xl font-semibold transition-all hover:scale-[1.02] disabled:opacity-50"
            >
              {diagnoseMutation.isPending ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Stethoscope className="w-5 h-5" />
                  {t("Get Diagnosis", "निदान प्राप्त करें")}
                </>
              )}
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
        >
          <AnimatePresence mode="wait">
            {diagnosis ? (
              <motion.div
                key="result"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white rounded-2xl shadow-lg border border-green-100 overflow-hidden"
              >
                <div className="bg-gradient-to-r from-green-500 to-emerald-500 text-white p-6">
                  <div className="flex items-center gap-3">
                    <ShieldCheck className="w-8 h-8" />
                    <div>
                      <h3 className="text-lg font-semibold">{t("Diagnosis Report", "निदान रिपोर्ट")}</h3>
                      <p className="text-green-100 text-sm">{cropType}</p>
                    </div>
                  </div>
                </div>

                <div className="p-6 space-y-6">
                  <div className="flex gap-3">
                    <AlertCircle className="w-6 h-6 text-red-500 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-gray-800">{t("Diagnosis", "निदान")}</h4>
                      <p className="text-gray-600 text-sm mt-1">{diagnosis.diagnosis}</p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <FlaskConical className="w-6 h-6 text-blue-500 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-gray-800">{t("Recommended Products", "अनुशंसित उत्पाद")}</h4>
                      <div className="bg-blue-50 rounded-lg p-3 mt-2">
                        <p className="text-blue-700 font-medium">{diagnosis.recommendedProduct}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <Leaf className="w-6 h-6 text-green-500 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-gray-800">{t("Organic Solution", "जैविक समाधान")}</h4>
                      <div className="bg-green-50 rounded-lg p-3 mt-2">
                        <p className="text-green-700 text-sm whitespace-pre-line">{diagnosis.organicSolution}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4 border-t">
                    <button
                      onClick={handleWhatsAppShare}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-green-500 hover:bg-green-600 text-white rounded-xl text-sm font-medium transition-all"
                    >
                      <Send className="w-4 h-4" />
                      {t("Share on WhatsApp", "व्हाट्सएप पर साझा करें")}
                    </button>
                    <button
                      onClick={handleReset}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-medium transition-all"
                    >
                      {t("New Diagnosis", "नया निदान")}
                    </button>
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="bg-white rounded-2xl shadow-md p-8 text-center border border-dashed border-gray-200"
              >
                <img
                  src="/ai-doctor.jpg"
                  alt="AI Doctor"
                  className="w-48 h-48 object-contain mx-auto mb-6 rounded-2xl"
                />
                <h3 className="text-lg font-semibold text-gray-700 mb-2">
                  {t("Your AI Crop Doctor is Ready!", "आपका एआई फसल डॉक्टर तैयार है!")}
                </h3>
                <p className="text-gray-500 text-sm max-w-sm mx-auto mb-6">
                  {t(
                    "Fill in the details about your crop problem and get instant organic treatment recommendations.",
                    "अपनी फसल समस्या के बारे में विवरण भरें और तुरंत जैविक उपचार सिफारिशें प्राप्त करें।"
                  )}
                </p>
                <div className="grid grid-cols-2 gap-3 text-left">
                  {[
                    { icon: Bug, text: t("Pest Identification", "कीट पहचान") },
                    { icon: Sun, text: t("Disease Diagnosis", "रोग निदान") },
                    { icon: Leaf, text: t("Organic Treatment", "जैविक उपचार") },
                    { icon: Sprout, text: t("Prevention Tips", "रोकथाम सुझाव") },
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-green-50 rounded-lg p-3">
                      <item.icon className="w-5 h-5 text-green-600" />
                      <span className="text-sm text-green-700">{item.text}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
}
