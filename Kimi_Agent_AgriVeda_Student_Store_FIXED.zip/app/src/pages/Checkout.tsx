import { useState } from "react";
import { useNavigate, Link } from "react-router";
import { useLanguage } from "@/hooks/useLanguage";
import { useCart } from "@/hooks/useCart";
import { trpc } from "@/providers/trpc";
import { QRCodeSVG } from "qrcode.react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import {
  CreditCard,
  Truck,
  MapPin,
  User,
  QrCode,
  Banknote,
  ArrowLeft,
  Check,
  FileText,
} from "lucide-react";

export default function Checkout() {
  const { t } = useLanguage();
  const cart = useCart();
  const navigate = useNavigate();
  const [step, setStep] = useState<"details" | "payment">("details");
  const [paymentMethod, setPaymentMethod] = useState<"cod" | "upi" | "qr">("cod");

  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
    village: "",
    district: "",
    state: "Madhya Pradesh",
    pincode: "",
    notes: "",
    upiId: "",
  });

  const createOrder = trpc.order.create.useMutation({
    onSuccess: (data) => {
      toast.success(t("Order placed successfully!", "ऑर्डर सफलतापूर्वक दिया गया!"));
      cart.clearCart();
      navigate(`/order-confirmation/${data.orderNumber}`);
    },
    onError: (error) => {
      toast.error(error.message || t("Failed to place order", "ऑर्डर देने में विफल"));
    },
  });

  const subtotal = cart.getTotal();
  const deliveryCharge = subtotal > 500 ? 0 : 50;
  const total = subtotal + deliveryCharge;

  const handleSubmit = () => {
    if (!form.name || !form.phone || !form.address) {
      toast.error(t("Please fill all required fields", "कृपया सभी आवश्यक फ़ील्ड भरें"));
      return;
    }

    createOrder.mutate({
      customerName: form.name,
      customerPhone: form.phone,
      customerEmail: form.email || undefined,
      customerAddress: `${form.address}, ${form.village}, ${form.district}, ${form.state} - ${form.pincode}`,
      items: cart.items.map((item) => ({
        productId: item.productId,
        productName: item.name,
        quantity: item.quantity,
        unit: item.unit,
        price: item.price,
        total: item.price * item.quantity,
      })),
      totalAmount: subtotal,
      discount: 0,
      finalAmount: total,
      paymentMethod,
      notes: form.notes,
    });
  };

  const upiUri = `upi://pay?pa=sanjayrathorevbyl@oksbi&pn=AgriVeda Organic Store&am=${total.toFixed(2)}&cu=INR&tn=Order from AgriVeda`;

  if (cart.items.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <Check className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-700 mb-2">
            {t("Cart is empty!", "कार्ट खाली है!")}
          </h2>
          <Link to="/products" className="text-green-600 hover:underline">
            {t("Continue Shopping", "खरीदारी जारी रखें")}
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <Link
        to="/cart"
        className="inline-flex items-center gap-2 text-gray-600 hover:text-green-600 mb-6 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        {t("Back to Cart", "कार्ट पर वापस")}
      </Link>

      <h1 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
        <CreditCard className="w-6 h-6 text-green-600" />
        {t("Checkout", "चेकआउट")}
      </h1>

      <div className="flex items-center gap-4 mb-8">
        <div className={`flex items-center gap-2 ${step === "details" ? "text-green-600" : "text-gray-400"}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${step === "details" ? "bg-green-600 text-white" : "bg-gray-200"}`}>1</div>
          <span className="text-sm font-medium">{t("Details", "विवरण")}</span>
        </div>
        <div className="flex-1 h-0.5 bg-gray-200">
          <div className={`h-full bg-green-600 transition-all ${step === "payment" ? "w-full" : "w-0"}`} />
        </div>
        <div className={`flex items-center gap-2 ${step === "payment" ? "text-green-600" : "text-gray-400"}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${step === "payment" ? "bg-green-600 text-white" : "bg-gray-200"}`}>2</div>
          <span className="text-sm font-medium">{t("Payment", "भुगतान")}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {step === "details" ? (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-2xl shadow-md p-6">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <User className="w-5 h-5 text-green-600" />
                {t("Customer Details", "ग्राहक विवरण")}
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t("Full Name", "पूरा नाम")} *</label>
                  <input type="text" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none" placeholder={t("Enter your name", "अपना नाम दर्ज करें")} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t("Phone Number", "फोन नंबर")} *</label>
                  <input type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none" placeholder="7877612427" maxLength={10} />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t("Email (optional)", "ईमेल (वैकल्पिक)")}</label>
                  <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none" placeholder="sanjayrathorevbyl@gmail.com" />
                </div>
              </div>

              <h2 className="text-lg font-semibold mt-6 mb-4 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-green-600" />
                {t("Delivery Address", "डिलीवरी पता")}
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t("Address", "पता")} *</label>
                  <textarea value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none resize-none" rows={2} placeholder={t("Enter your full address", "अपना पूरा पता दर्ज करें")} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t("Village/City", "गांव/शहर")}</label>
                  <input type="text" value={form.village} onChange={(e) => setForm({ ...form, village: e.target.value })} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t("District", "जिला")}</label>
                  <input type="text" value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t("State", "राज्य")}</label>
                  <input type="text" value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t("Pincode", "पिनकोड")}</label>
                  <input type="text" value={form.pincode} onChange={(e) => setForm({ ...form, pincode: e.target.value })} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none" maxLength={6} />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t("Order Notes (optional)", "ऑर्डर नोट्स (वैकल्पिक)")}</label>
                  <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none resize-none" rows={2} placeholder={t("Any special instructions...", "कोई विशेष निर्देश...")} />
                </div>
              </div>

              <button
                onClick={() => {
                  if (!form.name || !form.phone || !form.address) {
                    toast.error(t("Please fill all required fields", "कृपया सभी आवश्यक फ़ील्ड भरें"));
                    return;
                  }
                  setStep("payment");
                }}
                className="w-full mt-6 flex items-center justify-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold transition-all hover:scale-105"
              >
                {t("Continue to Payment", "भुगतान जारी रखें")}
                <ArrowLeft className="w-5 h-5 rotate-180" />
              </button>
            </motion.div>
          ) : (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
              <div className="bg-white rounded-2xl shadow-md p-6">
                <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-green-600" />
                  {t("Select Payment Method", "भुगतान विधि चुनें")}
                </h2>

                <div className="space-y-3">
                  <button onClick={() => setPaymentMethod("cod")} className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all ${paymentMethod === "cod" ? "border-green-500 bg-green-50" : "border-gray-200 hover:border-green-300"}`}>
                    <Banknote className="w-8 h-8 text-green-600" />
                    <div className="text-left">
                      <h3 className="font-semibold text-gray-800">{t("Cash on Delivery", "डिलीवरी पर नकदी")}</h3>
                      <p className="text-sm text-gray-500">{t("Pay when you receive the order", "ऑर्डर प्राप्त करने पर भुगतान करें")}</p>
                    </div>
                  </button>

                  <button onClick={() => setPaymentMethod("qr")} className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all ${paymentMethod === "qr" ? "border-green-500 bg-green-50" : "border-gray-200 hover:border-green-300"}`}>
                    <QrCode className="w-8 h-8 text-blue-600" />
                    <div className="text-left">
                      <h3 className="font-semibold text-gray-800">{t("UPI QR Code", "यूपीआई क्यूआर कोड")}</h3>
                      <p className="text-sm text-gray-500">{t("Scan QR to pay via any UPI app", "किसी भी यूपीआई ऐप से भुगतान के लिए QR स्कैन करें")}</p>
                    </div>
                  </button>

                  <button onClick={() => setPaymentMethod("upi")} className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all ${paymentMethod === "upi" ? "border-green-500 bg-green-50" : "border-gray-200 hover:border-green-300"}`}>
                    <QrCode className="w-8 h-8 text-purple-600" />
                    <div className="text-left">
                      <h3 className="font-semibold text-gray-800">{t("UPI ID", "यूपीआई आईडी")}</h3>
                      <p className="text-sm text-gray-500">{t("Pay using UPI ID", "यूपीआई आईडी का उपयोग करके भुगतान करें")}</p>
                    </div>
                  </button>
                </div>
              </div>

              {paymentMethod === "qr" && (
                <div className="bg-white rounded-2xl shadow-md p-6 text-center">
                  <h3 className="font-semibold text-gray-800 mb-4">{t("Scan to Pay Rs.", "भुगतान के लिए स्कैन करें Rs.")}{total.toFixed(2)}</h3>
                  <div className="bg-white p-4 rounded-xl inline-block shadow-inner">
                    <QRCodeSVG value={upiUri} size={200} />
                  </div>
                  <p className="text-sm text-gray-500 mt-3">{t("Use any UPI app like Google Pay, PhonePe, Paytm", "गूगल पे, फोनपे, पेटीएम जैसे किसी भी यूपीआई ऐप का उपयोग करें")}</p>
                  <p className="text-sm text-green-600 font-medium mt-1">UPI ID: sanjayrathorevbyl@oksbi</p>
                </div>
              )}

              {paymentMethod === "upi" && (
                <div className="bg-white rounded-2xl shadow-md p-6">
                  <h3 className="font-semibold text-gray-800 mb-4">{t("Enter UPI Details", "यूपीआई विवरण दर्ज करें")}</h3>
                  <div className="bg-blue-50 rounded-xl p-4 mb-4">
                    <p className="text-sm text-blue-700">{t("Pay to: sanjayrathorevbyl@oksbi", "भुगतान करें: sanjayrathorevbyl@oksbi")}</p>
                    <p className="text-sm text-blue-700 font-semibold">{t("Amount", "राशि")}: Rs.{total.toFixed(2)}</p>
                  </div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t("Your UPI ID / Transaction Ref", "आपकी यूपीआई आईडी / लेनदेन संदर्भ")}</label>
                  <input type="text" value={form.upiId} onChange={(e) => setForm({ ...form, upiId: e.target.value })} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none" placeholder="name@upi" />
                </div>
              )}

              <div className="flex gap-3">
                <button onClick={() => setStep("details")} className="flex-1 px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition-all">{t("Back", "वापस")}</button>
                <button onClick={handleSubmit} disabled={createOrder.isPending} className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold transition-all hover:scale-105 disabled:opacity-50">
                  {createOrder.isPending ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <><Check className="w-5 h-5" />{t("Place Order", "ऑर्डर दें")}</>}
                </button>
              </div>
            </motion.div>
          )}
        </div>

        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl shadow-md p-6 sticky top-24">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5 text-green-600" />
              {t("Order Summary", "ऑर्डर सारांश")}
            </h2>
            <div className="space-y-3 max-h-60 overflow-y-auto mb-4">
              {cart.items.map((item) => (
                <div key={item.productId} className="flex justify-between text-sm">
                  <span className="text-gray-600">{t(item.name, item.nameHi || item.name).slice(0, 20)} x{item.quantity}</span>
                  <span className="font-medium">Rs.{(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>
            <div className="border-t pt-4 space-y-2">
              <div className="flex justify-between text-sm text-gray-600">
                <span>{t("Subtotal", "उप-योग")}</span>
                <span>Rs.{subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm text-gray-600">
                <span className="flex items-center gap-1"><Truck className="w-4 h-4" />{t("Delivery", "डिलीवरी")}</span>
                <span className={deliveryCharge === 0 ? "text-green-600" : ""}>{deliveryCharge === 0 ? t("FREE", "मुफ्त") : `Rs.${deliveryCharge}`}</span>
              </div>
              <div className="border-t pt-2 flex justify-between font-bold text-lg">
                <span>{t("Total", "कुल")}</span>
                <span className="text-green-600">Rs.{total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
