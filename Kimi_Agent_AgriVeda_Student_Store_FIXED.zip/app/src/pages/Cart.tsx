import { Link, useNavigate } from "react-router";
import { useLanguage } from "@/hooks/useLanguage";
import { useCart } from "@/hooks/useCart";
import { motion } from "framer-motion";
import {
  ShoppingCart,
  Minus,
  Plus,
  Trash2,
  ArrowRight,
  Package,
  Tag,
} from "lucide-react";

export default function Cart() {
  const { t } = useLanguage();
  const cart = useCart();
  const navigate = useNavigate();

  const subtotal = cart.getTotal();
  const deliveryCharge = subtotal > 500 ? 0 : 50;
  const total = subtotal + deliveryCharge;

  if (cart.items.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <ShoppingCart className="w-20 h-20 text-gray-200 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-gray-700 mb-2">
            {t("Your Cart is Empty", "आपका कार्ट खाली है")}
          </h2>
          <p className="text-gray-500 mb-8">
            {t("Browse our products and add items to your cart.", "हमारे उत्पाद ब्राउज़ करें और कार्ट में आइटम जोड़ें।")}
          </p>
          <Link
            to="/products"
            className="inline-flex items-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold transition-all hover:scale-105"
          >
            <Package className="w-5 h-5" />
            {t("Start Shopping", "खरीदारी शुरू करें")}
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
        <ShoppingCart className="w-6 h-6 text-green-600" />
        {t("Shopping Cart", "शॉपिंग कार्ट")}
        <span className="text-sm font-normal text-gray-500">
          ({cart.items.length} {t("items", "आइटम")})
        </span>
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          {cart.items.map((item, idx) => (
            <motion.div
              key={item.productId}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="bg-white rounded-2xl shadow-md p-4 flex gap-4"
            >
              <img
                src={item.image || "/products/vermicompost.jpg"}
                alt={item.name}
                className="w-24 h-24 object-cover rounded-xl"
              />
              <div className="flex-1">
                <h3 className="font-semibold text-gray-800">{t(item.name, item.nameHi || item.name)}</h3>
                <p className="text-sm text-gray-500">
                  ₹{item.price}/{item.unit}
                </p>
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() =>
                        cart.updateQuantity(item.productId, item.quantity - 1)
                      }
                      className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-10 text-center font-semibold">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() =>
                        cart.updateQuantity(item.productId, item.quantity + 1)
                      }
                      className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-bold text-green-600">
                      ₹{(item.price * item.quantity).toFixed(2)}
                    </span>
                    <button
                      onClick={() => cart.removeItem(item.productId)}
                      className="w-8 h-8 rounded-lg bg-red-50 hover:bg-red-100 flex items-center justify-center text-red-500 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}

          <button
            onClick={() => cart.clearCart()}
            className="text-red-500 hover:text-red-600 text-sm font-medium flex items-center gap-1 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            {t("Clear Cart", "कार्ट खाली करें")}
          </button>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl shadow-md p-6 sticky top-24">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">
              {t("Order Summary", "ऑर्डर सारांश")}
            </h2>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-gray-600">
                <span>{t("Subtotal", "उप-योग")}</span>
                <span>₹{subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span className="flex items-center gap-1">
                  <Tag className="w-4 h-4" />
                  {t("Delivery", "डिलीवरी")}
                </span>
                <span className={deliveryCharge === 0 ? "text-green-600 font-medium" : ""}>
                  {deliveryCharge === 0 ? t("FREE", "मुफ्त") : `₹${deliveryCharge}`}
                </span>
              </div>
              {subtotal > 500 && (
                <div className="text-green-600 text-sm bg-green-50 p-2 rounded-lg">
                  {t("You got FREE delivery!", "आपको मुफ्त डिलीवरी मिली!")}
                </div>
              )}
              <div className="border-t pt-3 flex justify-between font-bold text-lg">
                <span>{t("Total", "कुल")}</span>
                <span className="text-green-600">₹{total.toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={() => navigate("/checkout")}
              className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold transition-all hover:scale-105"
            >
              {t("Proceed to Checkout", "चेकआउट करें")}
              <ArrowRight className="w-5 h-5" />
            </button>

            <Link
              to="/products"
              className="block text-center text-green-600 hover:text-green-700 text-sm mt-4"
            >
              {t("Continue Shopping", "खरीदारी जारी रखें")}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
