import { useState } from "react";
import { Link } from "react-router";
import { useLanguage } from "@/hooks/useLanguage";
import { trpc } from "@/providers/trpc";
import { motion } from "framer-motion";
import {
  Search,
  Package,
  Truck,
  CheckCircle,
  Clock,
  MapPin,
  Phone,
  CreditCard,
  FileText,
  UserCircle,
} from "lucide-react";

export default function TrackOrder() {
  const { t } = useLanguage();
  const [orderNumber, setOrderNumber] = useState("");
  const [searched, setSearched] = useState(false);

  const { data: order, isLoading } = trpc.order.getByOrderNumber.useQuery(
    { orderNumber },
    { enabled: searched && orderNumber.length > 0 }
  );

  const handleSearch = () => {
    if (orderNumber.trim()) {
      setSearched(true);
    }
  };

  const getStatusStep = (status: string) => {
    const steps = ["pending", "confirmed", "processing", "shipped", "delivered"];
    return steps.indexOf(status || "pending");
  };

  const statusLabels = [
    { key: "pending", label: t("Order Placed", "ऑर्डर दिया गया"), icon: FileText },
    { key: "confirmed", label: t("Confirmed", "पुष्टि की गई"), icon: CheckCircle },
    { key: "processing", label: t("Processing", "प्रसंस्करण"), icon: Clock },
    { key: "shipped", label: t("Shipped", "भेज दिया गया"), icon: Truck },
    { key: "delivered", label: t("Delivered", "डिलीवर किया गया"), icon: Package },
  ];

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-orange-400 to-red-500 flex items-center justify-center mx-auto mb-3">
          <Search className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-gray-800">
          {t("Track Your Order", "अपना ऑर्डर ट्रैक करें")}
        </h1>
        <p className="text-gray-500">
          {t("Enter your order number to check status", "स्थिति जांचने के लिए अपना ऑर्डर नंबर दर्ज करें")}
        </p>
      </motion.div>

      {/* Search */}
      <div className="bg-white rounded-2xl shadow-md p-6 mb-8">
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={orderNumber}
              onChange={(e) => {
                setOrderNumber(e.target.value);
                setSearched(false);
              }}
              onKeyPress={(e) => e.key === "Enter" && handleSearch()}
              placeholder={t("Enter order number (e.g., AGR123)", "ऑर्डर नंबर दर्ज करें")}
              className="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none"
            />
          </div>
          <button
            onClick={handleSearch}
            className="px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-medium transition-all hover:scale-105"
          >
            {t("Track", "ट्रैक")}
          </button>
        </div>
      </div>

      {/* Results */}
      {isLoading && (
        <div className="text-center py-12">
          <div className="animate-spin w-10 h-10 border-4 border-green-600 border-t-transparent rounded-full mx-auto" />
          <p className="mt-4 text-gray-500">{t("Searching...", "खोज रहे हैं...")}</p>
        </div>
      )}

      {searched && !isLoading && !order && (
        <div className="text-center py-12">
          <Package className="w-16 h-16 text-gray-200 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-700">
            {t("Order not found", "ऑर्डर नहीं मिला")}
          </h3>
          <p className="text-gray-500 mt-1">
            {t("Please check your order number and try again.", "कृपया अपना ऑर्डर नंबर जांचें और पुनः प्रयास करें।")}
          </p>
        </div>
      )}

      {order && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Order Info */}
          <div className="bg-white rounded-2xl shadow-md p-6">
            <div className="flex flex-wrap justify-between items-start gap-4 mb-6">
              <div>
                <p className="text-sm text-gray-500">{t("Order Number", "ऑर्डर नंबर")}</p>
                <p className="text-xl font-bold text-gray-800">{order.orderNumber}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-500">{t("Order Date", "ऑर्डर की तारीख")}</p>
                <p className="font-medium">
                  {new Date(order.createdAt).toLocaleDateString("en-IN")}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <UserCircle className="w-4 h-4 text-green-600" />
                <span>{order.customerName}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-green-600" />
                <span>{order.customerPhone}</span>
              </div>
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-green-600" />
                <span>{order.paymentMethod?.toUpperCase()}</span>
              </div>
              {order.customerAddress && (
                <div className="md:col-span-3 flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-green-600 mt-0.5" />
                  <span>{order.customerAddress}</span>
                </div>
              )}
            </div>
          </div>

          {/* Progress Tracker */}
          <div className="bg-white rounded-2xl shadow-md p-6">
            <h3 className="font-semibold text-gray-800 mb-6">
              {t("Order Status", "ऑर्डर की स्थिति")}
            </h3>

            <div className="relative">
              {/* Progress Line */}
              <div className="absolute top-5 left-0 right-0 h-1 bg-gray-200 rounded">
                <div
                  className="h-full bg-green-500 rounded transition-all duration-500"
                  style={{
                    width: `${Math.min(((getStatusStep(order.status || "pending") + 1) / statusLabels.length) * 100, 100)}%`,
                  }}
                />
              </div>

              {/* Steps */}
              <div className="relative flex justify-between">
                {statusLabels.map((step, idx) => {
                  const currentStep = getStatusStep(order.status || "pending");
                  const isCompleted = idx <= currentStep;
                  const isCurrent = idx === currentStep;

                  return (
                    <div key={step.key} className="flex flex-col items-center">
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${
                          isCompleted
                            ? "bg-green-500 border-green-500 text-white"
                            : isCurrent
                            ? "bg-white border-green-500 text-green-500"
                            : "bg-white border-gray-300 text-gray-400"
                        }`}
                      >
                        <step.icon className="w-5 h-5" />
                      </div>
                      <span className={`text-xs mt-2 text-center max-w-[80px] ${isCompleted ? "text-green-600 font-medium" : "text-gray-400"}`}>
                        {step.label}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Order Items */}
          <div className="bg-white rounded-2xl shadow-md p-6">
            <h3 className="font-semibold text-gray-800 mb-4">
              {t("Order Items", "ऑर्डर आइटम")}
            </h3>
            <div className="space-y-3">
              {(order as any).items?.map((item: any, idx: number) => (
                <div key={idx} className="flex justify-between items-center py-2 border-b last:border-0">
                  <div>
                    <p className="font-medium text-gray-800">{item.productName}</p>
                    <p className="text-sm text-gray-500">
                      {item.quantity} {item.unit} x Rs.{item.price}
                    </p>
                  </div>
                  <p className="font-semibold text-gray-800">Rs.{item.total}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t flex justify-between font-bold text-lg">
              <span>{t("Total", "कुल")}</span>
              <span className="text-green-600">Rs.{order.finalAmount}</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <Link
              to={`/order-confirmation/${order.orderNumber}`}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-medium transition-all"
            >
              <FileText className="w-4 h-4" />
              {t("View Invoice", "इनवॉइस देखें")}
            </Link>
          </div>
        </motion.div>
      )}
    </div>
  );
}
