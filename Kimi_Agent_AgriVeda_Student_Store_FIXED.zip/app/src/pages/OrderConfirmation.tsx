import { useParams, Link } from "react-router";
import { useLanguage } from "@/hooks/useLanguage";
import { trpc } from "@/providers/trpc";
import { useRef } from "react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { motion } from "framer-motion";
import {
  CheckCircle,
  Download,
  MessageCircle,
  ShoppingBag,
  CreditCard,
  Truck,
  QrCode,
} from "lucide-react";

export default function OrderConfirmation() {
  const { orderNumber } = useParams<{ orderNumber: string }>();
  const { t } = useLanguage();
  const billRef = useRef<HTMLDivElement>(null);

  const { data: order, isLoading } = trpc.order.getByOrderNumber.useQuery(
    { orderNumber: orderNumber || "" },
    { enabled: !!orderNumber }
  );

  const handleDownloadPDF = () => {
    if (!order) return;
    const items = (order as any).items || [];
    
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.setTextColor(34, 197, 94);
    doc.text("AgriVeda Organic Store", 105, 20, { align: "center" });
    doc.setFontSize(12);
    doc.setTextColor(100);
    doc.text("College of Agriculture, Balaghat", 105, 28, { align: "center" });
    doc.setDrawColor(34, 197, 94);
    doc.setLineWidth(0.5);
    doc.line(14, 38, 196, 38);
    doc.setFontSize(18);
    doc.setTextColor(0);
    doc.text("INVOICE", 105, 48, { align: "center" });
    doc.setFontSize(10);
    doc.text(`Invoice No: ${order.orderNumber}`, 14, 58);
    doc.text(`Date: ${new Date(order.createdAt).toLocaleDateString("en-IN")}`, 14, 64);
    doc.text(`Status: ${(order.status || "pending").toUpperCase()}`, 14, 70);
    
    doc.setFontSize(12);
    doc.setTextColor(34, 197, 94);
    doc.text("Customer Details:", 14, 82);
    doc.setFontSize(10);
    doc.setTextColor(0);
    doc.text(`Name: ${order.customerName}`, 14, 88);
    doc.text(`Phone: ${order.customerPhone}`, 14, 94);
    if (order.customerEmail) doc.text(`Email: ${order.customerEmail}`, 14, 100);
    if (order.customerAddress) {
      const addr = doc.splitTextToSize(`Address: ${order.customerAddress}`, 90);
      doc.text(addr, 14, 106);
    }

    const tableData = items.map((item: any) => [
      item.productName,
      `${item.quantity} ${item.unit}`,
      `Rs.${item.price}`,
      `Rs.${item.total}`,
    ]);

    autoTable(doc, {
      startY: 120,
      head: [["Product", "Quantity", "Price", "Total"]],
      body: tableData,
      theme: "grid",
      headStyles: { fillColor: [34, 197, 94], textColor: 255 },
      styles: { fontSize: 10 },
    });

    const finalY = (doc as any).lastAutoTable?.finalY ? (doc as any).lastAutoTable.finalY + 10 : 150;

    doc.setFontSize(12);
    doc.text(`Subtotal:`, 140, finalY);
    doc.text(`Rs.${order.totalAmount}`, 180, finalY, { align: "right" });
    doc.text(`Discount:`, 140, finalY + 6);
    doc.text(`Rs.${order.discount || 0}`, 180, finalY + 6, { align: "right" });
    doc.setFontSize(14);
    doc.setTextColor(34, 197, 94);
    doc.text(`Total Amount:`, 140, finalY + 16);
    doc.text(`Rs.${order.finalAmount}`, 180, finalY + 16, { align: "right" });

    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text("Thank you for supporting organic farming!", 105, finalY + 30, { align: "center" });
    doc.text("For queries, contact: 7877612427", 105, finalY + 36, { align: "center" });

    doc.save(`AgriVeda_Invoice_${order.orderNumber}.pdf`);
  };

  const handleWhatsAppShare = () => {
    if (!order) return;
    const items = (order as any).items || [];
    const itemsText = items.map((i: any) => `• ${i.productName} - ${i.quantity}${i.unit} x Rs.${i.price} = Rs.${i.total}`).join("\n");
    const message = `*AgriVeda Organic Store - Order Confirmation*\n\n*Order #:* ${order.orderNumber}\n*Customer:* ${order.customerName}\n*Phone:* ${order.customerPhone}\n\n*Items:*\n${itemsText}\n\n*Total:* Rs.${order.finalAmount}\n*Payment:* ${(order.paymentMethod || "cod").toUpperCase()}\n\nThank you for choosing organic!\nCollege of Agriculture, Balaghat`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, "_blank");
  };

  const handleSendToCustomerWhatsApp = () => {
    if (!order) return;
    const items = (order as any).items || [];
    const itemsText = items.map((i: any) => `• ${i.productName} - ${i.quantity}${i.unit} = Rs.${i.total}`).join("\n");
    const message = `Namaste!\n\nYour order from *AgriVeda Organic Store* has been confirmed!\n\n*Order #:* ${order.orderNumber}\n*Amount:* Rs.${order.finalAmount}\n*Items:*\n${itemsText}\n\nWe will contact you soon for delivery.\n\nThank you for supporting organic farming!\nCollege of Agriculture, Balaghat`;
    window.open(`https://wa.me/91${order.customerPhone}?text=${encodeURIComponent(message)}`, "_blank");
  };

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <div className="animate-spin w-10 h-10 border-4 border-green-600 border-t-transparent rounded-full mx-auto" />
        <p className="mt-4 text-gray-500">{t("Loading order...", "ऑर्डर लोड हो रहा है...")}</p>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold text-gray-700 mb-2">{t("Order not found", "ऑर्डर नहीं मिला")}</h2>
        <Link to="/products" className="text-green-600 hover:underline">{t("Continue Shopping", "खरीदारी जारी रखें")}</Link>
      </div>
    );
  }

  const items = (order as any).items || [];

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
        <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
        <h1 className="text-3xl font-bold text-gray-800 mb-2">{t("Order Confirmed!", "ऑर्डर की पुष्टि हो गई!")}</h1>
        <p className="text-gray-600">{t("Thank you for your order. We will contact you soon.", "आपके ऑर्डर के लिए धन्यवाद। हम जल्द ही संपर्क करेंगे।")}</p>
      </motion.div>

      <motion.div ref={billRef} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white rounded-2xl shadow-lg border border-green-100 overflow-hidden">
        <div className="bg-gradient-to-r from-green-600 to-emerald-600 text-white p-6 text-center">
          <h2 className="text-2xl font-bold">AgriVeda Organic Store</h2>
          <p className="text-green-200 text-sm">College of Agriculture, Balaghat</p>
          <p className="text-green-200 text-xs mt-1">Phone: 7877612427</p>
        </div>

        <div className="p-6 border-b">
          <div className="flex flex-wrap justify-between gap-4">
            <div>
              <p className="text-sm text-gray-500">{t("Invoice No", "चालान नंबर")}</p>
              <p className="font-bold text-lg">{order.orderNumber}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-500">{t("Date", "तारीख")}</p>
              <p className="font-medium">{new Date(order.createdAt).toLocaleDateString("en-IN")}</p>
            </div>
          </div>
        </div>

        <div className="p-6 border-b bg-gray-50">
          <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <ShoppingBag className="w-4 h-4 text-green-600" />
            {t("Customer Details", "ग्राहक विवरण")}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
            <p><span className="text-gray-500">{t("Name", "नाम")}:</span> {order.customerName}</p>
            <p><span className="text-gray-500">{t("Phone", "फोन")}:</span> {order.customerPhone}</p>
            {order.customerEmail && <p><span className="text-gray-500">{t("Email", "ईमेल")}:</span> {order.customerEmail}</p>}
            {order.customerAddress && <p className="md:col-span-2"><span className="text-gray-500">{t("Address", "पता")}:</span> {order.customerAddress}</p>}
          </div>
        </div>

        <div className="p-6 border-b">
          <h3 className="font-semibold text-gray-800 mb-4">{t("Order Items", "ऑर्डर आइटम")}</h3>
          <div className="space-y-3">
            {items.map((item: any, idx: number) => (
              <div key={idx} className="flex justify-between items-center py-2 border-b last:border-0">
                <div>
                  <p className="font-medium text-gray-800">{item.productName}</p>
                  <p className="text-sm text-gray-500">{item.quantity} {item.unit} x Rs.{item.price}</p>
                </div>
                <p className="font-semibold text-gray-800">Rs.{item.total}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 border-b bg-gray-50">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">{t("Subtotal", "उप-योग")}</span>
              <span>Rs.{order.totalAmount}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">{t("Discount", "छूट")}</span>
              <span>Rs.{order.discount || 0}</span>
            </div>
            <div className="flex justify-between text-lg font-bold pt-2 border-t">
              <span className="text-gray-800">{t("Total Amount", "कुल राशि")}</span>
              <span className="text-green-600">Rs.{order.finalAmount}</span>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="flex flex-wrap justify-between gap-4 text-sm">
            <div className="flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-green-600" />
              <span><strong>{t("Payment", "भुगतान")}:</strong> {(order.paymentMethod || "cod").toUpperCase()}</span>
            </div>
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-green-600" />
              <span><strong>{t("Status", "स्थिति")}:</strong> {(order.status || "pending").toUpperCase()}</span>
            </div>
          </div>
        </div>

        <div className="bg-green-50 p-4 text-center text-sm text-green-700">
          <p>{t("Thank you for supporting organic farming!", "जैविक खेती का समर्थन करने के लिए धन्यवाद!")}</p>
          <p className="mt-1">{t("College of Agriculture, Balaghat", "कॉलेज ऑफ एग्रीकल्चर, बालाघाट")}</p>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <button onClick={handleDownloadPDF} className="flex items-center justify-center gap-2 px-4 py-3 bg-red-500 hover:bg-red-600 text-white rounded-xl font-medium transition-all hover:scale-105">
          <Download className="w-4 h-4" />{t("Download PDF", "पीडीएफ डाउनलोड")}
        </button>
        <button onClick={handleSendToCustomerWhatsApp} className="flex items-center justify-center gap-2 px-4 py-3 bg-green-500 hover:bg-green-600 text-white rounded-xl font-medium transition-all hover:scale-105">
          <MessageCircle className="w-4 h-4" />{t("Send WhatsApp", "व्हाट्सएप भेजें")}
        </button>
        <button onClick={handleWhatsAppShare} className="flex items-center justify-center gap-2 px-4 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-medium transition-all hover:scale-105">
          <QrCode className="w-4 h-4" />{t("Share", "साझा करें")}
        </button>
        <Link to="/products" className="flex items-center justify-center gap-2 px-4 py-3 bg-gray-800 hover:bg-gray-900 text-white rounded-xl font-medium transition-all hover:scale-105">
          <ShoppingBag className="w-4 h-4" />{t("Shop More", "और खरीदें")}
        </Link>
      </motion.div>

      {order.paymentStatus === "pending" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="mt-6 bg-white rounded-2xl shadow-md p-6 text-center">
          <h3 className="font-semibold text-gray-800 mb-4">{t("Complete Your Payment", "अपना भुगतान पूरा करें")}</h3>
          <p className="text-gray-500 text-sm mb-4">{t("Scan this QR code with any UPI app to pay", "भुगतान के लिए किसी भी यूपीआई ऐप से इस QR कोड को स्कैन करें")}</p>
          <div className="bg-white p-4 rounded-xl inline-block shadow-inner border">
            <QrCode className="w-32 h-32 text-gray-300 mx-auto" />
          </div>
          <p className="text-green-600 font-medium mt-3">UPI: sanjayrathorevbyl@oksbi</p>
          <p className="text-gray-800 font-bold text-lg mt-1">Rs.{order.finalAmount}</p>
        </motion.div>
      )}
    </div>
  );
}
