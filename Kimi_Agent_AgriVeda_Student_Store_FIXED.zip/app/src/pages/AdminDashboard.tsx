import { useState } from "react";
import { Link } from "react-router";
import { useLanguage } from "@/hooks/useLanguage";
import { trpc } from "@/providers/trpc";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { motion } from "framer-motion";
import {
  LayoutDashboard,
  DollarSign,
  ShoppingCart,
  TrendingUp,
  TrendingDown,
  Package,
  AlertTriangle,
  Trash2,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3,
  PieChartIcon,
  Activity,
} from "lucide-react";
import { toast } from "sonner";

const COLORS = ["#22c55e", "#3b82f6", "#f59e0b", "#ef4444", "#8b5cf6"];

const revenueData = [
  { name: "Mon", revenue: 4000, expenses: 2400 },
  { name: "Tue", revenue: 3000, expenses: 1398 },
  { name: "Wed", revenue: 2000, expenses: 9800 },
  { name: "Thu", revenue: 2780, expenses: 3908 },
  { name: "Fri", revenue: 1890, expenses: 4800 },
  { name: "Sat", revenue: 2390, expenses: 3800 },
  { name: "Sun", revenue: 3490, expenses: 4300 },
];

const categoryData = [
  { name: "Fertilizers", value: 400 },
  { name: "Pesticides", value: 300 },
  { name: "Bio-Fertilizers", value: 200 },
  { name: "Services", value: 100 },
];

export default function AdminDashboard() {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<"overview" | "orders" | "sales" | "expenses" | "inventory">("overview");

  const { data: overview } = trpc.dashboard.overview.useQuery();
  const { data: orders } = trpc.order.list.useQuery();
  const { data: salesData } = trpc.sales.list.useQuery();
  const { data: expensesData } = trpc.expense.list.useQuery({});
  const { data: salesStats } = trpc.sales.stats.useQuery();

  const utils = trpc.useUtils();

  const updateOrderStatus = trpc.order.updateStatus.useMutation({
    onSuccess: () => { utils.order.list.invalidate(); utils.dashboard.overview.invalidate(); toast.success(t("Status updated", "स्थिति अपडेट की गई")); },
  });

  const deleteExpense = trpc.expense.delete.useMutation({
    onSuccess: () => { utils.expense.list.invalidate(); utils.sales.stats.invalidate(); utils.dashboard.overview.invalidate(); toast.success(t("Expense deleted", "खर्च हटा दिया गया")); },
  });

  const tabs = [
    { id: "overview", label: t("Overview", "अवलोकन"), icon: LayoutDashboard },
    { id: "orders", label: t("Orders", "ऑर्डर"), icon: ShoppingCart },
    { id: "sales", label: t("Sales", "बिक्री"), icon: DollarSign },
    { id: "expenses", label: t("Expenses", "खर्च"), icon: TrendingDown },
    { id: "inventory", label: t("Inventory", "इन्वेंटरी"), icon: Package },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2"><LayoutDashboard className="w-7 h-7 text-green-600" />{t("Admin Dashboard", "एडमिन डैशबोर्ड")}</h1>
          <p className="text-gray-500 text-sm mt-1">{t("Welcome back, Sanjay!", "वापसी पर स्वागत है, संजय!")}</p>
        </div>
        <div className="text-sm text-gray-500 bg-white px-4 py-2 rounded-lg shadow-sm"><Calendar className="w-4 h-4 inline mr-2" />{new Date().toLocaleDateString("en-IN", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <StatCard title={t("Total Revenue", "कुल राजस्व")} value={`Rs.${(overview?.totalRevenue || 0).toLocaleString("en-IN")}`} icon={DollarSign} trend="up" trendValue="+12%" color="green" />
        <StatCard title={t("Today Revenue", "आज का राजस्व")} value={`Rs.${(overview?.todayRevenue || 0).toLocaleString("en-IN")}`} icon={TrendingUp} trend="up" trendValue="+5%" color="blue" />
        <StatCard title={t("Total Orders", "कुल ऑर्डर")} value={String(overview?.totalOrders || 0)} icon={ShoppingCart} trend="up" trendValue="+8%" color="purple" />
        <StatCard title={t("Net Profit", "शुद्ध लाभ")} value={`Rs.${(salesStats?.netProfit || 0).toLocaleString("en-IN")}`} icon={Activity} trend={salesStats?.netProfit && salesStats.netProfit > 0 ? "up" : "down"} trendValue="N/A" color="emerald" />
      </div>

      <div className="flex flex-wrap gap-2 mb-6 bg-white p-2 rounded-xl shadow-sm">
        {tabs.map((tab) => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === tab.id ? "bg-green-600 text-white" : "text-gray-600 hover:bg-green-50"}`}>
            <tab.icon className="w-4 h-4" />{tab.label}
          </button>
        ))}
      </div>

      {activeTab === "overview" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-2xl shadow-md p-6">
              <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2"><BarChart3 className="w-5 h-5 text-green-600" />{t("Revenue vs Expenses", "राजस्व बनाम खर्च")}</h3>
              <ResponsiveContainer width="100%" height={300}><LineChart data={revenueData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" /><YAxis /><Tooltip /><Legend /><Line type="monotone" dataKey="revenue" stroke="#22c55e" name="Revenue" strokeWidth={2} /><Line type="monotone" dataKey="expenses" stroke="#ef4444" name="Expenses" strokeWidth={2} /></LineChart></ResponsiveContainer>
            </div>
            <div className="bg-white rounded-2xl shadow-md p-6">
              <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2"><PieChartIcon className="w-5 h-5 text-green-600" />{t("Sales by Category", "श्रेणी के अनुसार बिक्री")}</h3>
              <ResponsiveContainer width="100%" height={300}><PieChart><Pie data={categoryData} cx="50%" cy="50%" labelLine={false} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} outerRadius={80} fill="#8884d8" dataKey="value">{categoryData.map((_entry, index) => (<Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />))}</Pie><Tooltip /></PieChart></ResponsiveContainer>
            </div>
          </div>
          <div className="bg-white rounded-2xl shadow-md p-6">
            <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2"><ShoppingCart className="w-5 h-5 text-green-600" />{t("Recent Orders", "हाल के ऑर्डर")}</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm"><thead><tr className="border-b"><th className="text-left py-2 px-3">{t("Order #", "ऑर्डर #")}</th><th className="text-left py-2 px-3">{t("Customer", "ग्राहक")}</th><th className="text-left py-2 px-3">{t("Amount", "राशि")}</th><th className="text-left py-2 px-3">{t("Status", "स्थिति")}</th><th className="text-left py-2 px-3">{t("Date", "तारीख")}</th></tr></thead>
                <tbody>{overview?.recentOrders?.slice(0, 5).map((order: any) => (<tr key={order.id} className="border-b hover:bg-gray-50"><td className="py-2 px-3 font-medium">{order.orderNumber}</td><td className="py-2 px-3">{order.customerName}</td><td className="py-2 px-3">Rs.{order.finalAmount}</td><td className="py-2 px-3"><span className={`px-2 py-1 rounded-full text-xs font-medium ${order.status === "delivered" ? "bg-green-100 text-green-700" : order.status === "pending" ? "bg-yellow-100 text-yellow-700" : "bg-blue-100 text-blue-700"}`}>{order.status?.toUpperCase()}</span></td><td className="py-2 px-3 text-gray-500">{new Date(order.createdAt).toLocaleDateString("en-IN")}</td></tr>))}</tbody>
              </table>
            </div>
          </div>
          {overview?.lowStockProducts && overview.lowStockProducts.length > 0 && (
            <div className="bg-red-50 border border-red-200 rounded-2xl p-6">
              <h3 className="font-semibold text-red-700 mb-4 flex items-center gap-2"><AlertTriangle className="w-5 h-5" />{t("Low Stock Alert", "कम स्टॉक अलर्ट")}</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {overview.lowStockProducts.map((product: any) => (<div key={product.id} className="bg-white rounded-xl p-3 flex items-center gap-3"><img src={product.image || "/products/vermicompost.jpg"} alt={product.name} className="w-12 h-12 rounded-lg object-cover" /><div><p className="font-medium text-sm">{product.name}</p><p className="text-red-500 text-xs">{t("Only", "केवल")} {product.stock} {product.unit} {t("left", "बचे")}</p></div></div>))}
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === "orders" && (
        <div className="bg-white rounded-2xl shadow-md p-6">
          <h3 className="font-semibold text-gray-800 mb-4">{t("All Orders", "सभी ऑर्डर")}</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm"><thead><tr className="border-b"><th className="text-left py-2 px-3">{t("Order #", "ऑर्डर #")}</th><th className="text-left py-2 px-3">{t("Customer", "ग्राहक")}</th><th className="text-left py-2 px-3">{t("Phone", "फोन")}</th><th className="text-left py-2 px-3">{t("Amount", "राशि")}</th><th className="text-left py-2 px-3">{t("Status", "स्थिति")}</th><th className="text-left py-2 px-3">{t("Actions", "कार्रवाई")}</th></tr></thead>
              <tbody>{orders?.map((order: any) => (<tr key={order.id} className="border-b hover:bg-gray-50"><td className="py-2 px-3 font-medium">{order.orderNumber}</td><td className="py-2 px-3">{order.customerName}</td><td className="py-2 px-3">{order.customerPhone}</td><td className="py-2 px-3">Rs.{order.finalAmount}</td><td className="py-2 px-3"><select value={order.status || "pending"} onChange={(e) => updateOrderStatus.mutate({ id: order.id, status: e.target.value as any })} className="text-xs border rounded-lg px-2 py-1 outline-none"><option value="pending">PENDING</option><option value="confirmed">CONFIRMED</option><option value="processing">PROCESSING</option><option value="shipped">SHIPPED</option><option value="delivered">DELIVERED</option><option value="cancelled">CANCELLED</option></select></td><td className="py-2 px-3"><Link to={`/order-confirmation/${order.orderNumber}`} className="text-green-600 hover:text-green-700 text-xs font-medium">{t("View", "देखें")}</Link></td></tr>))}</tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === "sales" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-green-50 rounded-2xl p-6 border border-green-200"><p className="text-sm text-green-600">{t("Total Sales", "कुल बिक्री")}</p><p className="text-2xl font-bold text-green-700">Rs.{(salesStats?.totalSales || 0).toLocaleString("en-IN")}</p></div>
            <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200"><p className="text-sm text-blue-600">{t("Today's Sales", "आज की बिक्री")}</p><p className="text-2xl font-bold text-blue-700">Rs.{(salesStats?.todaySales || 0).toLocaleString("en-IN")}</p></div>
            <div className="bg-yellow-50 rounded-2xl p-6 border border-yellow-200"><p className="text-sm text-yellow-600">{t("Pending Payments", "लंबित भुगतान")}</p><p className="text-2xl font-bold text-yellow-700">Rs.{(salesStats?.pendingSales || 0).toLocaleString("en-IN")}</p></div>
          </div>
          <div className="bg-white rounded-2xl shadow-md p-6">
            <h3 className="font-semibold text-gray-800 mb-4">{t("Student Sales Records", "छात्र बिक्री रिकॉर्ड")}</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm"><thead><tr className="border-b"><th className="text-left py-2 px-3">{t("Student", "छात्र")}</th><th className="text-left py-2 px-3">{t("Buyer", "खरीदार")}</th><th className="text-left py-2 px-3">{t("Product", "उत्पाद")}</th><th className="text-left py-2 px-3">{t("Qty", "मात्रा")}</th><th className="text-left py-2 px-3">{t("Amount", "राशि")}</th><th className="text-left py-2 px-3">{t("Payment", "भुगतान")}</th><th className="text-left py-2 px-3">{t("Date", "तारीख")}</th></tr></thead>
                <tbody>{salesData?.slice(0, 50).map((sale: any) => (<tr key={sale.id} className="border-b hover:bg-gray-50"><td className="py-2 px-3">{sale.studentName}</td><td className="py-2 px-3">{sale.buyerName}</td><td className="py-2 px-3">{sale.productName}</td><td className="py-2 px-3">{sale.quantity} {sale.unit}</td><td className="py-2 px-3">Rs.{sale.totalAmount}</td><td className="py-2 px-3"><span className={`text-xs px-2 py-1 rounded-full ${sale.paymentStatus === "paid" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}>{sale.paymentStatus?.toUpperCase()}</span></td><td className="py-2 px-3 text-gray-500">{new Date(sale.createdAt).toLocaleDateString("en-IN")}</td></tr>))}</tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeTab === "expenses" && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl shadow-md p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-gray-800">{t("Expense Records", "खर्च रिकॉर्ड")}</h3>
              <div className="text-right"><p className="text-sm text-gray-500">{t("Total Expenses", "कुल खर्च")}</p><p className="text-2xl font-bold text-red-600">Rs.{(salesStats?.totalExpenses || 0).toLocaleString("en-IN")}</p></div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm"><thead><tr className="border-b"><th className="text-left py-2 px-3">{t("Category", "श्रेणी")}</th><th className="text-left py-2 px-3">{t("Description", "विवरण")}</th><th className="text-left py-2 px-3">{t("Amount", "राशि")}</th><th className="text-left py-2 px-3">{t("Date", "तारीख")}</th><th className="text-left py-2 px-3">{t("Action", "कार्रवाई")}</th></tr></thead>
                <tbody>{expensesData?.map((expense: any) => (<tr key={expense.id} className="border-b hover:bg-gray-50"><td className="py-2 px-3"><span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs">{expense.category}</span></td><td className="py-2 px-3">{expense.description}</td><td className="py-2 px-3 font-medium">Rs.{expense.amount}</td><td className="py-2 px-3 text-gray-500">{new Date(expense.createdAt).toLocaleDateString("en-IN")}</td><td className="py-2 px-3"><button onClick={() => deleteExpense.mutate({ id: expense.id })} className="text-red-500 hover:text-red-600"><Trash2 className="w-4 h-4" /></button></td></tr>))}</tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeTab === "inventory" && (
        <div className="bg-white rounded-2xl shadow-md p-6">
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2"><Package className="w-5 h-5 text-green-600" />{t("Inventory Status", "इन्वेंटरी स्थिति")}</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm"><thead><tr className="border-b"><th className="text-left py-2 px-3">{t("Product", "उत्पाद")}</th><th className="text-left py-2 px-3">{t("Stock", "स्टॉक")}</th><th className="text-left py-2 px-3">{t("Unit", "इकाई")}</th><th className="text-left py-2 px-3">{t("Price", "कीमत")}</th><th className="text-left py-2 px-3">{t("Status", "स्थिति")}</th></tr></thead>
              <tbody>{overview?.lowStockProducts?.map((product: any) => (<tr key={product.id} className="border-b hover:bg-gray-50"><td className="py-2 px-3 flex items-center gap-2"><img src={product.image || "/products/vermicompost.jpg"} alt={product.name} className="w-8 h-8 rounded object-cover" />{product.name}</td><td className="py-2 px-3">{product.stock}</td><td className="py-2 px-3">{product.unit}</td><td className="py-2 px-3">Rs.{product.price}</td><td className="py-2 px-3"><span className={`text-xs px-2 py-1 rounded-full ${product.stock < 20 ? "bg-red-100 text-red-700" : product.stock < 50 ? "bg-yellow-100 text-yellow-700" : "bg-green-100 text-green-700"}`}>{product.stock < 20 ? "CRITICAL" : product.stock < 50 ? "LOW" : "OK"}</span></td></tr>))}</tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ title, value, icon: Icon, trend, trendValue, color }: any) {
  const colorClasses: any = { green: "bg-green-50 text-green-600", blue: "bg-blue-50 text-blue-600", purple: "bg-purple-50 text-purple-600", emerald: "bg-emerald-50 text-emerald-600" };
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-2xl shadow-md p-5">
      <div className="flex items-center justify-between mb-3">
        <div className={`w-10 h-10 rounded-xl ${colorClasses[color] || colorClasses.green} flex items-center justify-center`}><Icon className="w-5 h-5" /></div>
        <div className={`flex items-center gap-1 text-xs font-medium ${trend === "up" ? "text-green-600" : "text-red-600"}`}>{trend === "up" ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}{trendValue}</div>
      </div>
      <p className="text-gray-500 text-sm">{title}</p>
      <p className="text-xl font-bold text-gray-800 mt-1">{value}</p>
    </motion.div>
  );
}
