import { useParams, Link, useNavigate } from "react-router";
import { useLanguage } from "@/hooks/useLanguage";
import { useCart } from "@/hooks/useCart";
import { trpc } from "@/providers/trpc";
import { useState } from "react";
import { motion } from "framer-motion";
import {
  ShoppingCart,
  ArrowLeft,
  Minus,
  Plus,
  Check,
  Star,
  Package,
  Leaf,
  Shield,
  Info,
  Zap,
} from "lucide-react";

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const { t } = useLanguage();
  const cart = useCart();
  const navigate = useNavigate();
  const [quantity, setQuantity] = useState(1);
  const [addedToCart, setAddedToCart] = useState(false);

  const { data: product, isLoading } = trpc.product.getById.useQuery({ id: Number(id) });

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <div className="animate-spin w-10 h-10 border-4 border-green-600 border-t-transparent rounded-full mx-auto" />
        <p className="mt-4 text-gray-500">{t("Loading...", "लोड हो रहा है...")}</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-gray-600">{t("Product not found", "उत्पाद नहीं मिला")}</h2>
        <Link to="/products" className="text-green-600 hover:underline mt-4 inline-block">{t("Back to Products", "उत्पादों पर वापस")}</Link>
      </div>
    );
  }

  const price = parseFloat(product.price?.toString() || "0");
  const benefits = (product.benefits as string[]) || [];
  const benefitsHi = (product.benefitsHi as string[]) || [];

  const handleAddToCart = () => {
    cart.addItem({ productId: product.id, name: product.name, nameHi: product.nameHi, price, unit: product.unit || "kg", quantity, image: product.image });
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  const handleBuyNow = () => {
    handleAddToCart();
    navigate("/checkout");
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <Link to="/products" className="inline-flex items-center gap-2 text-gray-600 hover:text-green-600 mb-6 transition-colors"><ArrowLeft className="w-4 h-4" />{t("Back to Products", "उत्पादों पर वापस")}</Link>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <motion.div initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} className="bg-white rounded-3xl shadow-lg p-6">
          <img src={product.image || "/products/vermicompost.jpg"} alt={product.name} className="w-full h-[400px] object-contain rounded-2xl" />
          {product.stock < 50 && (
            <div className="mt-4 bg-red-50 border border-red-200 rounded-xl p-3 flex items-center gap-2">
              <Info className="w-4 h-4 text-red-500" /><span className="text-red-600 text-sm font-medium">{t("Only few left in stock!", "स्टॉक में केवल कुछ ही बचे हैं!")}</span>
            </div>
          )}
        </motion.div>
        <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-medium">{t("100% Organic", "100% जैविक")}</span>
            <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded-full font-medium">{t("College Certified", "कॉलेज प्रमाणित")}</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{t(product.name, product.nameHi || product.name)}</h1>
          <p className="text-gray-600 mb-6">{t(product.description || "", product.descriptionHi || "")}</p>
          <div className="bg-green-50 rounded-2xl p-6 mb-6">
            <div className="flex items-baseline gap-2"><span className="text-4xl font-bold text-green-700">Rs.{price}</span><span className="text-gray-500">/{product.unit}</span></div>
            <div className="flex items-center gap-4 mt-3 text-sm text-gray-600">
              <span className="flex items-center gap-1"><Package className="w-4 h-4" />{t("Stock", "स्टॉक")}: {product.stock} {product.unit}</span>
              <span className="flex items-center gap-1"><Leaf className="w-4 h-4" />{t("Min Order", "न्यूनतम ऑर्डर")}: {product.minOrder} {product.unit}</span>
            </div>
          </div>
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">{t("Quantity", "मात्रा")} ({product.unit})</label>
            <div className="flex items-center gap-4">
              <button onClick={() => setQuantity(Math.max(product.minOrder || 1, quantity - 1))} className="w-10 h-10 rounded-xl bg-gray-100 hover:bg-gray-200 flex items-center justify-center"><Minus className="w-4 h-4" /></button>
              <span className="text-xl font-semibold w-16 text-center">{quantity}</span>
              <button onClick={() => setQuantity(quantity + 1)} className="w-10 h-10 rounded-xl bg-gray-100 hover:bg-gray-200 flex items-center justify-center"><Plus className="w-4 h-4" /></button>
              <span className="text-gray-500 ml-4">= <strong className="text-green-600 text-lg">Rs.{(price * quantity).toFixed(2)}</strong></span>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <button onClick={handleAddToCart} className={`flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all hover:scale-105 active:scale-95 ${addedToCart ? "bg-green-500 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`}>
              {addedToCart ? <><Check className="w-5 h-5" />{t("Added to Cart!", "कार्ट में जोड़ा गया!")}</> : <><ShoppingCart className="w-5 h-5" />{t("Add to Cart", "कार्ट में जोड़ें")}</>}
            </button>
            <button onClick={handleBuyNow} className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold transition-all hover:scale-105 active:scale-95">
              <Zap className="w-5 h-5" />{t("Buy Now", "अभी खरीदें")}
            </button>
          </div>
          {benefits.length > 0 && (
            <div className="mt-8">
              <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2"><Star className="w-5 h-5 text-yellow-500" />{t("Benefits", "लाभ")}</h3>
              <div className="space-y-2">{benefits.map((benefit: string, idx: number) => (<div key={idx} className="flex items-start gap-2"><Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" /><span className="text-gray-600 text-sm">{t(benefit, benefitsHi[idx] || benefit)}</span></div>))}</div>
            </div>
          )}
          {(product.usage || product.usageHi) && (
            <div className="mt-6">
              <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2"><Info className="w-5 h-5 text-blue-500" />{t("How to Use", "उपयोग विधि")}</h3>
              <div className="bg-blue-50 rounded-xl p-4"><p className="text-gray-600 text-sm">{t(product.usage || "", product.usageHi || "")}</p></div>
            </div>
          )}
          <div className="mt-8 grid grid-cols-3 gap-4">
            <div className="text-center"><Shield className="w-8 h-8 text-green-600 mx-auto mb-1" /><span className="text-xs text-gray-500">{t("Quality Guaranteed", "गुणवत्ता गारंटी")}</span></div>
            <div className="text-center"><Leaf className="w-8 h-8 text-green-600 mx-auto mb-1" /><span className="text-xs text-gray-500">{t("100% Organic", "100% जैविक")}</span></div>
            <div className="text-center"><Zap className="w-8 h-8 text-green-600 mx-auto mb-1" /><span className="text-xs text-gray-500">{t("Fast Delivery", "तेज डिलीवरी")}</span></div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
