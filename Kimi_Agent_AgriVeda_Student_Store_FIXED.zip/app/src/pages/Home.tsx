import { Link } from "react-router";
import { useLanguage } from "@/hooks/useLanguage";
import { useCart } from "@/hooks/useCart";
import { trpc } from "@/providers/trpc";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  ShoppingCart,
  Sparkles,
  Stethoscope,
  Truck,
  Leaf,
  Shield,
  ChevronRight,
  Star,
  Users,
  Award,
  Phone,
  MessageCircle,
  TrendingUp,
  Zap,
  Barcode,
  Globe,
} from "lucide-react";

export default function Home() {
  const { t } = useLanguage();
  const [currentSlide, setCurrentSlide] = useState(0);

  const { data: products } = trpc.product.list.useQuery({});

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % 3);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const slides = [
    {
      title: t("100% Organic Inputs", "100% जैविक इनपुट"),
      subtitle: t("From Our College Farm to Your Field", "हमारे कॉलेज फार्म से आपके खेत तक"),
      desc: t("Premium quality vermicompost, bio-fertilizers, and organic pesticides prepared by agriculture students.", "कृषि छात्रों द्वारा तैयार प्रीमियम क्वालिटी वर्मीकम्पोस्ट, जैव-उर्वरक और जैविक कीटनाशक।"),
    },
    {
      title: t("AI-Powered Crop Doctor", "एआई संचालित फसल डॉक्टर"),
      subtitle: t("Free Plant Disease Diagnosis", "निःशुल्क पौधा रोग निदान"),
      desc: t("Upload photos of affected plants and get instant organic treatment recommendations.", "प्रभावित पौधों की फोटो अपलोड करें और तुरंत जैविक उपचार सिफारिशें प्राप्त करें।"),
    },
    {
      title: t("Student Entrepreneurship", "छात्र उद्यमिता"),
      subtitle: t("Supporting Agriculture Students", "कृषि छात्रों का समर्थन"),
      desc: t("Every purchase supports the education and practical training of agriculture students at College of Agriculture, Balaghat.", "हर खरीदारी कॉलेज ऑफ एग्रीकल्चर, बालाघाट में कृषि छात्रों की शिक्षा और व्यावहारिक प्रशिक्षण का समर्थन करती है।"),
    },
  ];

  const features = [
    { icon: Shield, title: t("100% Organic", "100% जैविक"), desc: t("Chemical-free products", "रसायन मुक्त उत्पाद") },
    { icon: Truck, title: t("Fast Delivery", "तेज डिलीवरी"), desc: t("Quick doorstep service", "त्वरित doorstep सेवा") },
    { icon: Award, title: t("Best Quality", "सर्वश्रेष्ठ गुणवत्ता"), desc: t("College certified inputs", "कॉलेज प्रमाणित इनपुट") },
    { icon: Phone, title: t("24/7 Support", "24/7 सहायता"), desc: t("Always here to help", "हमेशा मदद के लिए तैयार") },
  ];

  const services = [
    { icon: Stethoscope, title: t("AI Crop Doctor", "एआई फसल डॉक्टर"), desc: t("Diagnose plant diseases with AI", "एआई से पौधा रोग का निदान करें"), link: "/ai-doctor", color: "from-red-500 to-pink-500" },
    { icon: MessageCircle, title: t("AI Chatbot", "एआई चैटबॉट"), desc: t("24/7 farming assistant", "24/7 कृषि सहायक"), link: "/ai-chatbot", color: "from-blue-500 to-cyan-500" },
    { icon: ShoppingCart, title: t("Online Store", "ऑनलाइन स्टोर"), desc: t("Buy organic inputs online", "जैविक इनपुट ऑनलाइन खरीदें"), link: "/products", color: "from-green-500 to-emerald-500" },
    { icon: TrendingUp, title: t("Sales Entry", "बिक्री एंट्री"), desc: t("Student sales portal", "छात्र बिक्री पोर्टल"), link: "/student-sales", color: "from-purple-500 to-violet-500" },
    { icon: Barcode, title: t("Quick Billing", "त्वरित बिलिंग"), desc: t("Generate bills instantly", "तुरंत बिल जेनरेट करें"), link: "/admin", color: "from-orange-500 to-amber-500" },
    { icon: Globe, title: t("Hindi/English", "हिंदी/अंग्रेजी"), desc: t("Language toggle support", "भाषा टॉगल समर्थन"), link: "#", color: "from-teal-500 to-cyan-500" },
  ];

  const stats = [
    { icon: Users, value: "500+", label: t("Happy Farmers", "खुश किसान") },
    { icon: Leaf, value: "15+", label: t("Organic Products", "जैविक उत्पाद") },
    { icon: Star, value: "1000+", label: t("Orders Delivered", "ऑर्डर डिलीवर") },
    { icon: Award, value: "50+", label: t("Students Trained", "प्रशिक्षित छात्र") },
  ];

  const featuredProducts = products?.slice(0, 6) || [];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[500px] overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url(/hero-banner.jpg)" }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-green-900/80 via-green-800/60 to-transparent" />
        <div className="relative max-w-7xl mx-auto px-4 h-full flex items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-xl text-white"
          >
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-yellow-400" />
              <span className="text-green-200 font-medium">
                {slides[currentSlide].subtitle}
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
              {slides[currentSlide].title}
            </h1>
            <p className="text-lg text-green-100 mb-8">
              {slides[currentSlide].desc}
            </p>
            <div className="flex flex-wrap gap-4">
              <Link
                to="/products"
                className="flex items-center gap-2 px-6 py-3 bg-green-500 hover:bg-green-600 rounded-xl font-semibold transition-all hover:scale-105"
              >
                <ShoppingCart className="w-5 h-5" />
                {t("Shop Now", "अभी खरीदें")}
              </Link>
              <Link
                to="/ai-doctor"
                className="flex items-center gap-2 px-6 py-3 bg-white/20 hover:bg-white/30 backdrop-blur rounded-xl font-semibold transition-all"
              >
                <Stethoscope className="w-5 h-5" />
                {t("AI Doctor", "एआई डॉक्टर")}
              </Link>
            </div>
            <div className="flex gap-2 mt-8">
              {[0, 1, 2].map((idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentSlide(idx)}
                  className={`w-3 h-3 rounded-full transition-all ${
                    idx === currentSlide ? "bg-white w-8" : "bg-white/50"
                  }`}
                />
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Bar */}
      <section className="bg-white shadow-md -mt-4 relative z-10 mx-4 md:mx-8 lg:mx-16 rounded-2xl">
        <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-green-100">
          {features.map((f, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="flex items-center gap-3 p-4 md:p-6"
            >
              <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center flex-shrink-0">
                <f.icon className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-800 text-sm">{f.title}</h3>
                <p className="text-xs text-gray-500">{f.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-2">
            {t("Our Organic Products", "हमारे जैविक उत्पाद")}
          </h2>
          <p className="text-gray-600">
            {t("Premium quality inputs for organic farming", "जैविक खेती के लिए प्रीमियम क्वालिटी इनपुट")}
          </p>
        </div>

        {featuredProducts.length === 0 ? (
          <div className="text-center py-12">
            <div className="animate-spin w-8 h-8 border-4 border-green-600 border-t-transparent rounded-full mx-auto" />
            <p className="mt-4 text-gray-500">{t("Loading products...", "उत्पाद लोड हो रहे हैं...")}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredProducts.map((product: any, idx: number) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
              >
                <ProductCard product={product} />
              </motion.div>
            ))}
          </div>
        )}

        <div className="text-center mt-10">
          <Link
            to="/products"
            className="inline-flex items-center gap-2 px-8 py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold transition-all hover:scale-105"
          >
            {t("View All Products", "सभी उत्पाद देखें")}
            <ChevronRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* Services Grid */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-2">
              {t("Our Services", "हमारी सेवाएं")}
            </h2>
            <p className="text-gray-600">
              {t("Complete organic farming solutions", "संपूर्ण जैविक कृषि समाधान")}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.1 }}
              >
                <Link
                  to={s.link}
                  className="block p-6 rounded-2xl border border-gray-100 hover:shadow-xl transition-all hover:-translate-y-1 bg-white"
                >
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${s.color} flex items-center justify-center mb-4`}>
                    <s.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-1">{s.title}</h3>
                  <p className="text-gray-500 text-sm">{s.desc}</p>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="text-center text-white"
              >
                <stat.icon className="w-10 h-10 mx-auto mb-3 opacity-80" />
                <div className="text-3xl md:text-4xl font-bold mb-1">{stat.value}</div>
                <div className="text-green-200 text-sm">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">
            {t("Ready to Go Organic?", "जैविक खेती के लिए तैयार?")}
          </h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            {t(
              "Contact us for bulk orders, custom formulations, or any questions about organic farming.",
              "थोक ऑर्डर, कस्टम फॉर्मूलेशन, या जैविक खेती के बारे में किसी भी प्रश्न के लिए हमसे संपर्क करें।"
            )}
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a
              href="https://wa.me/917877612427"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-xl font-semibold transition-all hover:scale-105"
            >
              <MessageCircle className="w-5 h-5" />
              {t("WhatsApp Us", "व्हाट्सएप करें")}
            </a>
            <a
              href="tel:7877612427"
              className="flex items-center gap-2 px-6 py-3 bg-gray-800 hover:bg-gray-900 text-white rounded-xl font-semibold transition-all hover:scale-105"
            >
              <Phone className="w-5 h-5" />
              {t("Call Now", "अभी कॉल करें")}
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

function ProductCard({ product }: { product: any }) {
  const { t } = useLanguage();
  const cart = useCart();
  const displayName = product.name;
  const displayNameHi = product.nameHi;
  const price = parseFloat(product.price?.toString() || "0");

  return (
    <div className="bg-white rounded-2xl shadow-md hover:shadow-xl transition-all hover:-translate-y-1 overflow-hidden border border-green-50 group">
      <Link to={`/product/${product.id}`} className="block relative">
        <img
          src={product.image || "/products/vermicompost.jpg"}
          alt={displayName}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
        />
        {product.stock < 50 && (
          <span className="absolute top-3 left-3 bg-red-500 text-white text-xs px-2 py-1 rounded-full font-medium">
            {t("Low Stock", "कम स्टॉक")}
          </span>
        )}
      </Link>
      <div className="p-4">
        <Link to={`/product/${product.id}`}>
          <h3 className="font-semibold text-gray-800 mb-1 hover:text-green-600 transition-colors">
            {t(displayName, displayNameHi || displayName)}
          </h3>
        </Link>
        <p className="text-gray-500 text-sm line-clamp-2 mb-3">
          {product.description?.slice(0, 80)}...
        </p>
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xl font-bold text-green-600">Rs.{price}</span>
            <span className="text-gray-400 text-sm">/{product.unit}</span>
          </div>
          <button
            onClick={() =>
              cart.addItem({
                productId: product.id,
                name: displayName,
                nameHi: displayNameHi,
                price,
                unit: product.unit || "kg",
                quantity: product.minOrder || 1,
                image: product.image,
              })
            }
            className="flex items-center gap-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm font-medium transition-all hover:scale-105 active:scale-95"
          >
            <Zap className="w-4 h-4" />
            {t("Add", "जोड़ें")}
          </button>
        </div>
      </div>
    </div>
  );
}
