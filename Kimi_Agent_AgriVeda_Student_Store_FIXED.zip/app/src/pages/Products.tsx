import { useState } from "react";
import { Link } from "react-router";
import { useLanguage } from "@/hooks/useLanguage";
import { useCart } from "@/hooks/useCart";
import { trpc } from "@/providers/trpc";
import { motion } from "framer-motion";
import {
  Search,
  Filter,
  ChevronRight,
  Zap,
  Package,
} from "lucide-react";

export default function Products() {
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<number | undefined>();
  const [sortBy, setSortBy] = useState("name");

  const { data: products, isLoading } = trpc.product.list.useQuery({
    categoryId: selectedCategory,
    search: searchQuery || undefined,
  });

  const { data: categories } = trpc.product.categories.useQuery();

  const filteredProducts = products
    ? [...products].sort((a: any, b: any) => {
        if (sortBy === "price-low") return parseFloat(a.price) - parseFloat(b.price);
        if (sortBy === "price-high") return parseFloat(b.price) - parseFloat(a.price);
        return a.name.localeCompare(b.name);
      })
    : [];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">{t("Our Products", "हमारे उत्पाद")}</h1>
        <p className="text-gray-600">{t("100% organic inputs for sustainable farming", "सतत खेती के लिए 100% जैविक इनपुट")}</p>
      </div>

      <div className="bg-white rounded-2xl shadow-md p-4 mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder={t("Search products...", "उत्पाद खोजें...")} className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none" />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <select value={selectedCategory || ""} onChange={(e) => setSelectedCategory(e.target.value ? Number(e.target.value) : undefined)} className="pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none appearance-none bg-white min-w-[180px]">
              <option value="">{t("All Categories", "सभी श्रेणियां")}</option>
              {categories?.map((cat: any) => (<option key={cat.id} value={cat.id}>{t(cat.name, cat.nameHi || cat.name)}</option>))}
            </select>
          </div>
          <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none bg-white">
            <option value="name">{t("Sort by Name", "नाम से क्रमबद्ध")}</option>
            <option value="price-low">{t("Price: Low to High", "कीमत: कम से ज्यादा")}</option>
            <option value="price-high">{t("Price: High to Low", "कीमत: ज्यादा से कम")}</option>
          </select>
        </div>
        <div className="flex flex-wrap gap-2 mt-4">
          <button onClick={() => setSelectedCategory(undefined)} className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${!selectedCategory ? "bg-green-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-green-50"}`}>{t("All", "सभी")}</button>
          {categories?.map((cat: any) => (<button key={cat.id} onClick={() => setSelectedCategory(cat.id)} className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${selectedCategory === cat.id ? "bg-green-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-green-50"}`}>{t(cat.name, cat.nameHi || cat.name)}</button>))}
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-20"><div className="animate-spin w-10 h-10 border-4 border-green-600 border-t-transparent rounded-full mx-auto" /><p className="mt-4 text-gray-500">{t("Loading products...", "उत्पाद लोड हो रहे हैं...")}</p></div>
      ) : filteredProducts.length === 0 ? (
        <div className="text-center py-20"><Package className="w-16 h-16 text-gray-300 mx-auto mb-4" /><p className="text-gray-500 text-lg">{t("No products found", "कोई उत्पाद नहीं मिला")}</p></div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product: any, idx: number) => (
            <motion.div key={product.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.05 }}>
              <ProductCard product={product} />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}

function ProductCard({ product }: { product: any }) {
  const { t } = useLanguage();
  const cart = useCart();
  const displayName = product.name;
  const displayNameHi = product.nameHi;
  const price = parseFloat(product.price?.toString() || "0");
  const isService = product.categoryId === 6;

  return (
    <div className="bg-white rounded-2xl shadow-md hover:shadow-xl transition-all hover:-translate-y-1 overflow-hidden border border-green-50 group">
      <Link to={`/product/${product.id}`} className="block relative">
        <img src={product.image || "/products/vermicompost.jpg"} alt={displayName} className="w-full h-44 object-cover group-hover:scale-105 transition-transform duration-500" />
        {product.stock < 50 && !isService && <span className="absolute top-3 left-3 bg-red-500 text-white text-xs px-2 py-1 rounded-full font-medium">{t("Low Stock", "कम स्टॉक")}</span>}
        {isService && <span className="absolute top-3 left-3 bg-blue-500 text-white text-xs px-2 py-1 rounded-full font-medium">{t("Service", "सेवा")}</span>}
      </Link>
      <div className="p-4">
        <Link to={`/product/${product.id}`}><h3 className="font-semibold text-gray-800 mb-1 hover:text-green-600 transition-colors line-clamp-1">{t(displayName, displayNameHi || displayName)}</h3></Link>
        <p className="text-gray-500 text-xs line-clamp-2 mb-3">{product.description?.slice(0, 70)}...</p>
        <div className="flex items-center justify-between">
          <div><span className="text-lg font-bold text-green-600">Rs.{price}</span><span className="text-gray-400 text-xs">/{product.unit}</span></div>
          {!isService && (
            <button onClick={() => cart.addItem({ productId: product.id, name: displayName, nameHi: displayNameHi, price, unit: product.unit || "kg", quantity: product.minOrder || 1, image: product.image })} className="flex items-center gap-1 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm font-medium transition-all hover:scale-105 active:scale-95">
              <Zap className="w-3 h-3" />{t("Add", "जोड़ें")}
            </button>
          )}
          {isService && (<Link to={`/product/${product.id}`} className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-all">{t("Details", "विवरण")}<ChevronRight className="w-3 h-3" /></Link>)}
        </div>
      </div>
    </div>
  );
}
