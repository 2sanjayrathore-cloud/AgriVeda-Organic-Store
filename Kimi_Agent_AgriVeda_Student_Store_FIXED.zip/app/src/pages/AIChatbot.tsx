import { useState, useRef, useEffect } from "react";
import { useLanguage } from "@/hooks/useLanguage";
import { trpc } from "@/providers/trpc";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import {
  Bot,
  Send,
  User,
  Sparkles,
  Mic,
  MicOff,
  Sprout,
} from "lucide-react";

interface Message {
  role: "user" | "assistant";
  message: string;
  createdAt: Date;
}

export default function AIChatbot() {
  const { t } = useLanguage();
  const [input, setInput] = useState("");
  const [sessionId] = useState(() => `session_${Date.now()}`);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      message: t(
        "Namaste! I am your AI farming assistant. Ask me anything about organic farming, our products, or crop management!",
        "नमस्ते! मैं आपका एआई कृषि सहायक हूं। जैविक खेती, हमारे उत्पादों, या फसल प्रबंधन के बारे में कुछ भी पूछें!"
      ),
      createdAt: new Date(),
    },
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const chatMutation = trpc.ai.chat.useMutation({
    onSuccess: (data) => {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", message: data.response, createdAt: new Date() },
      ]);
      setIsTyping(false);
    },
    onError: () => {
      setIsTyping(false);
      toast.error(t("Failed to get response", "उत्तर प्राप्त करने में विफल"));
    },
  });

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage = input.trim();
    setMessages((prev) => [
      ...prev,
      { role: "user", message: userMessage, createdAt: new Date() },
    ]);
    setInput("");
    setIsTyping(true);

    chatMutation.mutate({
      message: userMessage,
      sessionId,
    });
  };

  const handleVoiceInput = () => {
    if (!("webkitSpeechRecognition" in window) && !("SpeechRecognition" in window)) {
      toast.error(t("Voice input not supported in this browser", "इस ब्राउज़र में वॉइस इनपुट समर्थित नहीं है"));
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = "hi-IN";
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput(transcript);
    };
    recognition.onerror = () => {
      setIsListening(false);
      toast.error(t("Voice recognition failed", "वॉइस पहचान विफल"));
    };

    recognition.start();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center mx-auto mb-3">
            <Bot className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800">
            {t("AI Farming Assistant", "एआई कृषि सहायक")}
          </h1>
          <p className="text-gray-500">
            {t("Your 24/7 organic farming guide", "आपका 24/7 जैविक खेती गाइड")}
          </p>
        </motion.div>
      </div>

      <div className="bg-white rounded-2xl shadow-lg border border-green-100 overflow-hidden flex flex-col h-[600px]">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <AnimatePresence>
            {messages.map((msg, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 }}
                className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  msg.role === "assistant"
                    ? "bg-gradient-to-br from-green-400 to-emerald-600"
                    : "bg-gray-200"
                }`}>
                  {msg.role === "assistant" ? (
                    <Sprout className="w-4 h-4 text-white" />
                  ) : (
                    <User className="w-4 h-4 text-gray-600" />
                  )}
                </div>
                <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                  msg.role === "assistant"
                    ? "bg-green-50 text-gray-800"
                    : "bg-green-600 text-white"
                }`}>
                  <p className="text-sm whitespace-pre-line">{msg.message}</p>
                  <p className={`text-xs mt-1 ${
                    msg.role === "assistant" ? "text-gray-400" : "text-green-200"
                  }`}>
                    {msg.createdAt.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isTyping && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex gap-3"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white animate-spin" />
              </div>
              <div className="bg-green-50 rounded-2xl px-4 py-3">
                <div className="flex gap-1">
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-bounce" />
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-bounce" style={{ animationDelay: "0.1s" }} />
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-bounce" style={{ animationDelay: "0.2s" }} />
                </div>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Actions */}
        <div className="px-4 py-2 border-t bg-gray-50 flex gap-2 overflow-x-auto">
          {[
            t("Product Prices", "उत्पाद कीमतें"),
            t("How to use Vermicompost?", "वर्मीकम्पोस्ट का उपयोग कैसे करें?"),
            t("Crop Disease Help", "फसल रोग सहायता"),
            t("About College", "कॉलेज के बारे में"),
          ].map((quickMsg, idx) => (
            <button
              key={idx}
              onClick={() => setInput(quickMsg)}
              className="px-3 py-1.5 bg-white border border-green-200 rounded-full text-xs text-green-700 hover:bg-green-50 transition-colors whitespace-nowrap"
            >
              {quickMsg}
            </button>
          ))}
        </div>

        {/* Input */}
        <div className="p-4 border-t bg-white">
          <div className="flex gap-2">
            <button
              onClick={handleVoiceInput}
              className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                isListening
                  ? "bg-red-500 text-white animate-pulse"
                  : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              }`}
            >
              {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={t("Type your question...", "अपना प्रश्न टाइप करें...")}
              className="flex-1 px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || chatMutation.isPending}
              className="w-10 h-10 rounded-xl bg-green-600 hover:bg-green-700 text-white flex items-center justify-center transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
