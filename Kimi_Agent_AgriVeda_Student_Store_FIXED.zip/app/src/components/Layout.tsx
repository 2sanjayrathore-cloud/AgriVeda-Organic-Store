import { Outlet, Link, useLocation } from "react-router";
import { useLanguage } from "@/hooks/useLanguage";
import { useCart } from "@/hooks/useCart";
import { useState } from "react";
import {
  ShoppingCart,
  Menu,
  X,
  Home,
  Package,
  Stethoscope,
  GraduationCap,
  LayoutDashboard,
  Sprout,
  Globe,
  Phone,
  Search,
  Bot,
} from "lucide-react";

export default function Layout() {
  const { language, toggleLanguage, t } = useLanguage();
  const cart = useCart();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) => location.pathname === path;

  const navItems = [
    { path: "/", icon: Home, label: t("Home", "होम") },
    { path: "/products", icon: Package, label: t("Products", "उत्पाद") },
    { path: "/ai-doctor", icon: Stethoscope, label: t("AI Doctor", "एआई डॉक्टर") },
    { path: "/ai-chatbot", icon: Bot, label: t("AI Chat", "एआई चैट") },
    { path: "/track-order", icon: Search, label: t("Track Order", "ऑर्डर ट्रैक") },
    { path: "/student-sales", icon: GraduationCap, label: t("Student Sales", "स्टूडेंट सेल") },
    { path: "/admin", icon: LayoutDashboard, label: t("Dashboard", "डैशबोर्ड") },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      <div className="bg-gradient-to-r from-green-800 via-emerald-700 to-teal-700 text-white py-2 px-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center text-sm">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> 7877612427</span>
            <span className="hidden sm:inline">sanjayrathorevbyl@gmail.com</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="bg-white/20 px-2 py-0.5 rounded-full text-xs">{t("College of Agriculture, Balaghat", "कॉलेज ऑफ एग्रीकल्चर, बालाघाट")}</span>
          </div>
        </div>
      </div>

      <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-md shadow-lg border-b border-green-100">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center gap-2">
              <Sprout className="w-8 h-8 text-green-600" />
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">AgriVeda</h1>
                <p className="text-[10px] text-green-600 -mt-1">{t("Organic Store", "ऑर्गेनिक स्टोर")}</p>
              </div>
            </Link>

            <div className="hidden lg:flex items-center gap-1">
              {navItems.map((item) => (
                <Link key={item.path} to={item.path} className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${isActive(item.path) ? "bg-green-100 text-green-700" : "text-gray-600 hover:bg-green-50 hover:text-green-600"}`}>
                  <item.icon className="w-4 h-4" />{item.label}
                </Link>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button onClick={toggleLanguage} className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-green-50 text-green-700 hover:bg-green-100 transition-colors text-sm font-medium">
                <Globe className="w-4 h-4" />{language === "en" ? "हिंदी" : "English"}
              </button>
              <Link to="/cart" className="relative flex items-center gap-1 px-3 py-1.5 rounded-lg bg-green-600 text-white hover:bg-green-700 transition-colors">
                <ShoppingCart className="w-4 h-4" />
                <span className="text-sm font-medium hidden sm:inline">{t("Cart", "कार्ट")}</span>
                {cart.getItemCount() > 0 && <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold animate-bounce">{cart.getItemCount()}</span>}
              </Link>
              <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="lg:hidden p-2 rounded-lg hover:bg-green-50">
                {mobileMenuOpen ? <X className="w-6 h-6 text-green-700" /> : <Menu className="w-6 h-6 text-green-700" />}
              </button>
            </div>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-t border-green-100 shadow-lg">
            <div className="px-4 py-3 space-y-1">
              {navItems.map((item) => (
                <Link key={item.path} to={item.path} onClick={() => setMobileMenuOpen(false)} className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${isActive(item.path) ? "bg-green-100 text-green-700" : "text-gray-600 hover:bg-green-50"}`}>
                  <item.icon className="w-5 h-5" />{item.label}
                </Link>
              ))}
            </div>
          </div>
        )}
      </nav>

      <main className="min-h-[calc(100vh-200px)]"><Outlet /></main>

      <footer className="bg-gradient-to-r from-green-800 via-emerald-800 to-teal-800 text-white mt-12">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4"><Sprout className="w-8 h-8 text-green-300" /><h3 className="text-xl font-bold">AgriVeda</h3></div>
              <p className="text-green-200 text-sm">{t("Premium organic inputs from College of Agriculture, Balaghat. Made by students, for farmers.", "कॉलेज ऑफ एग्रीकल्चर, बालाघाट से प्रीमियम जैविक इनपुट। छात्रों द्वारा, किसानों के लिए।")}</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-green-300">{t("Quick Links", "त्वरित लिंक")}</h4>
              <div className="space-y-2 text-sm">
                <Link to="/products" className="block text-green-200 hover:text-white">{t("Our Products", "हमारे उत्पाद")}</Link>
                <Link to="/ai-doctor" className="block text-green-200 hover:text-white">{t("AI Crop Doctor", "एआई फसल डॉक्टर")}</Link>
                <Link to="/ai-chatbot" className="block text-green-200 hover:text-white">{t("AI Assistant", "एआई सहायक")}</Link>
                <Link to="/track-order" className="block text-green-200 hover:text-white">{t("Track Order", "ऑर्डर ट्रैक करें")}</Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-green-300">{t("Our Products", "हमारे उत्पाद")}</h4>
              <div className="space-y-2 text-sm">
                <span className="block text-green-200">Vermicompost (Rs.10/kg)</span>
                <span className="block text-green-200">Vermiwash</span>
                <span className="block text-green-200">BGA Bio-fertilizer</span>
                <span className="block text-green-200">Neemastra</span>
                <span className="block text-green-200">Panchgavya</span>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-green-300">{t("Contact Us", "संपर्क करें")}</h4>
              <div className="space-y-2 text-sm">
                <p className="flex items-center gap-2 text-green-200"><Phone className="w-4 h-4" /> 7877612427</p>
                <p className="text-green-200">sanjayrathorevbyl@gmail.com</p>
                <p className="text-green-200">{t("College of Agriculture", "कॉलेज ऑफ एग्रीकल्चर")}</p>
                <p className="text-green-200">Balaghat, Madhya Pradesh</p>
              </div>
            </div>
          </div>
          <div className="border-t border-green-700 mt-8 pt-8 text-center text-sm text-green-300">
            <p>{t("Made with love by students of College of Agriculture, Balaghat", "कॉलेज ऑफ एग्रीकल्चर, बालाघाट के छात्रों द्वारा प्रेम से बनाया गया")}</p>
            <p className="mt-1"> AgriVeda Organic Store. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
